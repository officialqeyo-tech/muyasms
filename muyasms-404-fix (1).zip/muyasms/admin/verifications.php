<?php
/**
 * MuyaSMS — admin: enterprise verification review.
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_admin();

$tab = (string)($_GET['tab'] ?? 'pending');
$where = $tab === 'history' ? 'v.status IN (\'approved\',\'rejected\')' : 'v.status = \'pending\'';
$vers = qall("SELECT v.*, u.name AS uname, u.email AS uemail FROM verifications v JOIN users u ON u.id = v.user_id WHERE $where ORDER BY v.id DESC LIMIT 200");

muya_page_start(['title' => __('nav_verifications'), 'area' => 'admin', 'active' => 'verifications']);
?>

<div class="flex mb-2" style="gap:8px">
  <a class="btn <?= $tab === 'pending' ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?tab=pending"><?= e(__('st_pending')) ?></a>
  <a class="btn <?= $tab === 'history' ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?tab=history"><?= e(__('ledger')) ?></a>
</div>

<div class="card">
  <?php if (!$vers): ?>
  <div class="empty"><div class="e-ic">🛡️</div><?= e(__('no_data')) ?></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th><?= e(__('company')) ?></th><th><?= e(__('user')) ?></th><th><?= e(__('status')) ?></th>
        <th><?= e(__('date')) ?></th><th><?= e(__('actions')) ?></th>
      </tr></thead>
      <tbody>
      <?php foreach ($vers as $v): ?>
      <tr>
        <td><b><?= e($v['company_name']) ?></b></td>
        <td><?= e($v['uname']) ?><div class="dim small"><?= e($v['uemail']) ?></div></td>
        <td><?= status_badge($v['status']) ?>
          <?php if ($v['note']): ?><div class="dim small"><?= e($v['note']) ?></div><?php endif; ?>
        </td>
        <td class="dim small"><?= e(fmt_dt($v['created_at'])) ?></td>
        <td>
          <div class="flex" style="gap:6px">
            <a class="btn btn-ghost btn-sm" href="../files.php?id=<?= (int)$v['id'] ?>" target="_blank">📄 <?= e(__('download')) ?></a>
            <?php if ($v['status'] === 'pending'): ?>
            <button class="btn btn-green btn-sm" onclick="verAction(<?= (int)$v['id'] ?>, 'approve', false)">✔ <?= e(__('adm_approve')) ?></button>
            <button class="btn btn-danger btn-sm" onclick="verAction(<?= (int)$v['id'] ?>, 'reject', true)">✕ <?= e(__('adm_reject')) ?></button>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<script>
function verAction(id, act, askNote) {
  var note = '';
  if (askNote) {
    note = prompt('<?= e(__('adm_note')) ?>', '') || '';
    if (note === '') return;
  }
  window.muyaApi('../api/admin/verifications.php', { op: act, id: id, note: note }).then(function (j) {
    window.muyaToast(j.msg || '✓', 'ok');
    setTimeout(function () { location.reload(); }, 800);
  }).catch(function () {});
}
</script>
<?php muya_page_end(['area' => 'admin']); ?>
