<?php
/**
 * MuyaSMS — admin: staff & administrator accounts (super-admin only).
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_super();

$staff = qall('SELECT * FROM users WHERE role IN (\'admin\',\'staff\') ORDER BY role, id');

muya_page_start(['title' => __('nav_staff'), 'area' => 'admin', 'active' => 'staff']);
?>

<div class="grid-1-2">
  <div class="card">
    <div class="card-title">➕ <?= e(__('adm_new_staff')) ?></div>
    <form onsubmit="return createStaff(event)">
      <div class="f-group">
        <label class="f-label"><?= e(__('full_name')) ?></label>
        <input class="f-input" id="sName" required maxlength="120">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('email')) ?></label>
        <input class="f-input" type="email" id="sEmail" required placeholder="staff@company.com">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('password')) ?></label>
        <input class="f-input" type="password" id="sPass" required minlength="10">
        <div class="f-hint"><?= e(__('err_password_rules')) ?></div>
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('role')) ?></label>
        <select class="f-input" id="sRole">
          <option value="staff">staff</option>
          <option value="admin">admin (super)</option>
        </select>
      </div>
      <button class="btn btn-primary btn-block" type="submit" id="staffBtn"><?= e(__('submit')) ?></button>
    </form>
  </div>

  <div class="card">
    <div class="card-title">🛡️ <?= e(__('adm_staff_title')) ?></div>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr>
          <th><?= e(__('user')) ?></th><th><?= e(__('role')) ?></th><th><?= e(__('status')) ?></th><th><?= e(__('date')) ?></th><th></th>
        </tr></thead>
        <tbody>
        <?php foreach ($staff as $s): ?>
        <tr>
          <td><b><?= e($s['name']) ?></b><div class="dim small"><?= e($s['email']) ?></div></td>
          <td><span class="tag <?= $s['role'] === 'admin' ? 'tag-gold' : '' ?>"><?= e($s['role']) ?></span></td>
          <td><?= status_badge($s['status']) ?></td>
          <td class="dim small"><?= e(fmt_dt($s['created_at'])) ?></td>
          <td>
            <?php if ((int)$s['id'] !== (int)$admin['id']): ?>
            <button class="btn <?= $s['status'] === 'active' ? 'btn-danger' : 'btn-green' ?> btn-sm" onclick="toggleStaff(<?= (int)$s['id'] ?>, '<?= $s['status'] === 'active' ? 'suspend' : 'activate' ?>')">
              <?= $s['status'] === 'active' ? '⏸' : '▶' ?>
            </button>
            <?php else: ?>
            <span class="tag tag-green">you</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function createStaff(ev) {
  ev.preventDefault();
  var btn = document.getElementById('staffBtn');
  btn.disabled = true;
  window.muyaApi('../api/admin/staff.php', {
    op: 'create',
    name: document.getElementById('sName').value,
    email: document.getElementById('sEmail').value,
    password: document.getElementById('sPass').value,
    role: document.getElementById('sRole').value
  }).then(function () {
    window.muyaToast('<?= e(__('adm_staff_created')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 800);
  }).catch(function () { btn.disabled = false; });
  return false;
}
function toggleStaff(id, act) {
  if (!window.muyaConfirm()) return;
  window.muyaApi('../api/admin/users.php', { op: act, id: id }).then(function () { location.reload(); }).catch(function () {});
}
</script>
<?php muya_page_end(['area' => 'admin']); ?>
