<?php
/**
 * MuyaSMS — ADMIN sign-in.
 * RULE: only administrator emails (role admin/staff) can sign in here.
 * Customer emails are rejected — they must use the customer portal.
 */
require __DIR__ . '/../includes/bootstrap.php';

$u = current_user();
if ($u) {
    if (in_array($u['role'], ['admin', 'staff'], true)) redirect('dashboard.php');
    redirect('../app/index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    require_same_origin();
    if (!rl_check('admin_login', 10, 600)) {
        $error = __('err_locked');
    } else {
        [$ok, $err] = attempt_login(post_email('email'), (string)($_POST['password'] ?? ''), 'admin');
        if ($ok) redirect('dashboard.php');
        $error = $err;
    }
}
?><!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(__('adm_title')) ?> · MuyaSMS</title>
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/muya.css">
</head>
<body>
<div class="bg-stage" aria-hidden="true">
  <div class="orb orb-emerald"></div><div class="orb orb-blue"></div><div class="orb orb-gold"></div><div class="grid-floor"></div>
</div>

<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;z-index:1">
  <div class="auth-card" style="max-width:430px">
    <div class="auth-brand">
      <?= muya_logo_svg(32) ?>
      <span class="brand-name" style="font-size:17px">MuyaSMS</span>
      <span class="tag tag-gold right"><?= e(__('admin_panel')) ?></span>
    </div>

    <h1 style="margin-top:20px">🛡️ <?= e(__('adm_title')) ?></h1>
    <div class="sub"><?= e(__('adm_only_hint')) ?></div>

    <?php if ($error): ?><div class="flash flash-err mb-2"><?= e($error) ?></div><?php endif; ?>

    <form method="post" action="index.php">
      <?= csrf_field() ?>
      <div class="f-group">
        <label class="f-label"><?= e(__('email')) ?></label>
        <input class="f-input f-input-lg" type="email" name="email" required autofocus autocomplete="email" placeholder="admin@muyalink.com">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('password')) ?></label>
        <input class="f-input f-input-lg" type="password" name="password" required autocomplete="current-password" placeholder="••••••••">
      </div>
      <button class="btn btn-primary btn-block" type="submit" style="padding:13px"><?= e(__('sign_in')) ?></button>
    </form>

    <div class="auth-foot"><a href="../signin.php" style="color:var(--dim)">← <?= e(__('customer_portal')) ?></a></div>
    <div class="auth-legal center">
      🔒 <?= e(__('adm_only_hint')) ?><br>
      <a href="?lang=<?= lang() === 'en' ? 'am' : 'en' ?>" style="color:var(--dim)"><?= lang() === 'en' ? '🇪🇹 አማርኛ' : '🇬🇧 English' ?></a>
    </div>
  </div>
</div>
</body>
</html>
