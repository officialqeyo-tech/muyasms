<?php
/**
 * MuyaSMS — admin: pricing & platform parameters (everything adjustable).
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_admin();

$tabs = [
    'pricing'  => '💰 ' . __('adm_pricing'),
    'telebirr' => '📲 ' . __('telebirr_settings'),
    'delivery' => '⚙️ ' . __('dispatch_settings'),
    'platform' => '🌍 ' . __('set_profile'),
];
$tab = (string)($_GET['t'] ?? 'pricing');

muya_page_start(['title' => __('nav_pricing'), 'area' => 'admin', 'active' => 'pricing']);
?>

<div class="flex mb-2" style="gap:8px;flex-wrap:wrap">
  <?php foreach ($tabs as $k => $label): ?>
  <a class="btn <?= $tab === $k ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?t=<?= $k ?>"><?= $label ?></a>
  <?php endforeach; ?>
</div>

<form onsubmit="return saveSettings(event)">
  <input type="hidden" name="tab" value="<?= e($tab) ?>">
  <?php if ($tab === 'pricing'): ?>
  <div class="card">
    <div class="card-title">💰 <?= e(__('adm_pricing')) ?></div>
    <div class="f-row">
      <div class="f-group">
        <label class="f-label"><?= e(__('price_per_sms')) ?></label>
        <input class="f-input" name="price_per_sms" value="<?= e(setting('price_per_sms', '1.00')) ?>">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('intl_mult')) ?></label>
        <input class="f-input" name="intl_credit_multiplier" value="<?= e(setting('intl_credit_multiplier', '2')) ?>">
      </div>
    </div>
    <div class="f-row">
      <div class="f-group">
        <label class="f-label"><?= e(__('signup_credits')) ?></label>
        <input class="f-input" name="signup_free_credits" value="<?= e(setting('signup_free_credits', '100')) ?>">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('min_topup')) ?></label>
        <input class="f-input" name="min_topup_etb" value="<?= e(setting('min_topup_etb', '25')) ?>">
      </div>
    </div>
    <label class="flex small" style="gap:8px;margin-bottom:10px">
      <input type="checkbox" name="bulk_requires_verification" value="1" <?= setting('bulk_requires_verification', '1') === '1' ? 'checked' : '' ?>>
      <?= e(__('bulk_verif')) ?>
    </label>
    <div class="f-group">
      <label class="f-label"><?= e(__('unverified_limit')) ?></label>
      <input class="f-input" name="unverified_recipient_limit" value="<?= e(setting('unverified_recipient_limit', '10')) ?>">
    </div>
  </div>

  <?php elseif ($tab === 'telebirr'): ?>
  <div class="card">
    <div class="card-title">📲 <?= e(__('telebirr_settings')) ?></div>
    <div class="f-row">
      <div class="f-group">
        <label class="f-label"><?= e(__('telebirr_name')) ?></label>
        <input class="f-input" name="telebirr_name" value="<?= e(setting('telebirr_name', '')) ?>">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('telebirr_account')) ?></label>
        <input class="f-input" name="telebirr_account" value="<?= e(setting('telebirr_account', '')) ?>" placeholder="+2519…">
      </div>
    </div>
    <div class="f-group">
      <label class="f-label"><?= e(__('telebirr_note')) ?></label>
      <textarea class="f-input" name="telebirr_note" rows="3"><?= e(setting('telebirr_note', '')) ?></textarea>
    </div>
    <div class="f-hint">📱 <?= e(__('telebirr_pay_to'), '…') ?></div>
  </div>

  <?php elseif ($tab === 'delivery'): ?>
  <div class="card">
    <div class="card-title">⚙️ <?= e(__('dispatch_settings')) ?></div>
    <div class="f-row">
      <div class="f-group">
        <label class="f-label"><?= e(__('batch_size')) ?></label>
        <input class="f-input" name="dispatch_batch_size" value="<?= e(setting('dispatch_batch_size', '25')) ?>">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('dispatch_interval')) ?></label>
        <input class="f-input" name="dispatch_interval_sec" value="<?= e(setting('dispatch_interval_sec', '20')) ?>">
      </div>
    </div>
    <div class="f-hint">⚡ Cron: <span class="mono">php <?= e(ROOT) ?>/cron/dispatch.php YOUR_CRON_KEY</span> (see README-DEPLOY.md)</div>
  </div>

  <?php else: ?>
  <div class="card">
    <div class="card-title">🌍 <?= e(__('set_profile')) ?></div>
    <div class="f-row">
      <div class="f-group">
        <label class="f-label"><?= e(__('platform_name')) ?></label>
        <input class="f-input" name="platform_name" value="<?= e(setting('platform_name', 'MuyaSMS')) ?>">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('adm_notify')) ?></label>
        <input class="f-input" name="admin_notify_email" value="<?= e(setting('admin_notify_email', '')) ?>">
      </div>
    </div>
    <label class="flex small" style="gap:8px;margin-bottom:10px">
      <input type="checkbox" name="email_enabled" value="1" <?= setting('email_enabled', '1') === '1' ? 'checked' : '' ?>>
      <?= e(__('email_enabled')) ?> — mail.muyalink.com:465 SSL
    </label>
    <label class="flex small" style="gap:8px">
      <input type="checkbox" name="maintenance_mode" value="1" <?= setting('maintenance_mode', '0') === '1' ? 'checked' : '' ?>>
      <?= e(__('maintenance')) ?> 🛠️
    </label>
  </div>
  <?php endif; ?>

  <button class="btn btn-primary mt-2" type="submit">💾 <?= e(__('save')) ?></button>
</form>

<script>
function saveSettings(ev) {
  ev.preventDefault();
  var form = ev.target;
  var data = { op: 'settings', tab: form.querySelector('[name=tab]').value };
  form.querySelectorAll('input:not([type=checkbox]):not([type=hidden]), textarea').forEach(function (el) { data[el.name] = el.value; });
  form.querySelectorAll('input[type=checkbox]').forEach(function (el) { data[el.name] = el.checked ? '1' : '0'; });
  window.muyaApi('../api/admin/settings.php', data).then(function () {
    window.muyaToast('<?= e(__('adm_save_settings')) ?>', 'ok');
  }).catch(function () {});
  return false;
}
</script>
<?php muya_page_end(['area' => 'admin']); ?>
