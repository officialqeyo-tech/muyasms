<?php
/**
 * MuyaSMS — admin: audit log (super-admin only).
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_super();

$actionF = (string)($_GET['a'] ?? '');
$where = '1=1';
$params = [];
if ($actionF !== '') {
    $where .= ' AND action LIKE ?';
    $params[] = $actionF . '%';
}
$logs = qall("SELECT * FROM audit_log WHERE $where ORDER BY id DESC LIMIT 300", $params);

muya_page_start(['title' => __('nav_audit'), 'area' => 'admin', 'active' => 'audit']);
?>

<div class="card">
  <div class="card-title">
    📜 <?= e(__('nav_audit')) ?>
    <form method="get" class="right" style="display:flex;gap:8px">
      <input class="f-input" name="a" value="<?= e($actionF) ?>" placeholder="<?= e(__('action')) ?>: login_ok / topup / verif…" style="padding:7px 12px;width:200px">
      <button class="btn btn-ghost btn-sm" type="submit">🔍</button>
    </form>
  </div>
  <?php if (!$logs): ?>
  <div class="empty"><div class="e-ic">📜</div><?= e(__('adm_audit_empty')) ?></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th><?= e(__('date')) ?></th><th><?= e(__('actor')) ?></th><th><?= e(__('action')) ?></th><th>Details</th><th>IP</th>
      </tr></thead>
      <tbody>
      <?php foreach ($logs as $l): ?>
      <tr>
        <td class="dim small"><?= e(fmt_dt($l['created_at'])) ?></td>
        <td class="small"><?= e($l['actor_email'] ?: ('#' . $l['user_id'])) ?></td>
        <td><span class="tag"><?= e($l['action']) ?></span></td>
        <td class="dim small"><?= e($l['details']) ?></td>
        <td class="dim small mono"><?= e($l['ip']) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php muya_page_end(['area' => 'admin']); ?>
