<?php
/**
 * MuyaSMS — admin overview dashboard (real data).
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_admin();
web_dispatch_tick();

// KPIs
$usersTotal = (int)qv('SELECT COUNT(*) FROM users');
$customers  = (int)qv('SELECT COUNT(*) FROM users WHERE role = \'customer\'');
$last24 = is_pg() ? 'NOW() - INTERVAL \'24 hours\'' : 'NOW() - INTERVAL 24 HOUR';
$msgs24     = (int)qv('SELECT COUNT(*) FROM messages WHERE created_at >= ' . $last24);
$okRate = null;
$r = qr('SELECT SUM(CASE WHEN status IN (\'sent\',\'delivered\') THEN 1 ELSE 0 END) AS ok, SUM(CASE WHEN status = \'failed\' THEN 1 ELSE 0 END) AS bad FROM messages');
if ($r && ((int)$r['ok'] + (int)$r['bad']) > 0) $okRate = round(100 * (int)$r['ok'] / ((int)$r['ok'] + (int)$r['bad']), 1);
$pendingPay = (int)qv('SELECT COUNT(*) FROM wallet_transactions WHERE status = \'pending\'');
$pendingVer = (int)qv('SELECT COUNT(*) FROM verifications WHERE status = \'pending\'');
$revenue = (float)qv('SELECT COALESCE(SUM(amount_etb),0) FROM wallet_transactions WHERE status = \'approved\' AND type = \'topup\'');

// throughput 24h
$hours = []; $labels = [];
for ($i = 23; $i >= 0; $i--) {
    $hStart = date('Y-m-d H:00:00', strtotime("-$i hour"));
    $hEnd   = date('Y-m-d H:00:00', strtotime('-' . ($i - 1) . ' hour'));
    $labels[] = date('H', strtotime($hStart));
    $hours[] = (int)qv('SELECT COUNT(*) FROM messages WHERE created_at >= ? AND created_at < ?', [$hStart, $hEnd]);
}
$okSeries = []; $badSeries = [];
for ($i = 23; $i >= 0; $i--) {
    $hStart = date('Y-m-d H:00:00', strtotime("-$i hour"));
    $hEnd   = date('Y-m-d H:00:00', strtotime('-' . ($i - 1) . ' hour'));
    $okSeries[] = (int)qv('SELECT COUNT(*) FROM messages WHERE status IN (\'sent\',\'delivered\') AND created_at >= ? AND created_at < ?', [$hStart, $hEnd]);
    $badSeries[] = (int)qv('SELECT COUNT(*) FROM messages WHERE status = \'failed\' AND created_at >= ? AND created_at < ?', [$hStart, $hEnd]);
}

$feed = qall('SELECT m.*, u.name AS uname FROM messages m LEFT JOIN users u ON u.id = m.user_id ORDER BY m.id DESC LIMIT 12');

$pendPays = qall('SELECT w.*, u.name AS uname, u.email AS uemail FROM wallet_transactions w JOIN users u ON u.id = w.user_id WHERE w.status = \'pending\' ORDER BY w.id ASC LIMIT 10');
$pendVers = qall('SELECT v.*, u.name AS uname, u.email AS uemail FROM verifications v JOIN users u ON u.id = v.user_id WHERE v.status = \'pending\' ORDER BY v.id ASC LIMIT 10');

muya_page_start(['title' => __('adm_overview_title'), 'area' => 'admin', 'active' => 'dashboard']);
?>

<div class="stat-grid">
  <div class="card card-3d stat-card stat-b" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('users') ?></div>
    <div class="stat-label"><?= e(__('adm_users_total')) ?></div>
    <div class="stat-value" data-count="<?= $usersTotal ?>">0</div>
    <div class="stat-sub"><?= e(__('adm_customers')) ?>: <?= $customers ?></div>
  </div>
  <div class="card card-3d stat-card stat-e" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('send') ?></div>
    <div class="stat-label"><?= e(__('adm_msgs_24')) ?></div>
    <div class="stat-value" data-count="<?= $msgs24 ?>">0</div>
    <div class="stat-sub"><?= e(__('adm_success_rate')) ?>: <?= $okRate === null ? '—' : $okRate . '%' ?></div>
  </div>
  <div class="card card-3d stat-card stat-g" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('cash') ?></div>
    <div class="stat-label"><?= e(__('adm_revenue')) ?></div>
    <div class="stat-value" data-count="<?= $revenue ?>" data-decimals="2">0</div>
    <div class="stat-sub">ETB · telebirr</div>
  </div>
  <div class="card card-3d stat-card stat-o" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('clock') ?></div>
    <div class="stat-label"><?= e(__('adm_pending_actions')) ?></div>
    <div class="stat-value"><span data-count="<?= $pendingPay ?>">0</span> + <span data-count="<?= $pendingVer ?>">0</span></div>
    <div class="stat-sub"><?= e(__('adm_pending_pay')) ?> / <?= e(__('adm_pending_ver')) ?></div>
  </div>
</div>

<div class="mt-2 grid-2-1">
  <div class="card">
    <div class="card-title">📈 <?= e(__('dash_chart')) ?></div>
    <div class="chart-box"><canvas id="throughputChart"></canvas></div>
  </div>
  <div class="card">
    <div class="card-title">⚡ <?= e(__('adm_feed')) ?></div>
    <?php if (!$feed): ?>
    <div class="empty" style="padding:26px"><div class="e-ic">📭</div><?= e(__('no_data')) ?></div>
    <?php else: ?>
    <div style="display:flex;flex-direction:column;gap:8px">
      <?php foreach ($feed as $m): ?>
      <div class="flex" style="padding:9px 11px;border:1px solid var(--border);border-radius:11px;background:rgba(22,30,46,.5)">
        <span class="mono small" style="min-width:104px"><?= e($m['recipient']) ?></span>
        <?= status_badge($m['status']) ?>
        <span class="small dim right" title="<?= e($m['uname'] ?? '') ?>"><?= e(time_ago($m['created_at'])) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($pendPays || $pendVers): ?>
<div class="mt-2 grid-2">
  <div class="card">
    <div class="card-title">💳 <?= e(__('adm_pending_pay')) ?> <span class="tag tag-gold"><?= $pendingPay ?></span></div>
    <?php foreach ($pendPays as $p): ?>
    <div class="flex-between" style="padding:10px 12px;border:1px solid rgba(245,158,11,.3);border-radius:12px;margin-bottom:8px;background:rgba(245,158,11,.05)">
      <div>
        <b><?= e(money_etb((float)$p['amount_etb'])) ?></b>
        <div class="small dim mono"><?= e($p['txn_ref']) ?></div>
        <div class="small dim"><?= e($p['uname']) ?> · <?= e($p['uemail']) ?></div>
      </div>
      <div class="flex" style="gap:6px">
        <button class="btn btn-green btn-sm" onclick="payAction(<?= (int)$p['id'] ?>, 'approve')">✔ <?= e(__('adm_approve')) ?></button>
        <button class="btn btn-danger btn-sm" onclick="payAction(<?= (int)$p['id'] ?>, 'reject')">✕</button>
      </div>
    </div>
    <?php endforeach; ?>
    <a class="btn btn-ghost btn-sm btn-block" href="payments.php"><?= e(__('view_all')) ?> →</a>
  </div>
  <div class="card">
    <div class="card-title">🛡️ <?= e(__('adm_pending_ver')) ?> <span class="tag tag-gold"><?= $pendingVer ?></span></div>
    <?php foreach ($pendVers as $v): ?>
    <div class="flex-between" style="padding:10px 12px;border:1px solid var(--border);border-radius:12px;margin-bottom:8px;background:rgba(22,30,46,.5)">
      <div>
        <b><?= e($v['company_name']) ?></b>
        <div class="small dim"><?= e($v['uname']) ?> · <?= e($v['uemail']) ?></div>
      </div>
      <div class="flex" style="gap:6px">
        <a class="btn btn-ghost btn-sm" href="../files.php?id=<?= (int)$v['id'] ?>" target="_blank">📄</a>
        <button class="btn btn-green btn-sm" onclick="verAction(<?= (int)$v['id'] ?>, 'approve')">✔</button>
        <button class="btn btn-danger btn-sm" onclick="verAction(<?= (int)$v['id'] ?>, 'reject')">✕</button>
      </div>
    </div>
    <?php endforeach; ?>
    <a class="btn btn-ghost btn-sm btn-block" href="verifications.php"><?= e(__('view_all')) ?> →</a>
  </div>
</div>
<?php endif; ?>

<script>
function payAction(id, act) {
  if (act === 'reject' && !prompt('<?= e(__('adm_note')) ?>', '')) return;
  window.muyaApi('../api/admin/payments.php', { op: act, id: id }).then(function () { location.reload(); }).catch(function () {});
}
function verAction(id, act) {
  if (act === 'reject' && !prompt('<?= e(__('adm_note')) ?>', '')) return;
  window.muyaApi('../api/admin/verifications.php', { op: act, id: id }).then(function () { location.reload(); }).catch(function () {});
}
window.addEventListener('DOMContentLoaded', function () {
  window.muyaCharts.line(document.getElementById('throughputChart'), [
    { color: '#10B981', data: <?= json_encode($okSeries) ?> },
    { color: '#EF4444', data: <?= json_encode($badSeries) ?> }
  ], { labels: <?= json_encode($labels) ?> });
});
</script>
<?php muya_page_end(['area' => 'admin']); ?>
