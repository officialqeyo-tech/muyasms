<?php
/**
 * MuyaSMS — admin: users management.
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_admin();

$q = trim((string)($_GET['q'] ?? ''));
$roleF = (string)($_GET['role'] ?? '');
$where = '1=1';
$params = [];
if ($q !== '') {
    $where .= ' AND (name LIKE ? OR email LIKE ? OR company_name LIKE ?)';
    $like = "%$q%";
    array_push($params, $like, $like, $like);
}
if (in_array($roleF, ['customer', 'admin', 'staff'], true)) {
    $where .= ' AND role = ?';
    $params[] = $roleF;
}
$users = qall("SELECT * FROM users WHERE $where ORDER BY id DESC LIMIT 300", $params);

muya_page_start(['title' => __('nav_users'), 'area' => 'admin', 'active' => 'users']);
?>

<div class="card">
  <div class="card-title">
    👥 <?= e(__('adm_users')) ?> <span class="tsub"><?= count($users) ?></span>
    <form method="get" class="right" style="display:flex;gap:8px">
      <input class="f-input" name="q" value="<?= e($q) ?>" placeholder="<?= e(__('search')) ?>" style="padding:7px 12px;width:190px">
      <select class="f-input" name="role" style="padding:7px 32px 7px 10px;width:auto">
        <option value=""><?= e(__('role')) ?>: *</option>
        <option value="customer" <?= $roleF === 'customer' ? 'selected' : '' ?>>customer</option>
        <option value="staff" <?= $roleF === 'staff' ? 'selected' : '' ?>>staff</option>
        <option value="admin" <?= $roleF === 'admin' ? 'selected' : '' ?>>admin</option>
      </select>
      <button class="btn btn-ghost btn-sm" type="submit">🔍</button>
    </form>
  </div>

  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th><?= e(__('user')) ?></th><th><?= e(__('role')) ?></th><th><?= e(__('credits')) ?></th>
        <th><?= e(__('nav_verification')) ?></th><th><?= e(__('status')) ?></th><th><?= e(__('date')) ?></th><th><?= e(__('actions')) ?></th>
      </tr></thead>
      <tbody>
      <?php foreach ($users as $usr): ?>
      <tr>
        <td>
          <b><?= e($usr['name']) ?></b>
          <div class="dim small"><?= e($usr['email']) ?></div>
          <?php if ($usr['phone']): ?><div class="dim small mono"><?= e($usr['phone']) ?></div><?php endif; ?>
        </td>
        <td><span class="tag <?= $usr['role'] === 'admin' ? 'tag-gold' : '' ?>"><?= e($usr['role']) ?></span></td>
        <td style="font-weight:700;color:var(--gold)"><?= number_format((int)$usr['credits']) ?></td>
        <td><?= (int)$usr['company_verified'] === 1 ? '<span class="badge badge-green">✓</span>' : '<span class="badge badge-gray">—</span>' ?></td>
        <td><?= status_badge($usr['status']) ?></td>
        <td class="dim small"><?= e(fmt_dt($usr['created_at'])) ?><div class="dim small">IP <?= e($usr['last_ip'] ?: '—') ?></div></td>
        <td>
          <div class="flex" style="gap:5px">
            <button class="btn btn-ghost btn-sm" title="<?= e(__('adjust_credits')) ?>" onclick="adjustCredits(<?= (int)$usr['id'] ?>, <?= (int)$usr['credits'] ?>)">±</button>
            <?php if ($usr['role'] === 'customer'): ?>
              <?php if ($usr['status'] === 'suspended'): ?>
              <button class="btn btn-green btn-sm" onclick="setStatus(<?= (int)$usr['id'] ?>, 'activate')">▶</button>
              <?php elseif ($usr['status'] === 'active'): ?>
              <button class="btn btn-danger btn-sm" onclick="setStatus(<?= (int)$usr['id'] ?>, 'suspend')">⏸</button>
              <?php endif; ?>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function adjustCredits(id, current) {
  var v = prompt('<?= e(__('credits_delta')) ?> (current: ' + current + ')', '+');
  if (v === null) return;
  window.muyaApi('../api/admin/users.php', { op: 'credits', id: id, delta: v }).then(function () {
    window.muyaToast('<?= e(__('adm_credits_set')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 700);
  }).catch(function () {});
}
function setStatus(id, act) {
  if (!window.muyaConfirm()) return;
  window.muyaApi('../api/admin/users.php', { op: act, id: id }).then(function () {
    window.muyaToast('<?= e(__('adm_user_status')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 700);
  }).catch(function () {});
}
</script>
<?php muya_page_end(['area' => 'admin']); ?>
