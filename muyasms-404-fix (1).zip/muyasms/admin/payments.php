<?php
/**
 * MuyaSMS — admin: telebirr payment approvals.
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_admin();

$tab = (string)($_GET['tab'] ?? 'pending');
$where = $tab === 'history' ? 'w.status IN (\'approved\',\'rejected\')' : 'w.status = \'pending\'';
$payments = qall("SELECT w.*, u.name AS uname, u.email AS uemail FROM wallet_transactions w JOIN users u ON u.id = w.user_id WHERE $where ORDER BY w.id DESC LIMIT 200");
$price = (float)setting('price_per_sms', 1);

muya_page_start(['title' => __('nav_payments'), 'area' => 'admin', 'active' => 'payments']);
?>

<div class="flex mb-2" style="gap:8px">
  <a class="btn <?= $tab === 'pending' ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?tab=pending"><?= e(__('st_pending')) ?></a>
  <a class="btn <?= $tab === 'history' ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?tab=history"><?= e(__('ledger')) ?></a>
</div>

<div class="card">
  <?php if (!$payments): ?>
  <div class="empty"><div class="e-ic">💳</div><?= e(__('no_data')) ?></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th><?= e(__('user')) ?></th><th><?= e(__('amount')) ?></th><th><?= e(__('txn_ref')) ?></th>
        <th><?= e(__('credits_granted')) ?></th><th><?= e(__('status')) ?></th><th><?= e(__('date')) ?></th><th><?= e(__('actions')) ?></th>
      </tr></thead>
      <tbody>
      <?php foreach ($payments as $p): ?>
      <tr>
        <td><b><?= e($p['uname']) ?></b><div class="dim small"><?= e($p['uemail']) ?></div></td>
        <td style="font-weight:700"><?= e(money_etb((float)$p['amount_etb'])) ?></td>
        <td class="mono small"><?= e($p['txn_ref'] ?: '—') ?></td>
        <td><?= $p['status'] === 'approved' ? number_format((int)$p['credits']) : '<span class="dim">≈ ' . number_format((int)floor((float)$p['amount_etb'] / $price)) . '</span>' ?></td>
        <td><?= status_badge($p['status']) ?>
          <?php if ($p['note']): ?><div class="dim small"><?= e($p['note']) ?></div><?php endif; ?>
        </td>
        <td class="dim small"><?= e(fmt_dt($p['created_at'])) ?></td>
        <td>
          <?php if ($p['status'] === 'pending'): ?>
          <div class="flex" style="gap:6px">
            <button class="btn btn-green btn-sm" onclick="payAction(<?= (int)$p['id'] ?>, 'approve', false)">✔ <?= e(__('adm_approve')) ?></button>
            <button class="btn btn-danger btn-sm" onclick="payAction(<?= (int)$p['id'] ?>, 'reject', true)">✕ <?= e(__('adm_reject')) ?></button>
          </div>
          <?php else: ?>
          <span class="dim small"><?= e(fmt_dt($p['reviewed_at'])) ?></span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card mt-2">
  <div class="small dim">
    ℹ️ <?= e(__('waiting_approval_d')) ?>
    <br>📱 telebirr: <b><?= e(setting('telebirr_name', '')) ?></b> <?= e(setting('telebirr_account', '')) ?> — <a href="pricing.php" style="color:var(--gold)"><?= e(__('telebirr_settings')) ?> →</a>
  </div>
</div>

<script>
function payAction(id, act, askNote) {
  var note = '';
  if (askNote) {
    note = prompt('<?= e(__('adm_note')) ?>', '') || '';
    if (note === '') return;
  }
  window.muyaApi('../api/admin/payments.php', { op: act, id: id, note: note }).then(function (j) {
    window.muyaToast(j.msg || '✓', 'ok');
    setTimeout(function () { location.reload(); }, 800);
  }).catch(function () {});
}
</script>
<?php muya_page_end(['area' => 'admin']); ?>
