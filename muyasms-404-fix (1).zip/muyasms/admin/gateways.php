<?php
/**
 * MuyaSMS — admin: SMS gateways (full control of every connection parameter).
 */
require __DIR__ . '/../includes/bootstrap.php';
$admin = require_admin();

$gws = qall('SELECT * FROM gateways ORDER BY is_default DESC, priority ASC, id ASC');

muya_page_start(['title' => __('nav_gateways'), 'area' => 'admin', 'active' => 'gateways']);
?>

<div class="flex mb-2" style="justify-content:space-between">
  <div class="small dim">⚙️ <?= e(__('feat_gateway_d')) ?></div>
  <button class="btn btn-primary btn-sm" onclick="openGw(null)">+ <?= e(__('gw_add')) ?></button>
</div>

<?php if (!$gws): ?>
<div class="card"><div class="empty"><div class="e-ic">⚡</div><?= e(__('gw_no_gateways')) ?></div></div>
<?php else: ?>
<div class="grid-2">
<?php foreach ($gws as $gw): ?>
  <div class="card card-3d <?= $gw['status'] === 'active' ? 'card-glow-e' : '' ?>" data-tilt="4">
    <div class="flex-between mb-1">
      <b style="font-size:15px">⚡ <?= e($gw['name']) ?></b>
      <div class="flex" style="gap:6px">
        <?php if ((int)$gw['is_default'] === 1): ?><span class="tag tag-gold"><?= e(__('gw_default')) ?></span><?php endif; ?>
        <?= status_badge($gw['status']) ?>
      </div>
    </div>
    <div class="kv"><span class="k"><?= e(__('gw_url')) ?></span><span class="v mono small"><?= e(mb_substr($gw['api_url'], 0, 40)) ?>…</span></div>
    <div class="kv"><span class="k"><?= e(__('gw_sender')) ?></span><span class="v"><?= e($gw['sender_id'] ?: '—') ?></span></div>
    <div class="kv"><span class="k"><?= e(__('gw_rps')) ?></span><span class="v"><?= (int)$gw['max_per_second'] ?>/s</span></div>
    <div class="kv"><span class="k"><?= e(__('gw_timeout')) ?>/<?= e(__('gw_retries')) ?></span><span class="v"><?= (int)$gw['timeout_sec'] ?>s / <?= (int)$gw['retries'] ?></span></div>
    <div class="kv"><span class="k"><?= e(__('gw_priority')) ?></span><span class="v"><?= (int)$gw['priority'] ?></span></div>
    <div class="flex mt-2" style="gap:6px;flex-wrap:wrap">
      <button class="btn btn-ghost btn-sm" onclick="openGw(<?= (int)$gw['id'] ?>)">✎ <?= e(__('edit')) ?></button>
      <button class="btn btn-gold btn-sm" onclick="testGw(<?= (int)$gw['id'] ?>)">📡 <?= e(__('gw_test')) ?></button>
      <button class="btn <?= $gw['status'] === 'active' ? 'btn-danger' : 'btn-green' ?> btn-sm" onclick="toggleGw(<?= (int)$gw['id'] ?>)">
        <?= $gw['status'] === 'active' ? '⏸' : '▶' ?>
      </button>
      <?php if ((int)$gw['is_default'] !== 1): ?>
      <button class="btn btn-ghost btn-sm" onclick="setDefault(<?= (int)$gw['id'] ?>)">★</button>
      <button class="btn btn-danger btn-sm" onclick="delGw(<?= (int)$gw['id'] ?>)">🗑</button>
      <?php endif; ?>
    </div>
  </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<script>
var GWS = <?= json_encode(array_map(function ($g) {
    return [
        'id' => (int)$g['id'], 'name' => $g['name'], 'api_url' => $g['api_url'],
        'http_method' => $g['http_method'], 'headers_json' => (string)$g['headers_json'],
        'body_template' => (string)$g['body_template'], 'sender_id' => (string)$g['sender_id'],
        'success_condition' => (string)$g['success_condition'], 'delivered_condition' => (string)$g['delivered_condition'],
        'id_regex' => (string)$g['id_regex'], 'timeout_sec' => (int)$g['timeout_sec'],
        'retries' => (int)$g['retries'], 'max_per_second' => (int)$g['max_per_second'],
        'priority' => (int)$g['priority'], 'is_default' => (int)$g['is_default'],
    ];
}, $gws), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;

function gwById(id) { return GWS.find(function (g) { return g.id === id; }); }

function openGw(id) {
  var g = id ? gwById(id) : {
    id: 0, name: '', api_url: 'https://', http_method: 'POST',
    headers_json: '{"Authorization":"Bearer YOUR_KEY"}',
    body_template: '{"to":"{{recipient}}","from":"{{sender}}","message":"{{message}}"}',
    sender_id: '', success_condition: '', delivered_condition: '', id_regex: '',
    timeout_sec: 15, retries: 2, max_per_second: 5, priority: 100, is_default: 0
  };
  var m = window.muyaModal(
    '<h3>' + (id ? '<?= e(__('gw_edit')) ?>' : '<?= e(__('gw_add')) ?>') + '</h3>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_name')) ?></label><input class="f-input" id="gwName" value="' + (g.name || '').replace(/"/g, '&quot;') + '"></div>' +
    '<div class="f-row"><div class="f-group"><label class="f-label"><?= e(__('gw_url')) ?></label><input class="f-input" id="gwUrl" value="' + g.api_url.replace(/"/g, '&quot;') + '"></div>' +
    '<div class="f-group" style="max-width:120px"><label class="f-label"><?= e(__('gw_method')) ?></label><select class="f-input" id="gwMethod"><option' + (g.http_method === 'POST' ? ' selected' : '') + '>POST</option><option' + (g.http_method === 'GET' ? ' selected' : '') + '>GET</option></select></div></div>' +
    '<div class="f-row"><div class="f-group"><label class="f-label"><?= e(__('gw_sender')) ?></label><input class="f-input" id="gwSender" value="' + (g.sender_id || '').replace(/"/g, '&quot;') + '"></div>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_success_cond')) ?></label><input class="f-input" id="gwOk" value="' + (g.success_condition || '').replace(/"/g, '&quot;') + '"><div class="f-hint"><?= e(__('gw_success_cond_h')) ?></div></div></div>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_headers')) ?></label><textarea class="f-input mono" id="gwHeaders" rows="3">' + (g.headers_json || '') + '</textarea></div>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_body')) ?></label><textarea class="f-input mono" id="gwBody" rows="4">' + (g.body_template || '') + '</textarea><div class="f-hint">{{recipient}} {{message}} {{sender}} {{timestamp}}</div></div>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_delivered_cond')) ?></label><input class="f-input" id="gwDeliv" value="' + (g.delivered_condition || '').replace(/"/g, '&quot;') + '"><div class="f-hint"><?= e(__('gw_delivered_cond_h')) ?></div></div>' +
    '<div class="f-row">' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_timeout')) ?></label><input class="f-input" type="number" id="gwTimeout" value="' + g.timeout_sec + '"></div>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_retries')) ?></label><input class="f-input" type="number" id="gwRetries" value="' + g.retries + '"></div>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_rps')) ?></label><input class="f-input" type="number" id="gwRps" value="' + g.max_per_second + '"></div>' +
    '<div class="f-group"><label class="f-label"><?= e(__('gw_priority')) ?></label><input class="f-input" type="number" id="gwPrio" value="' + g.priority + '"></div>' +
    '</div>' +
    '<label class="flex small" style="gap:8px"><input type="checkbox" id="gwDefault"' + (g.is_default ? ' checked' : '') + '> <?= e(__('gw_default')) ?></label>' +
    '<div class="flex mt-2" style="gap:8px"><button class="btn btn-primary btn-block" onclick="saveGw(' + (id || 0) + ')"><?= e(__('save')) ?></button></div>',
    true
  );
  m.dataset.gwid = id || 0;
}

function saveGw(id) {
  window.muyaApi('../api/admin/gateways.php', {
    op: 'save',
    id: id,
    name: document.getElementById('gwName').value,
    api_url: document.getElementById('gwUrl').value,
    http_method: document.getElementById('gwMethod').value,
    sender_id: document.getElementById('gwSender').value,
    headers_json: document.getElementById('gwHeaders').value,
    body_template: document.getElementById('gwBody').value,
    success_condition: document.getElementById('gwOk').value,
    delivered_condition: document.getElementById('gwDeliv').value,
    timeout_sec: document.getElementById('gwTimeout').value,
    retries: document.getElementById('gwRetries').value,
    max_per_second: document.getElementById('gwRps').value,
    priority: document.getElementById('gwPrio').value,
    is_default: document.getElementById('gwDefault').checked ? 1 : 0
  }).then(function () {
    window.muyaToast('<?= e(__('gw_saved')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 700);
  }).catch(function () {});
}

function testGw(id) {
  var phone = prompt('<?= e(__('gw_test_phone')) ?> (09… or +2519…)', '+251911000000');
  if (!phone) return;
  window.muyaApi('../api/admin/gateways.php', { op: 'test', id: id, phone: phone }).then(function (j) {
    window.muyaModal('<h3><?= e(__('gw_test')) ?></h3>' +
      (j.ok_gw ? '<div class="flash flash-ok"><?= e(__('gw_test_ok')) ?></div>' : '<div class="flash flash-err"><?= e(__('gw_test_fail')) ?></div>') +
      '<div class="code-block mt-2" style="max-height:260px;overflow:auto">' + (j.response || '—') + '</div>' +
      '<button class="btn btn-ghost btn-block mt-2" data-close><?= e(__('close')) ?></button>', true);
  }).catch(function () {});
}

function toggleGw(id) {
  window.muyaApi('../api/admin/gateways.php', { op: 'toggle', id: id }).then(function () { location.reload(); }).catch(function () {});
}
function setDefault(id) {
  window.muyaApi('../api/admin/gateways.php', { op: 'default', id: id }).then(function () { location.reload(); }).catch(function () {});
}
function delGw(id) {
  if (!window.muyaConfirm()) return;
  window.muyaApi('../api/admin/gateways.php', { op: 'delete', id: id }).then(function () { location.reload(); }).catch(function () {});
}
</script>
<?php muya_page_end(['area' => 'admin']); ?>
