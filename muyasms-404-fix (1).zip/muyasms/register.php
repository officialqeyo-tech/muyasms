<?php
/**
 * MuyaSMS — customer registration (v2 — INSTANT account).
 *
 * Form: Full name, Email, Phone, Company (optional), Password.
 * On submit:
 *   1. Account is created ACTIVE immediately (no admin approval).
 *   2. Signup bonus credits are added right away — the customer can
 *      sign in and use the platform straight away.
 *   3. A welcome email with a verification link is sent (verification
 *      confirms the address; it never blocks the account).
 *   4. The new customer is signed in automatically → dashboard.
 */
require __DIR__ . '/includes/bootstrap.php';

if (current_user()) redirect('app/index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    require_same_origin();
    if (!rl_check('register', 5, 3600)) {
        $error = __('err_locked');
    } elseif ((string)($_POST['password'] ?? '') !== (string)($_POST['password2'] ?? '')) {
        $error = __('err_password_mismatch');
    } else {
        [$ok, $tokenOrErr] = register_user(
            post_str('name', 120),
            post_email('email'),
            post_str('phone', 32),
            post_str('company', 190),
            (string)($_POST['password'] ?? '')
        );
        if ($ok) {
            $u = qr('SELECT * FROM users WHERE email = ?', [strtolower(trim(post_email('email')))]);
            $bonus = (int)setting('signup_free_credits', 100);

            // ---- welcome email (includes the verification link) ----
            $verifyUrl = base_url('/verify.php?token=' . $tokenOrErr);
            $html = email_template(
                'Welcome to MuyaSMS — your account is active 🎉',
                'እንኳን ወደ MuyaSMS ደህና መጡ — መለያዎ ንቁ ሆኗል 🎉',
                '<p>Welcome aboard, <b>' . e($u['name']) . '</b>!</p>'
                    . '<p>Your account is <b>active right now</b> — no approval needed. We added <b>' . $bonus . ' free SMS credits</b> to your wallet so you can try the platform immediately.</p>'
                    . '<p>You sign in with <b>your email or your phone number</b> + your password.</p>'
                    . '<p>One last thing: tap the button below to <b>confirm your email address</b> (the link expires in 24 hours). Confirming keeps your account secure and lets our team reach you about payments.</p>',
                '<p>እንኳን ደህና መጡ <b>' . e($u['name']) . '</b>!</p>'
                    . '<p>መለያዎ <b>አሁኑኑ ንቁ ሆኗል</b> — ምንም ማጽደቅ አያስፈልግም። <b>' . $bonus . ' ነጻ የኤስኤምኤስ ክሬዲቶች</b> ተጨምረውልዎታል።</p>'
                    . '<p>በ<b>ኢሜይልዎ ወይም በስልክ ቁጥርዎ</b> እና በይለፍ ቃልዎ ይግቡ።</p>'
                    . '<p>ከዚህ በታች ያለውን አዝራር ይንኩት <b>ኢሜይልዎን ለማረጋገጥ</b> (አገናኙ በ24 ሰዓታት ውስጥ ይያባል)።</p>',
                $verifyUrl,
                'Confirm my email / ኢሜይል ያረጋግጡ'
            );
            [$mailOk] = muya_mail($u['email'], 'MuyaSMS — Welcome! Your account is active / መለያዎ ንቁ ሆኗል', $html);
            if (!$mailOk) {
                notify_admin('MuyaSMS — welcome email failed', '<p>Welcome mail failed for ' . e($u['email']) . '. Check SMTP settings / storage/php-error.log</p>');
            }
            audit('register_ok', $u['email']);

            // ---- sign the customer in RIGHT NOW ----
            force_sign_in((int)$u['id']);
            flash_set('ok', sprintf(__('welcome_flash'), $bonus));
            redirect('app/index.php');
        } else {
            $error = $tokenOrErr;
        }
    }
}
?><!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(__('register')) ?> · MuyaSMS</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/muya.css">
</head>
<body>
<div class="bg-stage" aria-hidden="true">
  <div class="orb orb-emerald"></div><div class="orb orb-blue"></div><div class="orb orb-gold"></div><div class="grid-floor"></div>
</div>

<div class="auth-shell">
  <div class="auth-hero">
    <div class="flex" style="gap:12px"><?= muya_logo_svg(40) ?><span class="brand-name" style="font-size:22px">MuyaSMS</span></div>
    <h2 class="mt-3"><?= e(__('hero_title')) ?></h2>
    <p><?= e(__('hero_free')) ?></p>
    <div class="feature-grid">
      <div class="feature"><div class="f-ic" style="color:var(--emerald)"><?= muya_icon('send') ?></div><h4><?= e(__('feat_bulk_t')) ?></h4><p><?= e(__('feat_bulk_d')) ?></p></div>
      <div class="feature"><div class="f-ic" style="color:var(--gold)"><?= muya_icon('card') ?></div><h4><?= e(__('feat_pay_t')) ?></h4><p><?= e(__('feat_pay_d')) ?></p></div>
      <div class="feature"><div class="f-ic" style="color:var(--blue)"><?= muya_icon('zap') ?></div><h4><?= e(__('feat_auto_t')) ?></h4><p><?= e(__('feat_auto_d')) ?></p></div>
      <div class="feature"><div class="f-ic" style="color:var(--orange)"><?= muya_icon('shield') ?></div><h4><?= e(__('feat_ver_t')) ?></h4><p><?= e(__('feat_ver_d')) ?></p></div>
    </div>
  </div>

  <div class="auth-panel">
    <div class="auth-card">
      <a class="auth-brand" href="index.php"><?= muya_logo_svg(32) ?><span class="brand-name" style="font-size:17px">MuyaSMS</span></a>
      <h1><?= e(__('register_title')) ?></h1>
      <div class="sub"><?= e(__('register_sub')) ?></div>

      <?php if ($error): ?><div class="flash flash-err mb-2"><?= e($error) ?></div><?php endif; ?>

      <form method="post" action="register.php">
        <?= csrf_field() ?>
        <div class="f-group">
          <label class="f-label" for="name"><?= e(__('full_name')) ?></label>
          <input class="f-input f-input-lg" type="text" id="name" name="name" required autofocus value="<?= e(post_str('name', 120)) ?>" placeholder="Abebe Kebede">
        </div>
        <div class="f-row">
          <div class="f-group">
            <label class="f-label" for="email"><?= e(__('email')) ?></label>
            <input class="f-input" type="email" id="email" name="email" required value="<?= e(post_email('email')) ?>" placeholder="you@company.com">
          </div>
          <div class="f-group">
            <label class="f-label" for="phone"><?= e(__('phone')) ?></label>
            <input class="f-input" type="tel" id="phone" name="phone" required value="<?= e(post_str('phone', 32)) ?>" placeholder="09… / +2519…">
          </div>
        </div>
        <div class="f-group">
          <label class="f-label" for="company"><?= e(__('company')) ?> <span class="dim">(<?= e(__('optional')) ?>)</span></label>
          <input class="f-input" type="text" id="company" name="company" value="<?= e(post_str('company', 190)) ?>" placeholder="<?= e(__('company_ph')) ?>">
        </div>
        <div class="f-group">
          <label class="f-label" for="password"><?= e(__('password')) ?></label>
          <input class="f-input f-input-lg" type="password" id="password" name="password" required minlength="8" placeholder="8+ chars, letters & numbers">
        </div>
        <div class="f-group">
          <label class="f-label" for="password2"><?= e(__('password_confirm')) ?></label>
          <input class="f-input f-input-lg" type="password" id="password2" name="password2" required minlength="8">
        </div>
        <button class="btn btn-primary btn-block" type="submit" style="padding:13px"><?= e(__('sign_up')) ?></button>
      </form>
      <p class="auth-legal"><?= e(__('terms_note')) ?></p>
      <div class="auth-foot" style="display:flex;justify-content:space-between">
        <a href="signin.php"><?= e(__('have_account')) ?></a>
        <a href="?lang=<?= lang() === 'en' ? 'am' : 'en' ?>" style="color:var(--dim)"><?= lang() === 'en' ? '🇪🇹 አማርኛ' : '🇬🇧 English' ?></a>
      </div>
    </div>
  </div>
</div>
</body>
</html>
