# MuyaSMS — Security Implementation (SECURITY.md)

Every control below is implemented in the shipped code — no extensions required.

## Authentication & sessions
- Passwords hashed with **bcrypt** (`password_hash` / `password_verify`), cost 12 default
- Sessions: **HttpOnly + SameSite=Lax + Secure** (auto on HTTPS) cookies, **session fingerprint**
  (UA-bound hash, mismatch ⇒ session destroyed), ID **regenerated on login** and password change
- Idle timeout 60 min · absolute session lifetime 12 h
- Login brute-force: **5 failed attempts ⇒ 15 min account lock** + IP rate limit
  (12 attempts / 10 min on portal, 10 / 10 min on admin panel)
- **Email verification mandatory** before any login (accounts stay `pending` until the
  single-use, 24 h, SHA-256-hashed email token is consumed)
- Password reset: single-use, 1 h, hashed tokens; anti user-enumeration (same response
  whether or not the email exists)
- **Admin panel (`/admin/`) accepts administrator accounts only** — customer emails are
  rejected with an explicit message and the attempt is written to the audit log

## Web vulnerabilities
- **SQL injection:** 100 % PDO prepared statements, no string-built SQL with user input
- **XSS:** every dynamic output passes through `e()` (`htmlspecialchars`, ENT_QUOTES, UTF-8);
  CSP response header as second layer
- **CSRF:** per-session token enforced on **every** POST (form field, `X-CSRF-Token` header,
  or JSON body) with `hash_equals` timing-safe comparison + same-origin check
- **Path traversal:** verification documents resolved with `realpath()` and jailed to
  `uploads/verify/`; served only via `files.php` (admin session required)
- **Clickjacking:** `X-Frame-Options: DENY` + `frame-ancestors 'none'` in CSP
- **MIME confusion:** `X-Content-Type-Options: nosniff` everywhere
- **Referrer leakage:** `Referrer-Policy: strict-origin-when-cross-origin`

## File uploads (enterprise verification)
- Extension whitelist (PDF/JPG/PNG) **+ real MIME sniffing** (`finfo`)
- 5 MB size cap, PHP-source detection, **random stored filenames**
- Stored in `uploads/verify/` protected by `.htaccess` (deny-all + `RemoveHandler` for every
  script type + PHP engine off) — direct URL access is impossible; docs stream only through
  the authenticated `files.php` endpoint and every view is audited

## Server hardening (.htaccess)
- Directory listing disabled, server signature off
- Web access denied to `config/` (DB + SMTP credentials), `includes/`, `lang/`, `storage/`,
  `cron/`, `uploads/`, `firebase/` — each has its own deny-all `.htaccess` **plus** root-level
  `RedirectMatch` fallback in case `AllowOverride` is restricted
- `config.php` is additionally blocked by name at root level (defense in depth if PHP ever fails)
- Dotfiles, `*.sql`, `*.gz`, `*.zip`, `*.log`, `*.lock`, `*.sample`, `*.md`, `*.rules`,
  `*.ini`, `*.bak`, `*.env`, `*.json` blocked from web access
- HTTPS forced via 301 (with ACME challenge exemption)
- `install.php` is CSRF-protected, self-locks (`storage/installed.lock`) after creating the
  super-admin — delete it anyway. It rewrites **only** the DB lines of config.php when fixing
  the connection, and never displays a saved password after writing it

## Payments (telebirr)
- Manual approval model — credits are **never granted automatically**; a human admin verifies
  the transaction ID against the real telebirr balance before approval
- Transaction IDs unique; max 3 pending submissions per user; every action audited

## Delivery engine
- Gateways call only admin-configured URLs over **TLS with certificate verification**
  (`SSL_VERIFYPEER` on), redirects disabled, bounded timeouts
- Admin-supplied JSON is validated before save; regex validated; per-gateway rate limit
- Failures retried a bounded number of times, then marked failed with a reason (visible to the user)

## API (v1)
- `Authorization: Bearer muya_…` — keys stored **SHA-256 hashed** (a DB leak does not leak keys)
- 60 requests/minute per key (429 + `Retry-After`), same verification + wallet rules as the UI
- CORS enabled for the send endpoint only; no cookies involved

## Rate limiting & audit
- File-based limiter per scope+IP (login, register, reset, API, admin login, key regen)
- **Audit log** (super-admin view, 180-day retention): logins (ok/fail/lock/denied),
  registrations, email verifications, password changes/resets, top-ups (submit/approve/reject),
  verifications (submit/approve/reject/doc views), credits adjustments, user suspend/activate,
  staff creation, gateway CRUD + tests, settings changes, campaign launches, API sends —
  each entry with actor, details and IP

## Email (SMTP)
- Direct socket SMTP with **SSL certificate verification** to `mail.muyalink.com:465`
  (AUTH LOGIN), base64 MIME, UTF-8 bilingual bodies
- Failures logged to `storage/php-error.log` (never displayed to users) and reported to the
  admin notification address; `display_errors` always off in production

## Recommended extras (host-side)
1. cPanel **IP blocker** on `/admin/` if you always work from known IPs
2. Enable cPanel **ModSecurity** (it is on by default on most hosts)
3. Keep `APP_DEBUG false` (default)
4. Rotate `CRON_KEY` and the SMS-provider API keys quarterly

## Credential handling (privacy)
- The DB and SMTP passwords ship **only** inside `config/config.php` (pre-configured) —
  never in the UI, never in emails, never in error messages, never in this package's docs
- The installer's quick-fix form masks the password field and redirects immediately after
  saving (no value is re-rendered); PDO error text never contains the password
- Firebase project `muyasms-muyalink` ships deny-by-default rules (`firebase/`) locked to
  the owner account `officialqeyo@gmail.com` — deploy them even if unused
