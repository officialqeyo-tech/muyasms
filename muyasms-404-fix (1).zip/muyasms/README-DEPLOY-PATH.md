# MuyaSMS — FULL FIX & DEPLOY GUIDE (v3 — PostgreSQL + INSTANT accounts)

This package fixes **everything** you reported:

| Problem you saw | What was actually wrong | Fixed |
|---|---|---|
| "Something went wrong. Please try again or contact us on WhatsApp." | You were on a **fake placeholder page** (`muyasms.html`) inside the Node website — its form tries Firebase and fails. The real MuyaSMS (PHP) never ran. | Placeholder deleted — the MUYASMS button now opens the **real** MuyaSMS at `muyalink.com/muyasms/` |
| `/muyasms` showed 404 / wrong page | The Node app's `.htaccess` catches ALL urls, so PHP never runs | 4-line fix at the top of `public_html/.htaccess` (below) |
| Installing did nothing / dump.sql import failed in phpPgAdmin | **Your server's database is PostgreSQL (phpPgAdmin), NOT MySQL** — the old package only spoke MySQL | **NEW: the app now speaks PostgreSQL natively** (also still works on MySQL) |
| Customers had to wait for admin approval | Old design blocked login until email verified | **NEW: account works the second you register** — no admin, no approval |
| Sign in only with email | — | **NEW: sign in with EMAIL or PHONE + password** |
| — | — | **NEW: 100 free bonus credits granted at registration** (try SMS immediately) |
| — | — | **NEW: welcome email + password reset email (both by email or phone)** |

---

## THE NEW CUSTOMER FLOW (what your customers get)

1. Customer opens `https://muyalink.com/muyasms/` → clicks **Create free account**
2. Fills: **Full name, Email, Phone, Company (optional), Password**
3. Account is created **instantly — ACTIVE, usable, with 100 free SMS credits**
4. They are **signed in automatically** → straight to the dashboard
5. A **welcome email** arrives with a "Confirm my email" link
   (confirming is encouraged + keeps the account secure, but it is
   NEVER required to use the account)
6. They can sign in any time **with their email OR their phone number**
7. When they pay by telebirr: they submit the transaction ID →
   **admin approves the payment** → credits appear instantly.
   (Admin approves ONLY payments — never accounts.)

---

## DEPLOY — 5 STEPS (about 6 minutes)

### STEP 1 — Database: ALREADY DONE ✓
Your server uses **PostgreSQL** (phpPgAdmin) and your database
**`muyalito_muyasms`** is already created — do nothing here.

- Do NOT import dump.sql by hand in phpPgAdmin — the installer creates
  all tables itself (it uses `dump-pg.sql`, the PostgreSQL schema).
- If you ever start over on a MySQL server: create the DB in
  cPanel → MySQL® Databases, open `install.php` and pick MySQL in the
  fix form — the same package handles both.

### STEP 2 — Upload this package
**Upload `muyasms-404-fix.zip` directly into `public_html/`** — the SAME
folder where your Node.js website lives (do NOT create a muyasms folder
yourself, do NOT extract inside muyasms):
- cPanel → **File Manager** → open `public_html`
- Upload `muyasms-404-fix.zip` there
- Right-click the zip → **Extract** → a `muyasms` folder is created
  AUTOMATICALLY with all files inside
- Check: open `public_html/muyasms` → you must see `index.php` and
  `install.php` DIRECTLY there (not inside another folder)
- If an old/broken `muyasms` folder already exists: extracting over it
  REPLACES the files and fixes it — that is what we want
- Delete the zip after extracting
- (Do not worry: nothing in this zip touches your Node website files —
  everything is inside the `muyasms/` folder)

### STEP 3 — Run the installer
Open in your browser:

```
https://muyalink.com/muyasms/install.php
```

(Tip: opening `https://muyalink.com/muyasms/` before installation now
redirects to the installer automatically.)

- The installer connects to your **PostgreSQL** database
  `muyalito_muyasms` **automatically** — it tries the user
  `muyalito_muyasms`, your cPanel account name (`muyalito`),
  localhost AND the `/var/run/postgresql` socket, then saves whatever
  connects. You normally do not type anything.
- Only if it cannot connect does it show the fix form — then check the
  exact PostgreSQL user in cPanel → **PostgreSQL Databases** and type it.
- It creates ALL tables itself (dump-pg.sql) — never import anything by
  hand in phpPgAdmin.
- Then create the super-admin (`officialqeyo@gmail.com` + a 10+ char
  password).
- If you installed an older version before: delete
  `muyasms/storage/installed.lock` in File Manager first, then open
  `install.php` — it upgrades the database automatically
  (unlocks every waiting "pending" customer, adds phone sign-in).
- **After it says "Installation complete" → delete `install.php`
  from the server** (security).

### STEP 4 — The 4-line .htaccess fix (THIS kills the 404 / placeholder)
cPanel → File Manager → edit **`public_html/.htaccess`**
(the MAIN one, next to your Node app files — NOT the one inside muyasms/).

Paste these 4 lines at the **VERY TOP** of the file — above all the
Passenger / Node.js lines cPanel already wrote there:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteRule ^muyasms($|/) - [L]
</IfModule>
```

Save. (Same content is in `htaccess-root-fix.txt` in this package.)
The `muyasms/.htaccess` inside this package already turns Passenger
off for the folder — do not remove it.

### STEP 5 — Update the main website buttons
Upload the new `muyalink-full-site-update.zip` (separate file) over
`public_html/` of the Node app per its README. This changes the hero
MUYASMS button from the dead placeholder to the real
`https://muyalink.com/muyasms/` and turns the old placeholder into an
instant redirect. (Hero text row under the 5 buttons removed + mobile
menu header is solid green now too.)

### STEP 5 — Test everything (2 minutes)
1. Open `https://muyalink.com/muyasms/` → real MuyaSMS landing page ✅
2. **Create free account** → fill name, email, phone, company (optional),
   password → you land DIRECTLY on the dashboard with **100 credits** ✅
3. Check the email inbox → **welcome email** with "Confirm my email" ✅
4. Click the confirm link → "Email verified — thank you!" ✅
5. Sign out → **Sign in with your PHONE number** + password ✅
6. Sign out → Sign in with your **email** + password ✅
7. "Forgot password?" → enter email OR phone → reset email arrives ✅
8. Wallet → submit a telebirr transaction → admin panel → Payments →
   **Approve** → credits added instantly ✅

---

## IF SOMETHING DOES NOT WORK

| Symptom | Cause | Fix |
|---|---|---|
| Installer says "PHP does not have the PostgreSQL driver (pdo_pgsql)" | The host did not enable pdo_pgsql | Ask the host to enable pdo_pgsql — OR create a MySQL database in cPanel → MySQL Databases, open install.php and pick MySQL in the fix form |
| Installer shows the database fix form | Could not connect with the tried users | Type the exact user shown in cPanel → **PostgreSQL Databases** (often your cPanel account name, e.g. `muyalito`) + its password |
| Still "Something went wrong… WhatsApp" | Old placeholder cached, or step 4 not done | Hard-refresh (Ctrl+Shift+R); redo step 4; make sure the hero button points to `/muyasms/` |
| `/muyasms` shows "Not Found / The resource requested could not be found" | The `muyasms` folder is missing or incomplete on the server, or the 4 lines are missing/below the Passenger lines | Re-extract `muyasms-404-fix.zip` inside `public_html` (check `index.php` is directly inside `muyasms/`); make sure the 4 lines are at the VERY TOP of `public_html/.htaccess` |
| Redirects to install.php forever | DB connect failing | Use the fix form on install.php — database `muyalito_muyasms`, port 5432, the PostgreSQL user + password from cPanel |
| Emails don't arrive | SMTP password wrong | The SMTP account `sms@muyalink.com` must exist in cPanel → Email Accounts; its password is in config/config.php |
| Phone sign-in says wrong login | Phone saved differently | Sign in with email once, then use the phone exactly as registered (09… or +2519… both work) |

Error log: `muyasms/storage/php-error.log` (File Manager).
