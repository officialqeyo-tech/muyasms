# MuyaSMS — Firebase Security Rules (project `muyasms-muyalink`)

The live platform runs on **PHP + MySQL on cPanel** (muyalink.com) — it does **not**
need Firebase to work. These rules ship with the package because the Firebase
project was created for MuyaSMS; they keep that project **locked down** (deny-by-default)
and ready if you later add Firebase-powered real-time features (live dashboard
streaming, delivery-status push, etc.) using the same data model.

**Owner / super-admin locked in the rules:** `officialqeyo@gmail.com`

## Files

| File | For |
|---|---|
| `firestore.rules` | Cloud Firestore (test + production mode) |
| `realtime.rules` | Realtime Database (JSON) |

## What the rules enforce

1. **Deny by default** — every path not explicitly matched is fully blocked.
2. **Owner-only writes** — only `officialqeyo@gmail.com` (verified) can manage users,
   approve telebirr transactions, verify businesses, edit gateways/settings.
3. **Customer boundaries** — a signed-in customer can read *only* their own
   profile, campaigns, contacts and transaction status. No cross-account reads.
4. **No self-promotion** — clients can never change their own role, credits,
   `company_verified` flag, or transaction status (`pending` → `approved`).
5. **Append-only audit log** — clients cannot rewrite history.

## Deploying (2 minutes)

**Option A — Firebase Console (easiest)**
1. Open https://console.firebase.google.com → select project **muyasms-muyalink**
2. **Firestore Database → Rules** → paste the contents of `firestore.rules` → **Publish**
3. **Realtime Database → Rules** → paste the contents of `realtime.rules` → **Publish**

**Option B — Firebase CLI**
```bash
npm i -g firebase-tools
firebase login
firebase use muyasms-muyalink
cp firestore.rules firebase/firestore.rules   # if running from repo root
firebase deploy --only firestore:rules,database
```

## Connecting Firebase later (optional)

If you want live status streams in the MuyaSMS UI one day, add the web-app
config to a new `config/firebase.php` and read data with the JS SDK — the
rules above already match the MySQL schema used by the PHP app
(`users`, `wallet_transactions`, `verifications`, `campaigns`, `messages`,
`contacts`, `gateways`, `settings`, `audit_log`).

**Server writes** (message delivery status, audit entries) should use a
Firebase Admin SDK service account on the server — never a client key.
