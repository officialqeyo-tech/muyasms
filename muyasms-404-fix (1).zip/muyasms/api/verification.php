<?php
/**
 * MuyaSMS — enterprise verification submission.
 * Document is stored in LOCAL cPanel storage (uploads/verify/),
 * blocked from direct web access, downloadable by admins only.
 */
require __DIR__ . '/_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$u = require_api_user();
$uid = (int)$u['id'];

if (post_str('op', 20) !== 'submit') json_fail('Bad op', 422);

if ((int)$u['company_verified'] === 1) json_fail(__('verif_status_approved'));
$pending = qr('SELECT id FROM verifications WHERE user_id = ? AND status = \'pending\'', [$uid]);
if ($pending) json_fail(__('verif_status_pending_d'));

$company = post_str('company', 190);
if (mb_strlen($company) < 2) json_fail(__('verif_company'));

if (empty($_FILES['doc']) || !is_array($_FILES['doc'])) json_fail(__('verif_upload_err'));
$f = $_FILES['doc'];

if ($f['error'] !== UPLOAD_ERR_OK) {
    json_fail($f['error'] === UPLOAD_ERR_INI_SIZE ? __('verif_too_big') : __('verif_upload_err'));
}
if ($f['size'] > 5 * 1024 * 1024) json_fail(__('verif_too_big'));

// Extension + real MIME check (finfo)
$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
$allowed = ['pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png'];
if (!isset($allowed[$ext])) json_fail(__('verif_bad_type'));

$mime = '';
if (function_exists('finfo_open')) {
    $fi = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($fi, $f['tmp_name']);
    finfo_close($fi);
} elseif (function_exists('mime_content_type')) {
    $mime = mime_content_type($f['tmp_name']);
}
if ($mime !== '' && $mime !== $allowed[$ext] && !($ext === 'jpeg' && $mime === 'image/jpeg')) {
    json_fail(__('verif_bad_type'));
}
// PHP embed check (safety)
$head = (string)@file_get_contents($f['tmp_name'], false, null, 0, 4096);
if (stripos($head, '<?php') !== false) json_fail(__('verif_bad_type'));

// Store with random name in local storage
$dir = ROOT . '/uploads/verify';
if (!is_dir($dir)) @mkdir($dir, 0755, true);
$stored = 'vf_' . $uid . '_' . rand_token(10) . '.' . $ext;
$dest = $dir . '/' . $stored;
if (!@move_uploaded_file($f['tmp_name'], $dest)) {
    json_fail(__('verif_upload_err'));
}
@chmod($dest, 0644);

q('INSERT INTO verifications (user_id, company_name, doc_path, status) VALUES (?,?,?, \'pending\')', [$uid, $company, $stored]);
q('UPDATE users SET company_name = ? WHERE id = ?', [$company, $uid]);
audit('verif_submit', $company . ' → ' . $stored);

notify_admin(
    'MuyaSMS — enterprise verification pending / የድርጅት ማረጋገጫ በመጠበቅ',
    email_template(
        'Enterprise verification waiting for review',
        'የድርጅት ማረጋገጫ ግምገማ ይጠብቃል',
        '<p><b>' . e($u['name']) . '</b> (' . e($u['email']) . ') submitted company <b>' . e($company) . '</b> for verification.</p><p>Open the admin panel → Verifications to review the document.</p>',
        '<p><b>' . e($u['name']) . '</b> (' . e($u['email']) . ') ድርጅቱን <b>' . e($company) . '</b> ለማረጋገጥ አስገቷል።</p><p>ሰነዱን ለማየት የአስተዳዳሪ ክፍል → ማረጋገጫዎችን ይክፈቱ።</p>',
        null
    )
);

json_out(['ok' => true, 'msg' => __('verif_submitted')]);
