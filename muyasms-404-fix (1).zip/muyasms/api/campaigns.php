<?php
/**
 * MuyaSMS — campaign launch API.
 * Validates verification rules + credits, charges wallet, queues messages.
 */
require __DIR__ . '/_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$u = require_api_user();
$uid = (int)$u['id'];
$op = post_str('op', 20);

if ($op !== 'launch') json_fail('Bad op', 422);

$name = post_str('name', 160);
$message = post_str('message', 1600);
$recipientsRaw = post_str('recipients', 40000);

if ($message === '') json_fail(__('err_fields'));
if (mb_strlen($message) > 1600) json_fail('Message too long (1600 chars max)');

$parsed = parse_recipients($recipientsRaw);
$phones = $parsed['ok'];
if (!count($phones)) json_fail(__('send_none_valid'));

// Enterprise verification rule
$verifRequired = setting('bulk_requires_verification', '1') === '1';
$limit = (int)setting('unverified_recipient_limit', 10);
$verified = (int)$u['company_verified'] === 1;
if ($verifRequired && !$verified && count($phones) > $limit) {
    json_fail(sprintf(__('send_limit_unverified'), $limit));
}

// Credits
$est = estimate_credits($phones, $message);
$totalCredits = $est['credits'];
if ((int)$u['credits'] < $totalCredits) json_fail(__('send_no_credits'));

// Create campaign + messages in a transaction
$pdo = db();
$pdo->beginTransaction();
try {
    q('INSERT INTO campaigns (user_id, name, message, recipients_count, credits_charged, status) VALUES (?,?,?,?,?, \'queued\')', [
        $uid, $name ?: ('Campaign ' . date('Y-m-d H:i')), $message, count($phones), $totalCredits,
    ]);
    $campId = (int)$pdo->lastInsertId();

    $seg = seg_info($message);
    $segments = max(1, (int)$seg['segments']);
    $intlMult = max(1, (int)setting('intl_credit_multiplier', 2));

    $st = $pdo->prepare('INSERT INTO messages (campaign_id, user_id, recipient, content, segments, credits, status) VALUES (?,?,?,?,?,?, \'queued\')');
    $charged = 0;
    foreach ($phones as $p) {
        $c = $segments;
        if (is_intl($p)) $c *= $intlMult;
        $charged += $c;
        $st->execute([$campId, $uid, $p, $message, $segments, $c]);
    }

    // charge wallet
    q('UPDATE users SET credits = credits - ? WHERE id = ?', [$charged, $uid]);
    q('INSERT INTO wallet_transactions (user_id, type, credits, method, status, note) VALUES (?, \'charge\', ?, \'system\', \'approved\', ?)', [
        $uid, -$charged, 'Campaign #' . $campId,
    ]);
    q('UPDATE campaigns SET credits_charged = ? WHERE id = ?', [$charged, $campId]);

    $pdo->commit();
    audit('campaign_launch', '#' . $campId . ' → ' . count($phones) . ' recipients, ' . $charged . ' credits');

    // opportunistically kick the dispatcher (best effort)
    try { process_queue(); } catch (Throwable $e) { /* cron will handle */ }

    json_out(['ok' => true, 'campaign_id' => $campId, 'queued' => count($phones), 'credits' => $charged, 'removed' => $parsed['bad']]);
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('campaign launch: ' . $e->getMessage());
    json_fail(__('error_generic'), 500);
}
