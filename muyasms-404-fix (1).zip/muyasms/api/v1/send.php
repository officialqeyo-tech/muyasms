<?php
/**
 * MuyaSMS — public REST API v1: send SMS.
 *
 *   POST /api/v1/send.php
 *   Authorization: Bearer muya_....
 *   Content-Type: application/json
 *   {"recipients":["+251911223344","0922334455"],"message":"Hello","name":"My automation"}
 *
 * Rate limit: 60 requests / minute per API key.
 */
require __DIR__ . '/../includes/bootstrap.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_fail('POST only', 405);
}

// ---- Bearer auth ----
$hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!preg_match('/^Bearer\s+(muya_[A-Za-z0-9]+)$/i', $hdr, $m)) {
    header('WWW-Authenticate: Bearer realm="MuyaSMS API"');
    json_fail('Missing or invalid API key', 401);
}
$key = $m[1];
$u = qr('SELECT * FROM users WHERE api_key_hash = ? AND status = \'active\'', [api_key_hash($key)]);
if (!$u) json_fail('Invalid API key', 401);

if (!rl_check('api_' . $u['id'], 60, 60)) {
    header('Retry-After: 60');
    json_fail('Rate limit exceeded (60/min)', 429);
}

// ---- input ----
$body = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($body)) json_fail('Invalid JSON body', 400);

$message = isset($body['message']) && is_string($body['message']) ? trim($body['message']) : '';
$name = isset($body['name']) && is_string($body['name']) ? trim($body['name']) : 'API ' . date('Ymd H:i');
$recipientsIn = $body['recipients'] ?? [];

if ($message === '') json_fail('message is required', 422);
if (mb_strlen($message) > 1600) json_fail('message too long (1600 max)', 422);
if (!is_array($recipientsIn) || !count($recipientsIn)) json_fail('recipients[] is required', 422);
if (count($recipientsIn) > 2000) json_fail('too many recipients (2000 max per request)', 422);

$phones = [];
foreach ($recipientsIn as $r) {
    $p = normalize_phone((string)$r);
    if ($p === null) continue;
    if (!in_array($p, $phones, true)) $phones[] = $p;
}
if (!count($phones)) json_fail('no valid recipient numbers', 422);

$uid = (int)$u['id'];

// ---- rules (same as web) ----
$verifRequired = setting('bulk_requires_verification', '1') === '1';
$limit = (int)setting('unverified_recipient_limit', 10);
if ($verifRequired && (int)$u['company_verified'] !== 1 && count($phones) > $limit) {
    json_fail('verification required: max ' . $limit . ' recipients per campaign', 403);
}

$est = estimate_credits($phones, $message);
if ((int)$u['credits'] < $est['credits']) json_fail('insufficient credits', 402);

// ---- create + queue ----
$pdo = db();
$pdo->beginTransaction();
try {
    q('INSERT INTO campaigns (user_id, name, message, recipients_count, credits_charged, source, status) VALUES (?,?,?,?,?,\'api\',\'queued\')', [
        $uid, mb_substr($name, 0, 160), $message, count($phones), $est['credits'],
    ]);
    $campId = (int)$pdo->lastInsertId();

    $seg = seg_info($message);
    $segments = max(1, (int)$seg['segments']);
    $intlMult = max(1, (int)setting('intl_credit_multiplier', 2));
    $st = $pdo->prepare('INSERT INTO messages (campaign_id, user_id, recipient, content, segments, credits, status) VALUES (?,?,?,?,?,?, \'queued\')');
    $charged = 0;
    foreach ($phones as $p) {
        $c = $segments;
        if (is_intl($p)) $c *= $intlMult;
        $charged += $c;
        $st->execute([$campId, $uid, $p, $message, $segments, $c]);
    }
    q('UPDATE users SET credits = credits - ? WHERE id = ?', [$charged, $uid]);
    q('INSERT INTO wallet_transactions (user_id, type, credits, method, status, note) VALUES (?, \'charge\', ?, \'system\', \'approved\', ?)', [$uid, -$charged, 'API #' . $campId]);
    q('UPDATE campaigns SET credits_charged = ? WHERE id = ?', [$charged, $campId]);
    $pdo->commit();

    audit('api_send', '#' . $campId . ' ' . count($phones) . ' rcpt / ' . $charged . ' cr');
    try { process_queue(); } catch (Throwable $e) { /* cron will handle */ }

    json_out([
        'ok' => true,
        'campaign_id' => $campId,
        'queued' => count($phones),
        'credits_charged' => $charged,
        'credits_remaining' => (int)$u['credits'] - $charged,
    ], 201);
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('api send: ' . $e->getMessage());
    json_fail('server error', 500);
}
