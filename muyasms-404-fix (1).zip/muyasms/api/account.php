<?php
/**
 * MuyaSMS — account API (profile, password, API key).
 */
require __DIR__ . '/_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$u = require_api_user();
$uid = (int)$u['id'];
$op = post_str('op', 20);

if ($op === 'profile') {
    $name = post_str('name', 120);
    $phoneRaw = post_str('phone', 32);
    $langPref = in_array(post_str('lang', 5), ['en', 'am'], true) ? post_str('lang', 5) : 'en';
    if (mb_strlen($name) < 2) json_fail(__('err_name'));
    $phone = null;
    if ($phoneRaw !== '') {
        $phone = normalize_phone($phoneRaw);
        if ($phone === null) json_fail(__('err_phone_invalid'));
    }
    q('UPDATE users SET name = ?, phone = ?, preferred_lang = ? WHERE id = ?', [$name, $phone, $langPref, $uid]);
    $_SESSION['lang'] = $langPref;
    audit('profile_update', $u['email']);
    json_out(['ok' => true]);
}

if ($op === 'password') {
    $cur = (string)($_POST['cur'] ?? '');
    $nw = (string)($_POST['nw'] ?? '');
    $rep = (string)($_POST['rep'] ?? '');
    if (!password_verify($cur, $u['password_hash'])) json_fail(__('set_wrong_pass'));
    if ($nw !== $rep) json_fail(__('err_fields'));
    if (!password_ok($nw)) json_fail(__('err_password_rules'));
    q('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($nw, PASSWORD_DEFAULT), $uid]);
    session_regenerate_id(true);
    audit('password_change', $u['email']);
    json_out(['ok' => true, 'msg' => __('set_pass_ok')]);
}

if ($op === 'regen_api_key') {
    if (!rl_check('apikey_' . $uid, 5, 3600)) json_fail('Too many regenerations. Try later.');
    $key = generate_api_key();
    q('UPDATE users SET api_key_hash = ? WHERE id = ?', [api_key_hash($key), $uid]);
    audit('api_key_regen', $u['email']);
    json_out(['ok' => true, 'key' => $key]);
}

json_fail('Bad op', 422);
