<?php
/**
 * MuyaSMS — shared API guards.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

function require_api_user(): array
{
    $u = current_user();
    if (!$u) json_fail('Unauthorized', 401);
    return $u;
}

function require_api_admin(): array
{
    $u = current_user();
    if (!$u || !in_array($u['role'], ['admin', 'staff'], true)) json_fail('Forbidden', 403);
    return $u;
}

function require_api_super(): array
{
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') json_fail('Forbidden', 403);
    return $u;
}

function api_post_only(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_fail('POST only', 405);
}
