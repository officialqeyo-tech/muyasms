<?php
/**
 * MuyaSMS — wallet API: telebirr top-up submission.
 * Creates a PENDING transaction for admin approval (credits granted on approve).
 */
require __DIR__ . '/_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$u = require_api_user();
$uid = (int)$u['id'];

if (post_str('op', 20) !== 'topup') json_fail('Bad op', 422);

$amount = round((float)post_str('amount', 20), 2);
$txn = strtoupper(preg_replace('/[^A-Za-z0-9\-\_]/', '', post_str('txn', 60)));

$minTopup = (float)setting('min_topup_etb', 25);
if ($amount < $minTopup) json_fail(sprintf(__('topup_min'), number_format($minTopup, 2)));
if ($amount > 100000) json_fail('Amount too large');
if (strlen($txn) < 4) json_fail(__('telebirr_txn_hint'));

// duplicate transaction id?
if (qr('SELECT id FROM wallet_transactions WHERE txn_ref = ?', [$txn])) {
    json_fail(__('txn_duplicate'));
}

// pending one already? allow max 3 pending at a time
$pendingCount = (int)qv('SELECT COUNT(*) FROM wallet_transactions WHERE user_id = ? AND status = \'pending\'', [$uid]);
if ($pendingCount >= 3) json_fail(__('waiting_approval_d'));

q('INSERT INTO wallet_transactions (user_id, type, credits, amount_etb, method, txn_ref, status) VALUES (?, \'topup\', 0, ?, \'telebirr\', ?, \'pending\')', [
    $uid, $amount, $txn,
]);
audit('topup_submit', $txn . ' / ETB ' . number_format($amount, 2));

// notify admin
notify_admin(
    'MuyaSMS — new telebirr top-up pending / አዲስ የቴሌብር ማሞያ',
    email_template(
        'New telebirr top-up waiting for approval',
        'አዲስ የቴሌብር ማሞያ በመጠበቅ ላይ',
        '<p><b>' . e($u['name']) . '</b> (' . e($u['email']) . ') submitted ETB ' . number_format($amount, 2) . '.</p><p>Transaction ID: <b>' . e($txn) . '</b></p><p>Review it in the admin panel → Payments.</p>',
        '<p><b>' . e($u['name']) . '</b> (' . e($u['email']) . ') የ' . number_format($amount, 2) . ' ብር ክፍያ አስገብቷል።</p><p>የግብይት መለያ፦ <b>' . e($txn) . '</b></p><p>በአስተዳዳሪ ክፍል → ክፍያዎች ውስጥ ያረጋግጡ።</p>',
        null
    )
);

json_out(['ok' => true, 'msg' => __('txn_submitted')]);
