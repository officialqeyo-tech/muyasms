<?php
/**
 * MuyaSMS — contacts API (add / delete / import / list_group).
 */
require __DIR__ . '/_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$u = require_api_user();
$uid = (int)$u['id'];
$op = post_str('op', 20);

if ($op === 'add') {
    $name = post_str('name', 120);
    $phone = normalize_phone(post_str('phone', 32));
    $group = post_str('group', 80) ?: 'Default';
    if ($phone === null) json_fail(__('err_phone_invalid'));
    if (qr('SELECT id FROM contacts WHERE user_id = ? AND phone = ?', [$uid, $phone])) {
        json_fail('Duplicate phone');
    }
    q('INSERT INTO contacts (user_id, name, phone, group_name) VALUES (?,?,?,?)', [$uid, $name, $phone, $group]);
    json_out(['ok' => true, 'msg' => __('contacts_added')]);
}

if ($op === 'delete') {
    $id = post_int('id');
    q('DELETE FROM contacts WHERE id = ? AND user_id = ?', [$id, $uid]);
    json_out(['ok' => true]);
}

if ($op === 'import') {
    $csv = post_str('csv', 20000);
    $lines = preg_split('/\r\n|\r|\n/', $csv) ?: [];
    $added = 0; $skipped = 0;
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = array_map('trim', explode(',', $line));
        $phoneRaw = $parts[0];
        $name = '';
        if (count($parts) >= 2 && !preg_match('/^[0-9+]/', $parts[0])) {
            $name = $parts[0];
            $phoneRaw = $parts[1];
        }
        $phone = normalize_phone($phoneRaw);
        if ($phone === null) { $skipped++; continue; }
        try {
            if (is_pg()) {
                q('INSERT INTO contacts (user_id, name, phone, group_name) VALUES (?,?,?,\'Imported\') ON CONFLICT DO NOTHING', [$uid, mb_substr($name, 0, 120), $phone]);
            } else {
                q('INSERT IGNORE INTO contacts (user_id, name, phone, group_name) VALUES (?,?,?,\'Imported\')', [$uid, mb_substr($name, 0, 120), $phone]);
            }
            $added++;
        } catch (Throwable $e) { $skipped++; }
    }
    json_out(['ok' => true, 'msg' => sprintf(__('contacts_imported'), $added, $skipped)]);
}

if ($op === 'list_group') {
    $group = post_str('group', 80);
    $rows = qall('SELECT phone FROM contacts WHERE user_id = ? AND group_name = ?', [$uid, $group]);
    json_out(['ok' => true, 'phones' => array_column($rows, 'phone')]);
}

json_fail('Bad op', 422);
