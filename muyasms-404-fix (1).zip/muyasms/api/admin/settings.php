<?php
/**
 * MuyaSMS — admin API: platform settings (all parameters adjustable).
 */
require __DIR__ . '/../_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$admin = require_api_admin();

if (post_str('op', 20) !== 'settings') json_fail('Bad op', 422);

$numeric = ['price_per_sms', 'intl_credit_multiplier', 'signup_free_credits', 'min_topup_etb',
            'unverified_recipient_limit', 'dispatch_batch_size', 'dispatch_interval_sec'];
$text = ['telebirr_name', 'telebirr_account', 'telebirr_note', 'platform_name', 'admin_notify_email'];
$bool = ['bulk_requires_verification', 'maintenance_mode', 'email_enabled'];

$saved = [];
foreach ($numeric as $k) {
    if (isset($_POST[$k]) && is_numeric($_POST[$k]) === true) {
        $v = (string)(float)$_POST[$k];
        if ($k === 'price_per_sms') $v = number_format((float)$_POST[$k], 2, '.', '');
        if ($v >= 0) { setting_set($k, $v); $saved[] = $k; }
    }
}
foreach ($text as $k) {
    if (isset($_POST[$k])) { setting_set($k, post_str($k, 500)); $saved[] = $k; }
}
foreach ($bool as $k) {
    if (isset($_POST[$k])) {
        setting_set($k, $_POST[$k] === '1' || $_POST[$k] === 'on' ? '1' : '0');
        $saved[] = $k;
    }
}
if (in_array('admin_notify_email', $saved, true)) {
    $em = setting('admin_notify_email', '');
    if ($em !== '' && !filter_var((string)$em, FILTER_VALIDATE_EMAIL)) {
        setting_set('admin_notify_email', 'officialqeyo@gmail.com');
    }
}

audit('settings_update', implode(', ', $saved));
json_out(['ok' => true, 'msg' => __('adm_save_settings'), 'keys' => $saved]);
