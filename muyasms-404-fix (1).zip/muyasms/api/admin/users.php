<?php
/**
 * MuyaSMS — admin API: user management (suspend/activate/credits adjust).
 */
require __DIR__ . '/../_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$admin = require_api_admin();
$op = post_str('op', 20);
$id = post_int('id');

$target = qr('SELECT * FROM users WHERE id = ?', [$id]);
if (!$target) json_fail('User not found', 404);

if ($op === 'suspend' || $op === 'activate') {
    if ($target['role'] !== 'customer' && (int)$target['id'] !== (int)$admin['id']) {
        // staff/admin can only be suspended by a super-admin
        if ($admin['role'] !== 'admin') json_fail(__('super_only'), 403);
    }
    if ((int)$target['id'] === (int)$admin['id']) json_fail('You cannot suspend yourself');
    $newStatus = $op === 'suspend' ? 'suspended' : 'active';
    q('UPDATE users SET status = ? WHERE id = ?', [$newStatus, $id]);
    audit('user_' . $op, $target['email']);
    json_out(['ok' => true, 'msg' => __('adm_user_status')]);
}

if ($op === 'credits') {
    $delta = post_str('delta', 12);
    if (!preg_match('/^[+-]?\d{1,7}$/', $delta)) json_fail('Invalid number');
    $d = (int)$delta;
    if ($d === 0) json_fail('Zero change');
    $newCredits = (int)$target['credits'] + $d;
    if ($newCredits < 0) $newCredits = 0;
    q('UPDATE users SET credits = ? WHERE id = ?', [$newCredits, $id]);
    q('INSERT INTO wallet_transactions (user_id, type, credits, method, status, note) VALUES (?, \'adjust\', ?, \'admin\', \'approved\', ?)', [
        $id, $d, 'By ' . $admin['email'],
    ]);
    audit('credits_adjust', $target['email'] . ' ' . ($d > 0 ? '+' : '') . $d);
    json_out(['ok' => true, 'msg' => __('adm_credits_set')]);
}

json_fail('Bad op', 422);
