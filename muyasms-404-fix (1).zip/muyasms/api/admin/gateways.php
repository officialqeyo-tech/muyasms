<?php
/**
 * MuyaSMS — admin API: gateway management (save / test / toggle / default / delete).
 */
require __DIR__ . '/../_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$admin = require_api_admin();
$op = post_str('op', 20);

if ($op === 'save') {
    $id = post_int('id');
    $name = post_str('name', 120);
    $url = post_str('api_url', 500);
    $method = post_str('http_method', 10) === 'GET' ? 'GET' : 'POST';
    $sender = post_str('sender_id', 60);
    $headers = post_str('headers_json', 3000);
    $body = post_str('body_template', 5000);
    $okCond = post_str('success_condition', 250);
    $delivCond = post_str('delivered_condition', 250);
    $idRegex = post_str('id_regex', 250);
    $timeout = max(3, min(60, post_int('timeout_sec', 15)));
    $retries = max(0, min(5, post_int('retries', 2)));
    $rps = max(1, min(100, post_int('max_per_second', 5)));
    $priority = max(1, min(255, post_int('priority', 100)));
    $isDefault = post_int('is_default') === 1 ? 1 : 0;

    if ($name === '' || $url === '') json_fail(__('err_fields'));
    if (!preg_match('~^https?://~i', $url)) json_fail('URL must start with http:// or https://');

    // validate JSON fields when present
    if (trim($headers) !== '' && json_decode($headers, true) === null) json_fail('Headers: invalid JSON');
    if ($method === 'POST' && trim($body) !== '' && json_decode($body, true) === null) json_fail('Body template: invalid JSON');
    if ($idRegex !== '' && @preg_match($idRegex, '') === false) json_fail('Invalid regex');

    if ($id > 0) {
        q('UPDATE gateways SET name=?, api_url=?, http_method=?, sender_id=?, headers_json=?, body_template=?, success_condition=?, delivered_condition=?, id_regex=?, timeout_sec=?, retries=?, max_per_second=?, priority=?, is_default=? WHERE id=?', [
            $name, $url, $method, $sender, $headers, $body, $okCond, $delivCond, $idRegex, $timeout, $retries, $rps, $priority, $isDefault, $id,
        ]);
        if ($isDefault) q('UPDATE gateways SET is_default = 0 WHERE id != ?', [$id]);
        audit('gateway_update', $name);
    } else {
        q('INSERT INTO gateways (name, api_url, http_method, sender_id, headers_json, body_template, success_condition, delivered_condition, id_regex, timeout_sec, retries, max_per_second, priority, is_default, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,\'active\')', [
            $name, $url, $method, $sender, $headers, $body, $okCond, $delivCond, $idRegex, $timeout, $retries, $rps, $priority, $isDefault,
        ]);
        if ($isDefault) q('UPDATE gateways SET is_default = 0 WHERE id != ?', [db_last_id()]);
        audit('gateway_create', $name);
    }
    json_out(['ok' => true, 'msg' => __('gw_saved')]);
}

if ($op === 'test') {
    $id = post_int('id');
    $phoneRaw = post_str('phone', 32);
    $gw = qr('SELECT * FROM gateways WHERE id = ?', [$id]);
    if (!$gw) json_fail('Gateway not found', 404);
    $phone = normalize_phone($phoneRaw) ?: '+251911000000';
    $result = gateway_send($gw, $phone, 'MuyaSMS test message ' . date('H:i'), 0);
    audit('gateway_test', $gw['name'] . ' → ' . ($result['ok'] ? 'OK' : 'FAIL'));
    json_out(['ok' => true, 'ok_gw' => $result['ok'], 'response' => $result['response'] ?: ($result['error'] ?? 'empty')]);
}

if ($op === 'toggle') {
    $id = post_int('id');
    $gw = qr('SELECT id, name, status FROM gateways WHERE id = ?', [$id]);
    if (!$gw) json_fail('Gateway not found', 404);
    $new = $gw['status'] === 'active' ? 'inactive' : 'active';
    q('UPDATE gateways SET status = ? WHERE id = ?', [$new, $id]);
    audit('gateway_' . ($new === 'active' ? 'enable' : 'disable'), $gw['name']);
    json_out(['ok' => true]);
}

if ($op === 'default') {
    $id = post_int('id');
    if (is_pg()) {
        q('UPDATE gateways SET is_default = (id = ?)::int', [$id]);
    } else {
        q('UPDATE gateways SET is_default = (id = ?)', [$id]);
    }
    audit('gateway_default', '#' . $id);
    json_out(['ok' => true]);
}

if ($op === 'delete') {
    $id = post_int('id');
    $gw = qr('SELECT name, is_default FROM gateways WHERE id = ?', [$id]);
    if (!$gw) json_fail('Gateway not found', 404);
    if ((int)$gw['is_default'] === 1) json_fail('Cannot delete the default gateway');
    q('DELETE FROM gateways WHERE id = ?', [$id]);
    audit('gateway_delete', $gw['name']);
    json_out(['ok' => true]);
}

json_fail('Bad op', 422);
