<?php
/**
 * MuyaSMS — admin API: enterprise verification approval.
 * Approve → user.company_verified = 1 → bulk sending unlocked.
 */
require __DIR__ . '/../_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$admin = require_api_admin();
$op = post_str('op', 20);

if ($op !== 'approve' && $op !== 'reject') json_fail('Bad op', 422);

$id = post_int('id');
$note = post_str('note', 250);
$v = qr('SELECT v.*, u.email AS uemail, u.name AS uname FROM verifications v JOIN users u ON u.id = v.user_id WHERE v.id = ? AND v.status = \'pending\'', [$id]);
if (!$v) json_fail('Verification not found or already reviewed', 404);

if ($op === 'approve') {
    q('UPDATE verifications SET status = \'approved\', reviewed_by = ?, reviewed_at = NOW(), note = ? WHERE id = ?', [(int)$admin['id'], $note ?: null, $id]);
    q('UPDATE users SET company_verified = 1, company_name = ? WHERE id = ?', [$v['company_name'], (int)$v['user_id']]);
    audit('verif_approve', '#' . $id . ' ' . $v['company_name'] . ' (' . $v['uemail'] . ')');
    muya_mail(
        $v['uemail'],
        'MuyaSMS — company verified / ድርጅት ተረጋግጧል',
        email_template(
            'Your company is verified ✅',
            'ድርጅትዎ ተረጋግጧል ✅',
            '<p>Congratulations <b>' . e($v['uname']) . '</b>! <b>' . e($v['company_name']) . '</b> is now a verified business on MuyaSMS.</p><p>Unlimited bulk campaigns are unlocked on your account.</p>',
            '<pእንኳን ደስ አለዎት <b>' . e($v['uname']) . '</b>! <b>' . e($v['company_name']) . '</b> በMuyaSMS ላይ የተረጋገጠ ድርጅት ሆኗል።</p><p>ያለ ገደብ የብዙ መልእክት መላኪያ በመለያዎ ተከፍቷል።</p>',
            null
        )
    );
    json_out(['ok' => true, 'msg' => __('adm_verif_approve_ok')]);
} else {
    q('UPDATE verifications SET status = \'rejected\', reviewed_by = ?, reviewed_at = NOW(), note = ? WHERE id = ?', [(int)$admin['id'], $note ?: null, $id]);
    audit('verif_reject', '#' . $id . ' ' . $v['company_name'] . ' (' . $v['uemail'] . ')' . ($note ? ' — ' . $note : ''));
    muya_mail(
        $v['uemail'],
        'MuyaSMS — verification rejected / ማረጋገጫ አልተቀባይነም',
        email_template(
            'Verification could not be approved',
            'ማረጋገጫው ተቀባይነት አላገኘም',
            '<p>Hello <b>' . e($v['uname']) . '</b>, we could not verify <b>' . e($v['company_name']) . '</b>.</p>' . ($note ? '<p>Reason: ' . e($note) . '</p>' : '') . '<p>You can resubmit corrected documents from the Verification page.</p>',
            '<p>ሰላም <b>' . e($v['uname']) . '</b>፣ <b>' . e($v['company_name']) . '</b>ን ማረጋገጥ አልተቻለም።</p>' . ($note ? '<p>ምክንያት፦ ' . e($note) . '</p>' : '') . '<p>አስተካክለው ከማረጋገጫ ገጽ እንደገና ማስገባት ይችላሉ።</p>',
            null
        )
    );
    json_out(['ok' => true, 'msg' => __('adm_verif_reject_ok')]);
}
