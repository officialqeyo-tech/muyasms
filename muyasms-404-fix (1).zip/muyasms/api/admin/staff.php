<?php
/**
 * MuyaSMS — admin API: staff account creation (super-admin only).
 */
require __DIR__ . '/../_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$admin = require_api_super();

if (post_str('op', 20) !== 'create') json_fail('Bad op', 422);

$name = post_str('name', 120);
$email = post_email('email');
$pass = (string)($_POST['password'] ?? '');
$role = post_str('role', 10) === 'admin' ? 'admin' : 'staff';

if (mb_strlen($name) < 2) json_fail(__('err_name'));
if (!$email) json_fail(__('err_email_invalid'));
if (qr('SELECT id FROM users WHERE email = ?', [$email])) json_fail(__('err_email_taken'));
if (strlen($pass) < 10 || !preg_match('/[A-Za-z]/', $pass) || !preg_match('/[0-9]/', $pass)) {
    json_fail('Password must be 10+ characters with letters and numbers.');
}

q('INSERT INTO users (name, email, password_hash, role, status, email_verified) VALUES (?,?,?,?, \'active\', 1)', [
    $name, $email, password_hash($pass, PASSWORD_DEFAULT), $role,
]);
audit('staff_create', $email . ' (' . $role . ')');
json_out(['ok' => true, 'msg' => __('adm_staff_created')]);
