<?php
/**
 * MuyaSMS — admin API: telebirr payment approval.
 * Approve → credits granted (amount / price), customer notified by email.
 */
require __DIR__ . '/../_guard.php';

api_post_only();
require_csrf();
require_same_origin();

$admin = require_api_admin();
$op = post_str('op', 20);

if ($op !== 'approve' && $op !== 'reject') json_fail('Bad op', 422);

$id = post_int('id');
$note = post_str('note', 250);
$tx = qr('SELECT w.*, u.email AS uemail, u.name AS uname, u.credits FROM wallet_transactions w JOIN users u ON u.id = w.user_id WHERE w.id = ? AND w.status = \'pending\'', [$id]);
if (!$tx) json_fail('Transaction not found or already reviewed', 404);

$price = (float)setting('price_per_sms', 1);
if ($price <= 0) $price = 1;

if ($op === 'approve') {
    $credits = (int)floor((float)$tx['amount_etb'] / $price);
    if ($credits < 1) json_fail('Amount too small for 1 credit');
    q('UPDATE wallet_transactions SET status = \'approved\', credits = ?, reviewed_by = ?, reviewed_at = NOW(), note = ? WHERE id = ?', [
        $credits, (int)$admin['id'], $note ?: null, $id,
    ]);
    q('UPDATE users SET credits = credits + ? WHERE id = ?', [$credits, (int)$tx['user_id']]);
    audit('pay_approve', '#' . $id . ' ' . $tx['txn_ref'] . ' → +' . $credits . ' credits (' . $tx['uemail'] . ')');
    muya_mail(
        $tx['uemail'],
        'MuyaSMS — payment approved / ክፍያ ጸድቋል',
        email_template(
            'Your payment was approved',
            'ክፍያዎ ጸድቋል',
            '<p>Hello <b>' . e($tx['uname']) . '</b>, your telebirr payment of <b>' . e(money_etb((float)$tx['amount_etb'])) . '</b> was approved.</p><p><b style="color:#10B981">' . number_format($credits) . ' SMS credits</b> have been added to your wallet. 🎉</p>' . ($note ? '<p>Note from admin: ' . e($note) . '</p>' : ''),
            '<p>ሰላም <b>' . e($tx['uname']) . '</b>፣ የቴሌብር ክፍያዎ <b>' . e(money_etb((float)$tx['amount_etb'])) . '</b> ጸድቋል።</p><p><b style="color:#10B981">' . number_format($credits) . '</b> ኤስኤምኤስ ክሬዲት ወደ ዋሌትዎ ታክሏል። 🎉</p>' . ($note ? '<p>ማስታወሻ፦ ' . e($note) . '</p>' : ''),
            null
        )
    );
    json_out(['ok' => true, 'msg' => __('adm_pay_approve_ok'), 'credits' => $credits]);
} else {
    q('UPDATE wallet_transactions SET status = \'rejected\', reviewed_by = ?, reviewed_at = NOW(), note = ? WHERE id = ?', [
        (int)$admin['id'], $note ?: null, $id,
    ]);
    audit('pay_reject', '#' . $id . ' ' . $tx['txn_ref'] . ' (' . $tx['uemail'] . ')' . ($note ? ' — ' . $note : ''));
    muya_mail(
        $tx['uemail'],
        'MuyaSMS — payment rejected / ክፍያ አልተቀበለም',
        email_template(
            'Your payment could not be approved',
            'ክፍያዎ ተቀባይነት አላገኘም',
            '<p>Hello <b>' . e($tx['uname']) . '</b>, your transaction <span class="mono">' . e($tx['txn_ref']) . '</span> could not be verified.</p>' . ($note ? '<p>Reason: ' . e($note) . '</p>' : '') . '<p>If you believe this is a mistake, contact support with your telebirr receipt.</p>',
            '<p>ሰላም <b>' . e($tx['uname']) . '</b>፣ <span class="mono">' . e($tx['txn_ref']) . '</span> የሚለው ግብይት ማረጋገት አልተቻለም።</p>' . ($note ? '<p>ምክንያት፦ ' . e($note) . '</p>' : '') . '<p>ትክክል ብለው ካሰቡ የቴሌብር ደረሰኝዎን ይዘው ድጋፍን ያግኙ።</p>',
            null
        )
    );
    json_out(['ok' => true, 'msg' => __('adm_pay_reject_ok')]);
}
