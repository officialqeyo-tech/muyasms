<?php
/**
 * MuyaSMS — contacts manager + CSV import.
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();

$uid = (int)$u['id'];
$search = trim((string)($_GET['q'] ?? ''));
$whereSql = 'user_id = ?';
$params = [$uid];
if ($search !== '') {
    $whereSql .= ' AND (name LIKE ? OR phone LIKE ? OR group_name LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
$contacts = qall("SELECT * FROM contacts WHERE $whereSql ORDER BY id DESC LIMIT 400", $params);
$groups = qall('SELECT group_name, COUNT(*) AS n FROM contacts WHERE user_id = ? GROUP BY group_name ORDER BY group_name', [$uid]);

muya_page_start(['title' => __('nav_contacts'), 'area' => 'app', 'active' => 'contacts']);
?>

<div class="grid-1-2">
  <div>
    <div class="card">
      <div class="card-title">👤 <?= e(__('add_contact')) ?></div>
      <form onsubmit="return addContact(event)">
        <div class="f-group">
          <label class="f-label"><?= e(__('contact_name')) ?></label>
          <input class="f-input" id="cName" maxlength="120" placeholder="Abebe Kebede">
        </div>
        <div class="f-group">
          <label class="f-label"><?= e(__('contact_phone')) ?></label>
          <input class="f-input" id="cPhone" placeholder="09…" required>
        </div>
        <div class="f-group">
          <label class="f-label"><?= e(__('group')) ?></label>
          <input class="f-input" id="cGroup" list="groupList" placeholder="Default" value="Default">
          <datalist id="groupList">
            <?php foreach ($groups as $g): ?><option value="<?= e($g['group_name']) ?>"><?php endforeach; ?>
          </datalist>
        </div>
        <button class="btn btn-primary btn-block" type="submit" id="addBtn"><?= e(__('add')) ?></button>
      </form>
    </div>

    <div class="card mt-2">
      <div class="card-title">📥 <?= e(__('import_csv')) ?></div>
      <div class="f-hint" style="margin-bottom:10px"><?= e(__('csv_hint')) ?></div>
      <textarea class="f-input mono" id="csvBox" rows="6" placeholder="Abebe Kebede,0911223344&#10;0922334455"></textarea>
      <button class="btn btn-gold btn-block mt-1" onclick="importCsv()"><?= e(__('import_csv')) ?></button>
    </div>
  </div>

  <div class="card">
    <div class="card-title">
      📇 <?= e(__('contacts_title')) ?> <span class="tsub"><?= count($contacts) ?></span>
      <form method="get" class="right" style="display:flex;gap:8px">
        <input class="f-input" name="q" value="<?= e($search) ?>" placeholder="<?= e(__('search')) ?>" style="padding:7px 12px;width:180px">
        <button class="btn btn-ghost btn-sm" type="submit">🔍</button>
      </form>
    </div>
    <?php if (!$contacts): ?>
    <div class="empty"><div class="e-ic">📇</div><?= e(__('no_contacts')) ?></div>
    <?php else: ?>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr>
          <th><?= e(__('contact_name')) ?></th><th><?= e(__('contact_phone')) ?></th><th><?= e(__('group')) ?></th><th></th>
        </tr></thead>
        <tbody>
        <?php foreach ($contacts as $c): ?>
          <tr>
            <td><?= e($c['name'] ?: '—') ?></td>
            <td class="mono"><?= e($c['phone']) ?></td>
            <td><span class="tag"><?= e($c['group_name']) ?></span></td>
            <td><button class="btn btn-danger btn-sm" onclick="delContact(<?= (int)$c['id'] ?>)">✕</button></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
function addContact(ev) {
  ev.preventDefault();
  var btn = document.getElementById('addBtn');
  btn.disabled = true;
  window.muyaApi('../api/contacts.php', {
    op: 'add',
    name: document.getElementById('cName').value,
    phone: document.getElementById('cPhone').value,
    group: document.getElementById('cGroup').value || 'Default'
  }).then(function () {
    window.muyaToast('<?= e(__('contacts_added')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 700);
  }).catch(function () { btn.disabled = false; });
  return false;
}
function delContact(id) {
  if (!window.muyaConfirm()) return;
  window.muyaApi('../api/contacts.php', { op: 'delete', id: id }).then(function () {
    location.reload();
  }).catch(function () {});
}
function importCsv() {
  var text = document.getElementById('csvBox').value.trim();
  if (!text) return;
  window.muyaApi('../api/contacts.php', { op: 'import', csv: text }).then(function (j) {
    window.muyaToast((j.msg || 'OK'), 'ok');
    setTimeout(function () { location.reload(); }, 900);
  }).catch(function () {});
}
</script>
<?php muya_page_end(['area' => 'app']); ?>
