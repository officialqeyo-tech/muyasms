<?php
/**
 * MuyaSMS — wallet: telebirr top-up + approval status + ledger.
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();

$uid = (int)$u['id'];
$price = (float)setting('price_per_sms', 1);
$minTopup = (float)setting('min_topup_etb', 25);
$tbName = setting('telebirr_name', 'MuyaLink');
$tbAccount = setting('telebirr_account', '');
$tbNote = setting('telebirr_note', '');
$pending = qall('SELECT * FROM wallet_transactions WHERE user_id = ? AND status = \'pending\' ORDER BY id DESC', [$uid]);
$ledger = qall('SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 50', [$uid]);

muya_page_start(['title' => __('nav_wallet'), 'area' => 'app', 'active' => 'wallet']);
?>

<div class="grid-2">
  <div>
    <div class="card card-3d card-glow-g" data-tilt="6">
      <div class="stat-label"><?= e(__('wallet_balance')) ?></div>
      <div class="stat-value" style="color:var(--gold)"><span data-count="<?= (int)$u['credits'] ?>">0</span></div>
      <div class="stat-sub"><?= e(__('sms_credits')) ?> · <?= e(money_etb(((int)$u['credits']) * $price)) ?></div>
    </div>

    <?php foreach ($pending as $p): ?>
    <div class="waiting-box mt-2">
      <div class="w-ic">⏳</div>
      <div>
        <h4><?= e(__('waiting_approval')) ?></h4>
        <p><?= e(money_etb((float)$p['amount_etb'])) ?> · <?= e(__('txn_ref')) ?> <span class="mono"><?= e($p['txn_ref']) ?></span></p>
        <p class="dim"><?= e(__('waiting_approval_d')) ?></p>
      </div>
    </div>
    <?php endforeach; ?>

    <div class="card mt-2">
      <div class="card-title">📲 <?= e(__('topup_title')) ?></div>

      <div class="section-title"><?= e(__('telebirr_step1')) ?></div>
      <div class="code-block" style="color:#FCD34D"><?= e(sprintf(__('telebirr_pay_to'), $tbName, $tbAccount !== '' ? '(' . $tbAccount . ')' : '')) ?>
<?php if ($tbNote): ?>

<?= e($tbNote) ?><?php endif; ?></div>

      <div class="section-title"><?= e(__('telebirr_step2')) ?></div>
      <form onsubmit="return submitTopup(event)">
        <div class="f-row">
          <div class="f-group">
            <label class="f-label"><?= e(__('topup_amount')) ?></label>
            <input class="f-input" type="number" id="amount" min="<?= (int)$minTopup ?>" step="1" value="<?= (int)max(25, $minTopup) ?>" required>
            <div class="f-hint" id="calcHint"></div>
          </div>
          <div class="f-group">
            <label class="f-label"><?= e(__('telebirr_txn')) ?></label>
            <input class="f-input mono" id="txn" placeholder="12AB34CD5E" maxlength="60" required>
            <div class="f-hint"><?= e(__('telebirr_txn_hint')) ?></div>
          </div>
        </div>
        <button class="btn btn-primary btn-block" type="submit" id="topupBtn"><?= e(__('telebirr_submit')) ?></button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-title">📜 <?= e(__('ledger')) ?></div>
    <?php if (!$ledger): ?>
    <div class="empty"><div class="e-ic">📜</div><?= e(__('wallet_empty')) ?></div>
    <?php else: ?>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr>
          <th><?= e(__('date')) ?></th><th><?= e(__('type')) ?></th><th><?= e(__('credits')) ?></th><th><?= e(__('status')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($ledger as $t): ?>
          <tr>
            <td class="dim small"><?= e(fmt_dt($t['created_at'])) ?></td>
            <td>
              <?= e(__('tp_' . $t['type'])) ?>
              <?php if ($t['type'] === 'topup'): ?><div class="dim small mono"><?= e($t['txn_ref']) ?></div><?php endif; ?>
              <?php if ($t['note']): ?><div class="dim small"><?= e($t['note']) ?></div><?php endif; ?>
            </td>
            <td style="color:<?= in_array($t['type'], ['topup', 'bonus', 'refund', 'adjust']) ? 'var(--emerald)' : 'var(--muted)' ?>;font-weight:700">
              <?= (in_array($t['type'], ['topup', 'bonus', 'refund', 'adjust']) && (int)$t['credits'] >= 0 ? '+' : '') . number_format((int)$t['credits']) ?>
              <?php if ($t['amount_etb']): ?><div class="dim small"><?= e(money_etb((float)$t['amount_etb'])) ?></div><?php endif; ?>
            </td>
            <td><?= status_badge($t['status']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
var pricePerSms = <?= json_encode($price) ?>;
function calc() {
  var amount = parseFloat(document.getElementById('amount').value) || 0;
  var credits = Math.floor(amount / pricePerSms);
  document.getElementById('calcHint').textContent = '≈ ' + credits.toLocaleString() + ' <?= e(__('sms_credits')) ?>';
}
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('amount').addEventListener('input', calc);
  calc();
});
function submitTopup(ev) {
  ev.preventDefault();
  var btn = document.getElementById('topupBtn');
  btn.disabled = true;
  window.muyaApi('../api/wallet.php', {
    op: 'topup',
    amount: document.getElementById('amount').value,
    txn: document.getElementById('txn').value.trim()
  }).then(function () {
    window.muyaToast('<?= e(__('txn_submitted')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 1000);
  }).catch(function () { btn.disabled = false; });
  return false;
}
</script>
<?php muya_page_end(['area' => 'app']); ?>
