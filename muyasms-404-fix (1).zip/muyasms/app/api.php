<?php
/**
 * MuyaSMS — API keys & developer docs.
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();
$uid = (int)$u['id'];

$hasKey = !empty($u['api_key_hash']);
muya_page_start(['title' => __('nav_api'), 'area' => 'app', 'active' => 'api']);
?>

<div class="grid-2">
  <div class="card">
    <div class="card-title">🔑 <?= e(__('api_title')) ?></div>
    <?php if ($hasKey): ?>
    <div class="code-block" id="keyBox" style="color:#6EE7B7">•••••••••••••••••••••••••••••••</div>
    <div class="flex mt-1">
      <button class="btn btn-ghost btn-sm" onclick="window.muyaCopy(document.getElementById('keyBox').textContent)">📋 Copy</button>
      <button class="btn btn-gold btn-sm" onclick="regenKey()"><?= e(__('api_regen')) ?></button>
    </div>
    <?php else: ?>
    <p class="muted small mb-2"><?= e(__('api_docs_d')) ?></p>
    <button class="btn btn-primary" onclick="regenKey()">🔑 <?= e(__('api_regen')) ?></button>
    <?php endif; ?>
    <div class="flash flash-warn mt-2" style="font-size:12.5px">⚠️ <?= e(__('api_warn')) ?></div>
  </div>

  <div class="card">
    <div class="card-title">📖 <?= e(__('api_docs_t')) ?></div>
    <p class="muted small mb-2"><?= e(__('api_docs_note')) ?></p>
    <div class="code-block">POST /api/v1/send.php
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY

{
  "recipients": ["+251911223344", "0922334455"],
  "message": "Hello from my app!",
  "name": "Nightly alerts"
}</div>
    <div class="section-title"><?= e(__('api_example')) ?></div>
    <div class="code-block">curl -X POST <?= e(base_url('/api/v1/send.php')) ?> \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"recipients":["+251911223344"],
       "message":"Selam!","name":"Test"}'</div>
  </div>
</div>

<script>
function regenKey() {
  if (!window.muyaConfirm()) return;
  window.muyaApi('../api/account.php', { op: 'regen_api_key' }).then(function (j) {
    document.getElementById('keyBox').textContent = j.key;
    window.muyaToast('✓', 'ok');
  }).catch(function () {});
}
</script>
<?php muya_page_end(['area' => 'app']); ?>
