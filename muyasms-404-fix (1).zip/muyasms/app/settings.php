<?php
/**
 * MuyaSMS — account settings (profile, password, language).
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();
$uid = (int)$u['id'];

muya_page_start(['title' => __('nav_settings'), 'area' => 'app', 'active' => 'settings']);
?>

<div class="grid-2">
  <div class="card">
    <div class="card-title">👤 <?= e(__('set_profile')) ?></div>
    <form onsubmit="return saveProfile(event)">
      <div class="f-group">
        <label class="f-label"><?= e(__('full_name')) ?></label>
        <input class="f-input" id="pName" value="<?= e($u['name']) ?>" maxlength="120" required>
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('phone')) ?></label>
        <input class="f-input" id="pPhone" value="<?= e($u['phone']) ?>" placeholder="09…">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('email')) ?></label>
        <input class="f-input" value="<?= e($u['email']) ?>" disabled>
        <div class="f-hint">🔒</div>
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('set_lang_pref')) ?></label>
        <select class="f-input" id="pLang">
          <option value="en" <?= $u['preferred_lang'] === 'en' ? 'selected' : '' ?>>English</option>
          <option value="am" <?= $u['preferred_lang'] === 'am' ? 'selected' : '' ?>>አማርኛ (Amharic)</option>
        </select>
      </div>
      <button class="btn btn-primary" type="submit" id="pBtn"><?= e(__('save')) ?></button>
    </form>
  </div>

  <div class="card">
    <div class="card-title">🔒 <?= e(__('set_password')) ?></div>
    <form onsubmit="return changePass(event)">
      <div class="f-group">
        <label class="f-label"><?= e(__('set_cur_pass')) ?></label>
        <input class="f-input" type="password" id="curPass" required autocomplete="current-password">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('set_new_pass')) ?></label>
        <input class="f-input" type="password" id="newPass" minlength="8" required autocomplete="new-password">
      </div>
      <div class="f-group">
        <label class="f-label"><?= e(__('set_rep_pass')) ?></label>
        <input class="f-input" type="password" id="repPass" minlength="8" required autocomplete="new-password">
      </div>
      <button class="btn btn-green" type="submit" id="passBtn"><?= e(__('save')) ?></button>
    </form>
  </div>
</div>

<script>
function saveProfile(ev) {
  ev.preventDefault();
  var btn = document.getElementById('pBtn');
  btn.disabled = true;
  window.muyaApi('../api/account.php', {
    op: 'profile',
    name: document.getElementById('pName').value,
    phone: document.getElementById('pPhone').value,
    lang: document.getElementById('pLang').value
  }).then(function () {
    window.muyaToast('<?= e(__('set_saved')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 800);
  }).catch(function () { btn.disabled = false; });
  return false;
}
function changePass(ev) {
  ev.preventDefault();
  var btn = document.getElementById('passBtn');
  btn.disabled = true;
  window.muyaApi('../api/account.php', {
    op: 'password',
    cur: document.getElementById('curPass').value,
    nw: document.getElementById('newPass').value,
    rep: document.getElementById('repPass').value
  }).then(function () {
    window.muyaToast('<?= e(__('set_pass_ok')) ?>', 'ok');
    document.getElementById('curPass').value = '';
    document.getElementById('newPass').value = '';
    document.getElementById('repPass').value = '';
  }).catch(function () {}).then(function () { btn.disabled = false; });
  return false;
}
</script>
<?php muya_page_end(['area' => 'app']); ?>
