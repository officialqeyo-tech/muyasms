<?php
/**
 * MuyaSMS — enterprise verification (local document storage).
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();

$uid = (int)$u['id'];
$latest = qr('SELECT * FROM verifications WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$uid]);
$approved = (int)$u['company_verified'] === 1;
$pending = $latest && $latest['status'] === 'pending';
$rejected = $latest && $latest['status'] === 'rejected';
$limit = (int)setting('unverified_recipient_limit', 10);

muya_page_start(['title' => __('nav_verification'), 'area' => 'app', 'active' => 'verification']);
?>

<div class="grid-2">
  <div>
    <?php if ($approved): ?>
    <div class="card card-3d card-glow-e" data-tilt="6">
      <div class="flex" style="gap:12px">
        <div class="stat-ic" style="position:static;color:var(--emerald)">✅</div>
        <div>
          <h3 style="font-size:16px;color:var(--emerald)"><?= e(__('verif_status_approved')) ?></h3>
          <p class="muted small mt-1"><?= e(__('verif_status_approved_d')) ?></p>
        </div>
      </div>
      <div class="kv mt-2"><span class="k"><?= e(__('company')) ?></span><span class="v"><?= e($u['company_name']) ?></span></div>
      <div class="kv"><span class="k"><?= e(__('date')) ?></span><span class="v"><?= e(fmt_dt($latest['reviewed_at'] ?? null)) ?></span></div>
    </div>
    <?php elseif ($pending): ?>
    <div class="card card-3d card-glow-g" data-tilt="6">
      <div class="waiting-box" style="border-color:rgba(245,158,11,.35);background:transparent;padding:0">
        <div class="w-ic">⏳</div>
        <div>
          <h4><?= e(__('verif_status_pending')) ?></h4>
          <p><?= e(__('verif_status_pending_d')) ?></p>
        </div>
      </div>
      <div class="kv mt-2"><span class="k"><?= e(__('company')) ?></span><span class="v"><?= e($latest['company_name']) ?></span></div>
      <div class="kv"><span class="k"><?= e(__('submitted')) ?></span><span class="v"><?= e(fmt_dt($latest['created_at'])) ?></span></div>
    </div>
    <?php else: ?>
    <div class="card card-3d" data-tilt="6">
      <div class="card-title">🛡️ <?= e(__('verif_title')) ?></div>
      <?php if ($rejected): ?>
      <div class="flash flash-err mb-2"><?= e(sprintf(__('verif_status_rejected_d'), $latest['note'] ?: '—')) ?></div>
      <?php endif; ?>
      <p class="muted small mb-2"><?= e(sprintf(__('verif_status_none_d'), $limit)) ?></p>
      <form onsubmit="return submitVerification(event)" enctype="multipart/form-data">
        <div class="f-group">
          <label class="f-label"><?= e(__('verif_company')) ?></label>
          <input class="f-input" id="companyName" maxlength="190" required value="<?= e($u['company_name'] ?? '') ?>" placeholder="MuyaLink PLC">
        </div>
        <div class="f-group">
          <label class="f-label"><?= e(__('verif_doc')) ?></label>
          <input class="f-input" type="file" id="docFile" accept=".pdf,.jpg,.jpeg,.png" required>
          <div class="f-hint"><?= e(__('verif_doc_hint')) ?></div>
        </div>
        <button class="btn btn-primary btn-block" type="submit" id="verBtn"><?= e(__('verif_submit')) ?></button>
      </form>
    </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-title">📋 <?= e(__('verif_title')) ?></div>
    <div class="kv"><span class="k"><?= e(__('st_approved')) ?></span><span class="v" style="color:var(--emerald)">✓ <?= e(__('verif_status_approved_d')) ?></span></div>
    <div class="kv"><span class="k"><?= e(__('st_pending')) ?></span><span class="v muted small"><?= e(__('verif_status_pending_d')) ?></span></div>
    <div class="kv"><span class="k"><?= e(__('st_rejected')) ?></span><span class="v muted small"><?= e(__('verif_status_rejected_d'), '—') ?></span></div>
    <div class="kv"><span class="k"><?= e(__('unverified_limit')) ?></span><span class="v"><?= $limit ?></span></div>
    <div class="mt-2 small dim">🔐 <?= e(__('verif_doc_hint')) ?></div>
  </div>
</div>

<script>
function submitVerification(ev) {
  ev.preventDefault();
  var fileInput = document.getElementById('docFile');
  var file = fileInput.files && fileInput.files[0];
  if (!file) { alert('Select a document.'); return false; }
  if (file.size > 5 * 1024 * 1024) { alert('<?= e(__('verif_too_big')) ?>'); return false; }
  var fd = new FormData();
  fd.append('op', 'submit');
  fd.append('company', document.getElementById('companyName').value.trim());
  fd.append('doc', file);
  var btn = document.getElementById('verBtn');
  btn.disabled = true;
  window.muyaApi('../api/verification.php', fd).then(function () {
    window.muyaToast('<?= e(__('verif_submitted')) ?>', 'ok');
    setTimeout(function () { location.reload(); }, 1000);
  }).catch(function () { btn.disabled = false; });
  return false;
}
</script>
<?php muya_page_end(['area' => 'app']); ?>
