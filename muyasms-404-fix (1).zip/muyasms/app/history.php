<?php
/**
 * MuyaSMS — history: campaigns + messages with filters.
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();

$uid = (int)$u['id'];
$filter = (string)($_GET['f'] ?? 'campaigns');
$campId = (int)($_GET['c'] ?? 0);

muya_page_start(['title' => __('nav_history'), 'area' => 'app', 'active' => 'history']);
?>

<div class="flex mb-2" style="gap:8px">
  <a class="btn <?= $filter === 'campaigns' ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?f=campaigns"><?= e(__('hist_campaigns')) ?></a>
  <a class="btn <?= $filter === 'messages' ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?f=messages"><?= e(__('hist_messages')) ?></a>
</div>

<?php if ($filter === 'campaigns'): ?>
<div class="card">
  <div class="card-title">🚀 <?= e(__('hist_campaigns')) ?></div>
  <?php
  $campaigns = qall('SELECT * FROM campaigns WHERE user_id = ? ORDER BY id DESC LIMIT 100', [$uid]);
  if (!$campaigns): ?>
  <div class="empty"><div class="e-ic">📭</div><?= e(__('no_campaigns')) ?></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th><?= e(__('campaign')) ?></th><th><?= e(__('recipients')) ?></th><th><?= e(__('credits')) ?></th><th><?= e(__('status')) ?></th><th><?= e(__('date')) ?></th>
      </tr></thead>
      <tbody>
      <?php foreach ($campaigns as $c):
        $counts = qr('SELECT
            SUM(CASE WHEN status = \'queued\' THEN 1 ELSE 0 END) AS q, SUM(CASE WHEN status IN (\'sent\',\'delivered\') THEN 1 ELSE 0 END) AS ok, SUM(CASE WHEN status = \'failed\' THEN 1 ELSE 0 END) AS bad
            FROM messages WHERE campaign_id = ?', [(int)$c['id']]);
        $total = (int)$counts['q'] + (int)$counts['ok'] + (int)$counts['bad'];
        $pct = $total ? round(100 * ((int)$counts['ok'] + (int)$counts['bad']) / $total) : 0;
      ?>
      <tr>
        <td>
          <a href="?f=campaigns&c=<?= (int)$c['id'] ?>"><b><?= e($c['name']) ?></b></a>
          <div class="dim small mono"><?= e(mb_substr($c['message'], 0, 48)) ?><?= mb_strlen($c['message']) > 48 ? '…' : '' ?></div>
        </td>
        <td><?= number_format((int)$c['recipients_count']) ?></td>
        <td><?= number_format((int)$c['credits_charged']) ?></td>
        <td><?= status_badge($c['status']) ?>
          <div class="progressbar mt-1" style="width:90px"><div style="width:<?= $pct ?>%"></div></div>
        </td>
        <td class="dim small"><?= e(fmt_dt($c['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php if ($campId):
  $camp = qr('SELECT * FROM campaigns WHERE id = ? AND user_id = ?', [$campId, $uid]);
  if ($camp): ?>
  <div class="card mt-2">
    <div class="card-title">📬 <?= e(__('campaign_detail')) ?> — <?= e($camp['name']) ?></div>
    <?php $msgs = qall('SELECT * FROM messages WHERE campaign_id = ? ORDER BY id ASC LIMIT 500', [$campId]); ?>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr>
          <th><?= e(__('recipient')) ?></th><th><?= e(__('status')) ?></th><th><?= e(__('gateway')) ?></th><th><?= e(__('error_col')) ?></th><th><?= e(__('date')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($msgs as $m): ?>
        <tr>
          <td class="mono"><?= e($m['recipient']) ?></td>
          <td><?= status_badge($m['status']) ?></td>
          <td class="dim small"><?= e($m['gateway_msg_id'] ?: '—') ?></td>
          <td class="dim small"><?= e($m['error'] ?: '—') ?></td>
          <td class="dim small"><?= e(fmt_dt($m['sent_at'] ?: $m['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
<?php endif; ?>

<?php else: ?>
<div class="card">
  <div class="card-title">📨 <?= e(__('hist_messages')) ?></div>
  <?php
  $st = (string)($_GET['st'] ?? '');
  $where = 'user_id = ?';
  $params = [$uid];
  if (in_array($st, ['queued', 'sent', 'delivered', 'failed'], true)) {
      $where .= ' AND status = ?';
      $params[] = $st;
  }
  $msgs = qall("SELECT m.*, c.name AS camp_name FROM messages m LEFT JOIN campaigns c ON c.id = m.campaign_id WHERE $where ORDER BY m.id DESC LIMIT 200", $params);
  ?>
  <div class="flex mb-2" style="gap:7px;flex-wrap:wrap">
    <a class="btn <?= $st === '' ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?f=messages"><?= e(__('hist_all')) ?></a>
    <?php foreach (['sent', 'delivered', 'failed', 'queued'] as $s): ?>
    <a class="btn <?= $st === $s ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="?f=messages&st=<?= $s ?>"><?= e(__('st_' . $s)) ?></a>
    <?php endforeach; ?>
  </div>
  <?php if (!$msgs): ?>
  <div class="empty"><div class="e-ic">📭</div><?= e(__('no_data')) ?></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th><?= e(__('recipient')) ?></th><th><?= e(__('message')) ?></th><th><?= e(__('campaign')) ?></th><th><?= e(__('status')) ?></th><th><?= e(__('date')) ?></th>
      </tr></thead>
      <tbody>
      <?php foreach ($msgs as $m): ?>
      <tr>
        <td class="mono"><?= e($m['recipient']) ?></td>
        <td class="small"><?= e(mb_substr($m['content'], 0, 40)) ?><?= mb_strlen($m['content']) > 40 ? '…' : '' ?></td>
        <td class="dim small"><?= e($m['camp_name'] ?: '—') ?></td>
        <td><?= status_badge($m['status']) ?></td>
        <td class="dim small"><?= e(fmt_dt($m['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>
<?php muya_page_end(['area' => 'app']); ?>
