<?php
/**
 * MuyaSMS — bulk SMS composer.
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();

$groups = qall('SELECT group_name, COUNT(*) AS n FROM contacts WHERE user_id = ? GROUP BY group_name ORDER BY group_name', [(int)$u['id']]);
$verified = (int)$u['company_verified'] === 1;
$verifRequired = setting('bulk_requires_verification', '1') === '1';
$unverifiedLimit = (int)setting('unverified_recipient_limit', 10);
$price = (float)setting('price_per_sms', 1);

muya_page_start(['title' => __('nav_send'), 'area' => 'app', 'active' => 'send']);
?>

<?php if ($verifRequired && !$verified): ?>
<div class="flash flash-warn" style="margin-bottom:16px">
  🛡️ <?= e(__('verif_needed_bulk')) ?> — <a href="verification.php" style="color:var(--gold);font-weight:700"><?= e(__('nav_verification')) ?> →</a>
  <span class="small">(<?= e(sprintf(__('send_limit_unverified'), $unverifiedLimit)) ?>)</span>
</div>
<?php endif; ?>

<div class="grid-2-1">
  <div class="card">
    <div class="card-title">✍️ <?= e(__('send_title')) ?></div>
    <form id="sendForm" onsubmit="return launch(event)">
      <div class="f-group">
        <label class="f-label"><?= e(__('send_name')) ?></label>
        <input class="f-input" id="campName" placeholder="Campaign #<?= date('md') ?>" maxlength="150">
      </div>

      <div class="f-group">
        <label class="f-label flex-between" style="width:100%">
          <span><?= e(__('send_recipients')) ?></span>
          <?php if ($groups): ?>
          <span class="flex" style="gap:6px">
            <select id="groupSel" class="f-input" style="padding:5px 30px 5px 10px;font-size:12px">
              <option value=""><?= e(__('send_insert_group')) ?></option>
              <?php foreach ($groups as $g): ?>
              <option value="<?= e($g['group_name']) ?>"><?= e($g['group_name']) ?> (<?= (int)$g['n'] ?>)</option>
              <?php endforeach; ?>
            </select>
            <button type="button" class="btn btn-ghost btn-sm" onclick="insertGroup()">+</button>
          </span>
          <?php endif; ?>
        </label>
        <textarea class="f-input" id="recipients" rows="7" placeholder="<?= e(__('send_recipients_hint')) ?>" style="font-family:Consolas,monospace;font-size:13px"></textarea>
        <div class="f-hint" id="recipInfo"></div>
      </div>

      <div class="f-group">
        <label class="f-label"><?= e(__('send_message')) ?></label>
        <textarea class="f-input" id="msgText" rows="6" maxlength="1600" placeholder="…"></textarea>
        <div class="f-hint" id="segInfo"></div>
      </div>

      <div class="flex-between mt-1">
        <div class="small muted"><?= e(__('send_cost')) ?>: <b id="costInfo" style="color:var(--gold)">0</b> <?= e(__('credits')) ?></div>
        <button class="btn btn-primary" type="submit" id="sendBtn">🚀 <?= e(__('send_submit')) ?></button>
      </div>
    </form>
  </div>

  <div>
    <div class="card">
      <div class="card-title">📱 <?= e(__('send_preview')) ?></div>
      <div class="phone-stage">
        <div class="phone">
          <div class="phone-screen">
            <div class="phone-notch"></div>
            <div class="phone-msg" id="phoneMsg">…</div>
            <div class="phone-meta"><?= e(setting('platform_name', 'MuyaSMS')) ?> · <span id="phoneTime"><?= date('H:i') ?></span></div>
          </div>
        </div>
      </div>
    </div>
    <div class="card mt-2">
      <div class="kv"><span class="k"><?= e(__('dash_credits')) ?></span><span class="v" style="color:var(--gold)"><?= number_format((int)$u['credits']) ?></span></div>
      <div class="kv"><span class="k"><?= e(__('price_per_sms')) ?></span><span class="v"><?= e(money_etb($price)) ?></span></div>
      <div class="kv"><span class="k"><?= e(__('nav_verification')) ?></span><span class="v"><?= $verified ? '✅ ' . e(__('st_approved')) : '⚠️ ' . e(__('verif_status_none')) ?></span></div>
    </div>
  </div>
</div>

<script>
var M = window.MUYA || {};
var pricePerSms = <?= json_encode((float)$price) ?>;

function parseRecipients() {
  var raw = document.getElementById('recipients').value || '';
  var seen = {}, ok = 0;
  raw.split(/[\n,;]+/).forEach(function (item) {
    item = item.trim();
    if (!item) return;
    var p = normPhone(item);
    if (p && !seen[p]) { seen[p] = 1; ok++; }
  });
  return ok;
}
function normPhone(p) {
  p = p.replace(/[\s\-().]/g, '');
  var m = /^(?:0)?(9\d{8})$/.exec(p); if (m) return '+251' + m[1];
  m = /^251(9\d{8})$/.exec(p); if (m) return '+251' + m[1];
  if (/^\+[1-9]\d{7,14}$/.test(p)) return p;
  return null;
}
function segCount(txt) {
  var isUni = /[^\u0000-\u007F£¥èéùìòÇØøÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ¡ÄÖÑÜ§¿äöñüà\f^{}\[\]~|€]/.test(txt);
  var len = Array.from(txt).length;
  var single = isUni ? 70 : 160, concat = isUni ? 67 : 153;
  if (len === 0) return 0;
  return len <= single ? 1 : Math.ceil(len / concat);
}
window.muyaEstimate = function () {
  var txt = document.getElementById('msgText').value || '';
  var segs = segCount(txt) || 1;
  var n = parseRecipients();
  var credits = n * segs;
  document.getElementById('costInfo').textContent = credits.toLocaleString();
  document.getElementById('recipInfo').textContent = n + ' ✓';
};

document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('recipients').addEventListener('input', window.muyaEstimate);
  var msg = document.getElementById('msgText');
  msg.addEventListener('input', function () {
    document.getElementById('phoneMsg').textContent = msg.value || '…';
  });
  var sel = document.getElementById('groupSel');
  if (sel) sel.addEventListener('change', insertGroup);
  window.muyaEstimate();
});

function insertGroup() {
  var sel = document.getElementById('groupSel');
  if (!sel || !sel.value) return;
  window.muyaApi('../api/contacts.php', { op: 'list_group', group: sel.value }, { silent: true })
    .then(function (j) {
      var ta = document.getElementById('recipients');
      var lines = (ta.value.trim() ? ta.value.trim() + '\n' : '') + j.phones.join('\n');
      ta.value = lines;
      window.muyaEstimate();
    })
    .catch(function () { sel.value = ''; });
}

function launch(ev) {
  ev.preventDefault();
  var btn = document.getElementById('sendBtn');
  var name = document.getElementById('campName').value.trim();
  var recipients = document.getElementById('recipients').value;
  var message = document.getElementById('msgText').value;
  if (!message.trim() || !recipients.trim()) { alert('Please fill in recipients and message.'); return false; }
  btn.disabled = true;
  window.muyaApi('../api/campaigns.php', {
    op: 'launch',
    name: name || ('Campaign ' + new Date().toISOString().slice(0, 10)),
    recipients: recipients,
    message: message
  }).then(function (j) {
    window.muyaToast(j.msg || '✓', 'ok');
    setTimeout(function () { location.href = 'history.php'; }, 900);
  }).catch(function () { btn.disabled = false; });
  return false;
}
</script>
<?php muya_page_end(['area' => 'app']); ?>
