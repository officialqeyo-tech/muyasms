<?php
/**
 * MuyaSMS — customer dashboard (real data only).
 */
require __DIR__ . '/../includes/bootstrap.php';
$u = require_user();
web_dispatch_tick();

$uid = (int)$u['id'];

// KPIs — computed from the database
$last24 = is_pg() ? 'NOW() - INTERVAL \'24 hours\'' : 'NOW() - INTERVAL 24 HOUR';
$sent24 = (int)qv('SELECT COUNT(*) FROM messages WHERE user_id = ? AND created_at >= ' . $last24, [$uid]);
$delivRate = null;
$row = qr('SELECT
    SUM(CASE WHEN status IN (\'sent\',\'delivered\') THEN 1 ELSE 0 END) AS ok,
    SUM(CASE WHEN status = \'failed\' THEN 1 ELSE 0 END) AS bad
    FROM messages WHERE user_id = ?', [$uid]);
if ($row && ((int)$row['ok'] + (int)$row['bad']) > 0) {
    $delivRate = round(100 * (int)$row['ok'] / ((int)$row['ok'] + (int)$row['bad']), 1);
}
$pendingTx = (int)qv('SELECT COUNT(*) FROM wallet_transactions WHERE user_id = ? AND status = \'pending\'', [$uid]);

// throughput last 24h (hourly)
$hours = [];
$labels = [];
for ($i = 23; $i >= 0; $i--) {
    $hStart = date('Y-m-d H:00:00', strtotime("-$i hour"));
    $hEnd   = date('Y-m-d H:00:00', strtotime("-" . ($i - 1) . " hour"));
    $labels[] = date('H', strtotime($hStart));
    $hours[] = (int)qv('SELECT COUNT(*) FROM messages WHERE user_id = ? AND created_at >= ? AND created_at < ?', [$uid, $hStart, $hEnd]);
}

// status donut
$statuses = ['sent', 'delivered', 'failed', 'queued'];
$donut = [];
foreach ($statuses as $st) {
    $donut[$st] = (int)qv('SELECT COUNT(*) FROM messages WHERE user_id = ? AND status = ?', [$uid, $st]);
}

$campaigns = qall('SELECT * FROM campaigns WHERE user_id = ? ORDER BY id DESC LIMIT 6', [$uid]);
$activeGateway = (bool)qv('SELECT COUNT(*) FROM gateways WHERE status = \'active\'');

muya_page_start(['title' => __('nav_dashboard'), 'area' => 'app', 'active' => 'dashboard']);
?>

<?php if (!$activeGateway): ?>
<div class="flash flash-warn" style="margin-bottom:18px"><?= e(__('no_gateway_warn')) ?></div>
<?php endif; ?>

<div class="stat-grid">
  <div class="card card-3d stat-card stat-g" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('card') ?></div>
    <div class="stat-label"><?= e(__('dash_credits')) ?></div>
    <div class="stat-value" data-count="<?= (int)$u['credits'] ?>">0</div>
    <div class="stat-sub"><?= e(__('sms_credits')) ?></div>
  </div>
  <div class="card card-3d stat-card stat-b" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('send') ?></div>
    <div class="stat-label"><?= e(__('dash_sent_24h')) ?></div>
    <div class="stat-value" data-count="<?= $sent24 ?>">0</div>
    <div class="stat-sub"><?= e(__('dash_chart')) ?></div>
  </div>
  <div class="card card-3d stat-card stat-e" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('zap') ?></div>
    <div class="stat-label"><?= e(__('dash_delivered')) ?></div>
    <div class="stat-value"><?= $delivRate === null ? '—' : '<span data-count="' . $delivRate . '" data-decimals="1" data-suffix="%">0%</span>' ?></div>
    <div class="stat-sub"><?= e(__('hist_messages')) ?></div>
  </div>
  <div class="card card-3d stat-card stat-o" data-tilt="7">
    <div class="stat-ic"><?= muya_icon('clock') ?></div>
    <div class="stat-label"><?= e(__('dash_pending')) ?></div>
    <div class="stat-value" data-count="<?= $pendingTx ?>">0</div>
    <div class="stat-sub"><?= e(__('waiting_approval')) ?></div>
  </div>
</div>

<div class="mt-2 grid-2-1">
  <div class="card">
    <div class="card-title">📈 <?= e(__('dash_chart')) ?></div>
    <div class="chart-box"><canvas id="throughputChart"></canvas></div>
  </div>
  <div class="card">
    <div class="card-title">🍩 <?= e(__('hist_messages')) ?></div>
    <div class="donut-wrap">
      <div class="chart-box" style="height:170px;width:170px;flex-shrink:0"><canvas id="statusDonut"></canvas></div>
      <div class="donut-legend">
        <span><span class="legend-dot" style="background:#3B82F6"></span><?= e(__('st_sent')) ?> — <?= $donut['sent'] ?></span>
        <span><span class="legend-dot" style="background:#10B981"></span><?= e(__('st_delivered')) ?> — <?= $donut['delivered'] ?></span>
        <span><span class="legend-dot" style="background:#EF4444"></span><?= e(__('st_failed')) ?> — <?= $donut['failed'] ?></span>
        <span><span class="legend-dot" style="background:#F59E0B"></span><?= e(__('st_queued')) ?> — <?= $donut['queued'] ?></span>
      </div>
    </div>
  </div>
</div>

<div class="mt-2 card">
  <div class="card-title">
    🚀 <?= e(__('dash_recent')) ?>
    <a class="tsub" href="history.php"><?= e(__('view_all')) ?> →</a>
  </div>
  <?php if (!$campaigns): ?>
    <div class="empty"><div class="e-ic">📭</div><?= e(__('no_campaigns')) ?><div class="mt-1"><a class="btn btn-primary btn-sm" href="send.php"><?= e(__('quick_send')) ?> →</a></div></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th><?= e(__('campaign')) ?></th><th><?= e(__('recipients')) ?></th><th><?= e(__('status')) ?></th><th><?= e(__('date')) ?></th>
      </tr></thead>
      <tbody>
        <?php foreach ($campaigns as $c): ?>
        <tr>
          <td><b><?= e($c['name']) ?></b><div class="dim small mono"><?= e(mb_substr($c['message'], 0, 42)) ?><?= mb_strlen($c['message']) > 42 ? '…' : '' ?></div></td>
          <td><?= number_format((int)$c['recipients_count']) ?></td>
          <td><?= status_badge($c['status']) ?></td>
          <td class="dim"><?= e(time_ago($c['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<script>
window.addEventListener('DOMContentLoaded', function () {
  var C = window.muyaCharts;
  C.line(document.getElementById('throughputChart'), [
    { color: '#10B981', data: <?= json_encode($hours) ?> }
  ], { labels: <?= json_encode($labels) ?> });
  C.donut(document.getElementById('statusDonut'), [
    { color: '#3B82F6', value: <?= $donut['sent'] ?> },
    { color: '#10B981', value: <?= $donut['delivered'] ?> },
    { color: '#EF4444', value: <?= $donut['failed'] ?> },
    { color: '#F59E0B', value: <?= $donut['queued'] ?> }
  ]);
  setInterval(function () { location.reload(); }, 60000);
});
</script>
<?php muya_page_end(['area' => 'app']); ?>
