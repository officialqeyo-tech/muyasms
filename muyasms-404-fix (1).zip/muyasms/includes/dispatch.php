<?php
/**
 * MuyaSMS — delivery engine.
 * Processes queued messages through admin-configured HTTP gateways.
 * Runs via cron/dispatch.php (cPanel cron) and as a throttled web fallback.
 */

/** Pick the default active gateway (lowest priority number wins). */
function pick_gateway(): ?array
{
    return qr('SELECT * FROM gateways WHERE status = \'active\' ORDER BY is_default DESC, priority ASC, id ASC LIMIT 1');
}

/**
 * Render a gateway template (body or headers JSON).
 * Tokens: {{recipient}} {{message}} {{sender}} {{timestamp}} {{id}}
 */
function gateway_render(string $template, string $recipient, string $message, ?string $sender, int $msgId): string
{
    $jsonSafe = function (string $s): string {
        // placeholder to be replaced with a JSON string value including quotes
        return '__MUYA_JSON__' . base64_encode($s) . '__MUYA_JSON__';
    };
    $out = str_replace(
        ['{{recipient}}', '{{message}}', '{{sender}}', '{{timestamp}}', '{{id}}'],
        [
            $jsonSafe($recipient),
            $jsonSafe($message),
            $jsonSafe((string)$sender),
            (string)time(),
            (string)$msgId,
        ],
        $template
    );
    // convert placeholders into real JSON strings (handles both JSON bodies and raw bodies)
    $out = preg_replace_callback('/"__MUYA_JSON__([A-Za-z0-9+\/=]+)__MUYA_JSON__"/', function ($m) {
        $decoded = base64_decode($m[1]);
        return json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }, $out);
    // if template used bare {{token}} without quotes
    $out = preg_replace_callback('/__MUYA_JSON__([A-Za-z0-9+\/=]+)__MUYA_JSON__/', function ($m) {
        $decoded = base64_decode($m[1]);
        return json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }, $out);
    return $out;
}

/**
 * Send one message through a gateway.
 * Returns ['ok'=>bool,'delivered'=>bool,'gateway_id'=>string|null,'error'=>string|null,'response'=>string]
 */
function gateway_send(array $gw, string $recipient, string $message, int $msgId): array
{
    $sender = $gw['sender_id'] ?: 'MuyaSMS';
    $url    = $gw['api_url'];
    $method = $gw['http_method'] === 'GET' ? 'GET' : 'POST';

    $headers = [];
    $headersJson = trim((string)$gw['headers_json']);
    if ($headersJson !== '') {
        $rendered = gateway_render($headersJson, $recipient, $message, $sender, $msgId);
        $decoded = json_decode($rendered, true);
        if (is_array($decoded)) {
            foreach ($decoded as $k => $v) $headers[] = $k . ': ' . (is_scalar($v) ? (string)$v : json_encode($v));
        }
    }

    $body = null;
    $finalUrl = $url;
    if ($method === 'POST') {
        $tpl = (string)$gw['body_template'];
        if ($tpl === '') $tpl = '{"to":"{{recipient}}","from":"{{sender}}","message":"{{message}}"}';
        $body = gateway_render($tpl, $recipient, $message, $sender, $msgId);
        $headers[] = 'Content-Type: application/json';
    } else {
        // GET: render query string into URL
        $qs = gateway_render((string)$gw['body_template'], $recipient, $message, $sender, $msgId);
        $qs = ltrim(trim($qs), '?');
        $finalUrl = $url . (strpos($url, '?') === false ? '?' : '&') . $qs;
    }

    $ch = curl_init($finalUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_TIMEOUT        => max(3, min(60, (int)$gw['timeout_sec'])),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_USERAGENT      => 'MuyaSMS-Engine/1.0',
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    if ($headers) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $resp     = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err      = curl_error($ch);
    curl_close($ch);

    if ($resp === false) {
        return ['ok' => false, 'delivered' => false, 'gateway_id' => null, 'error' => mb_substr('cURL: ' . $err, 0, 250), 'response' => ''];
    }
    $respText = is_string($resp) ? mb_substr($resp, 0, 1000) : '';

    // success condition: substring in response body, "http:NNN", or empty → 2xx
    $cond = trim((string)$gw['success_condition']);
    $ok = false;
    if ($cond === '') {
        $ok = $httpCode >= 200 && $httpCode < 300;
    } elseif (preg_match('/^http:(\d+)$/i', $cond, $m)) {
        $ok = $httpCode === (int)$m[1];
    } else {
        $ok = strpos($respText, $cond) !== false;
    }

    $delivered = false;
    $dcond = trim((string)$gw['delivered_condition']);
    if ($ok && $dcond !== '') {
        $delivered = strpos($respText, $dcond) !== false;
    }

    $gid = null;
    $idRegex = trim((string)$gw['id_regex']);
    if ($idRegex !== '' && preg_match($idRegex, $respText, $m)) {
        $gid = isset($m[1]) ? $m[1] : $m[0];
        $gid = mb_substr($gid, 0, 110);
    }

    return [
        'ok'         => $ok,
        'delivered'  => $delivered,
        'gateway_id' => $gid,
        'error'      => $ok ? null : mb_substr('HTTP ' . $httpCode . ' — condition not met', 0, 250),
        'response'   => $respText,
    ];
}

/**
 * Process queued messages (batch). Returns [processed, sent, failed].
 * Respects per-gateway max_per_second.
 */
function process_queue(): array
{
    $stats = ['processed' => 0, 'sent' => 0, 'failed' => 0];
    $lockF = ROOT . '/storage/dispatch.lock';
    $fh = fopen($lockF, 'c');
    if (!$fh) return $stats;
    if (!flock($fh, LOCK_EX | LOCK_NB)) {
        fclose($fh);
        return $stats; // another worker is running
    }

    try {
        $batch = max(1, min(200, (int)setting('dispatch_batch_size', 25)));
        $gw = pick_gateway();
        if (!$gw) { flock($fh, LOCK_UN); fclose($fh); return $stats; }

        $msgs = qall('SELECT * FROM messages WHERE status = \'queued\' ORDER BY id ASC LIMIT ' . (int)$batch);
        $minGapUsec = $gw['max_per_second'] > 0 ? (int)floor(1000000 / max(1, (int)$gw['max_per_second'])) : 0;

        foreach ($msgs as $msg) {
            if ($msg['campaign_id']) {
                q('UPDATE campaigns SET status = \'sending\' WHERE id = ? AND status = \'queued\'', [$msg['campaign_id']]);
            }
            $attempts = 0;
            $maxTries = 1 + max(0, min(5, (int)$gw['retries']));
            $result = null;
            while ($attempts < $maxTries) {
                $attempts++;
                $result = gateway_send($gw, $msg['recipient'], $msg['content'], (int)$msg['id']);
                if ($result['ok']) break;
                usleep(300000); // 0.3s between retries
            }
            $stats['processed']++;
            if ($result['ok']) {
                $stats['sent']++;
                q('UPDATE messages SET status = ?, gateway_msg_id = ?, gateway_id = ?, sent_at = NOW(), error = NULL WHERE id = ?', [
                    $result['delivered'] ? 'delivered' : 'sent',
                    $result['gateway_id'], $gw['id'], $msg['id'],
                ]);
            } else {
                $stats['failed']++;
                q('UPDATE messages SET status = \'failed\', gateway_id = ?, error = ?, sent_at = NOW() WHERE id = ?', [
                    $gw['id'], $result['error'], $msg['id'],
                ]);
            }
            if ($minGapUsec > 0) usleep($minGapUsec);
        }

        // finalize campaigns whose messages are all done
        q('UPDATE campaigns c
           SET c.status = \'completed\', c.finished_at = NOW()
           WHERE c.status = \'sending\'
             AND NOT EXISTS (SELECT 1 FROM messages m WHERE m.campaign_id = c.id AND m.status = \'queued\')');
    } catch (Throwable $e) {
        error_log('dispatch error: ' . $e->getMessage());
    }

    flock($fh, LOCK_UN);
    fclose($fh);
    return $stats;
}

/** Throttled web fallback — called on dashboard/admin page loads. */
function web_dispatch_tick(): void
{
    $f = ROOT . '/storage/dispatch.last';
    $interval = max(5, (int)setting('dispatch_interval_sec', 20));
    if (is_file($f)) {
        $last = (int)@file_get_contents($f);
        if (time() - $last < $interval) return;
    }
    @file_put_contents($f, (string)time(), LOCK_EX);
    try {
        process_queue();
    } catch (Throwable $e) {
        error_log('web tick: ' . $e->getMessage());
    }
}
