<?php
/**
 * MuyaSMS — security core: headers, session hardening, CSRF,
 * rate limiting, audit log, JSON output helpers.
 */

// ---- Security headers ----
function send_security_headers(): void
{
    if (headers_sent()) return;
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 0'); // modern browsers: disabled legacy filter, CSP handles it
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
}

function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') return true;
    if (($_SERVER['SERVER_PORT'] ?? '') == '443') return true;
    return false;
}

// ---- Session hardening ----
function muya_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $lifetime = 0;
    session_name('MUYASESS');
    session_set_cookie_params([
        'lifetime' => $lifetime,
        'path'     => '/',
        'domain'   => '',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    // Session fingerprint (mitigates hijacking)
    $fp = hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? 'ua') . '|muya-fp-salt|' . session_name());
    if (!isset($_SESSION['fp'])) {
        $_SESSION['fp'] = $fp;
    } elseif (!hash_equals($_SESSION['fp'], $fp)) {
        session_destroy();
        session_start();
        session_regenerate_id(true);
        $_SESSION['fp'] = $fp;
    }

    // Absolute session timeout (12h)
    if (isset($_SESSION['last']) && time() - $_SESSION['last'] > 43200) {
        session_unset();
        session_destroy();
        session_start();
    }
    // Idle timeout (60 min)
    if (isset($_SESSION['last']) && time() - $_SESSION['last'] > 3600 && !empty($_SESSION['uid'])) {
        unset($_SESSION['uid']);
        flash_set('warn', __('session_expired'));
    }
    $_SESSION['last'] = time();
}

// ---- CSRF ----
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = rand_token(32);
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}
/** Validate CSRF (POST + JSON body). Kills request on failure. */
function require_csrf(): void
{
    $sent = $_POST['csrf'] ?? '';
    if (!$sent && isset($_SERVER['CONTENT_TYPE']) && stripos($_SERVER['CONTENT_TYPE'], 'application/json') === 0) {
        $body = json_decode((string)file_get_contents('php://input'), true);
        if (is_array($body)) $sent = $body['csrf'] ?? '';
        if (!$sent) $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    }
    if (!$sent) $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        if (json_out_request()) {
            json_out(['ok' => false, 'error' => 'Invalid security token. Refresh the page.'], 403);
        }
        http_response_code(403);
        exit('Invalid security token. Go back, refresh the page and try again.');
    }
}
/** Same-origin check for state-changing requests. */
function require_same_origin(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $host   = $_SERVER['HTTP_HOST'] ?? '';
    if ($origin === '' ) return; // non-CORS browser POST
    $originHost = parse_url($origin, PHP_URL_HOST);
    $same = $originHost !== null && strcasecmp($originHost, $host) === 0;
    if (!$same) {
        json_out(['ok' => false, 'error' => 'Cross-origin request blocked.'], 403);
    }
}

// ---- JSON output ----
function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function json_fail(string $msg, int $code = 400): void
{
    json_out(['ok' => false, 'error' => $msg], $code);
}

// ---- Client IP ----
function client_ip(): string
{
    // Direct connection only — cPanel PHP runs without trusted reverse proxy.
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

// ---- Rate limiting (file-based, per scope+IP) ----
function rl_file(string $scope): string
{
    $dir = ROOT . '/storage/rl';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir . '/' . preg_replace('/[^a-z0-9_.-]/i', '_', $scope) . '_' . md5(client_ip()) . '.json';
}
/** Check + increment. Returns true if allowed. */
function rl_check(string $scope, int $max, int $windowSec): bool
{
    $f = rl_file($scope);
    $now = time();
    $hits = [];
    if (is_file($f)) {
        $hits = json_decode((string)@file_get_contents($f), true);
        if (!is_array($hits)) $hits = [];
        $hits = array_values(array_filter($hits, function ($t) use ($now, $windowSec) {
            return is_int($t) && ($now - $t) < $windowSec;
        }));
    }
    if (count($hits) >= $max) return false;
    $hits[] = $now;
    @file_put_contents($f, json_encode($hits), LOCK_EX);
    return true;
}

// ---- Audit log ----
function audit(string $action, string $details = ''): void
{
    $u = function_exists('current_user') ? current_user() : null;
    try {
        q('INSERT INTO audit_log (user_id, actor_email, action, details, ip) VALUES (?,?,?,?,?)', [
            $u['id'] ?? null,
            $u['email'] ?? (($_SERVER['AUTH_USER_EMAIL'] ?? '') ?: null),
            $action,
            mb_substr($details, 0, 490),
            client_ip(),
        ]);
    } catch (Throwable $e) {
        error_log('audit fail: ' . $e->getMessage());
    }
}

// ---- Input sanitizers ----
function post_str(string $key, int $maxLen = 500): string
{
    $v = $_POST[$key] ?? '';
    if (!is_string($v)) return '';
    $v = trim($v);
    if (function_exists('mb_substr')) $v = mb_substr($v, 0, $maxLen);
    else $v = substr($v, 0, $maxLen);
    return $v;
}
function post_email(string $key): string
{
    $v = strtolower(trim((string)($_POST[$key] ?? '')));
    return filter_var($v, FILTER_VALIDATE_EMAIL) ? $v : '';
}
function post_int(string $key, int $default = 0): int
{
    return isset($_POST[$key]) && is_numeric($_POST[$key]) ? (int)$_POST[$key] : $default;
}
