<?php
/**
 * MuyaSMS — PDO database layer (prepared statements only).
 * Works with MySQL AND PostgreSQL (cPanel hosts offer either —
 * set DB_DRIVER in config/config.php: 'mysql' or 'pgsql').
 */

/** Active SQL driver name: 'mysql' or 'pgsql'. */
function db_driver(): string
{
    $d = strtolower(trim(defined('DB_DRIVER') ? DB_DRIVER : 'mysql'));
    return ($d === 'pgsql' || $d === 'postgres' || $d === 'postgresql') ? 'pgsql' : 'mysql';
}

/** True when the database is PostgreSQL. */
function is_pg(): bool
{
    return db_driver() === 'pgsql';
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        if (is_pg()) {
            // DB_HOST 'localhost' = TCP ; a path like '/var/run/postgresql' = unix socket
            $port = defined('DB_PORT') ? (int)DB_PORT : 5432;
            $dsn  = 'pgsql:host=' . DB_HOST . ';port=' . $port . ';dbname=' . DB_NAME;
        } else {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        }
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

/**
 * Last inserted id (driver-aware).
 * Call IMMEDIATELY after an INSERT into a table whose id is
 * AUTO_INCREMENT (MySQL) or SERIAL (PostgreSQL).
 */
function db_last_id(): int
{
    if (is_pg()) {
        return (int)qv('SELECT LASTVAL()');
    }
    return (int)db()->lastInsertId();
}

/** Does a table exist? (driver-aware; $table must be a fixed name from our own code) */
function db_table_exists(string $table): bool
{
    if (is_pg()) {
        return (bool)qv("SELECT to_regclass('public." . $table . "') IS NOT NULL");
    }
    return (bool)qv("SHOW TABLES LIKE '" . $table . "'");
}

/** Run a prepared statement. */
function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

/** Fetch one row or null. */
function qr(string $sql, array $params = []): ?array
{
    $r = q($sql, $params)->fetch();
    return $r === false ? null : $r;
}

/** Fetch all rows. */
function qall(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

/** Fetch first column of first row (scalar helper). */
function qv(string $sql, array $params = [])
{
    $v = q($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}
