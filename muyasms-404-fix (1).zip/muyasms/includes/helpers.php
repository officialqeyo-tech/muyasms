<?php
/**
 * MuyaSMS — general helpers.
 */

/** HTML-escape (XSS protection) — use on EVERY dynamic output. */
function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function base_url(string $path = ''): string
{
    $base = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
    return $base . $path;
}

// ---- Flash messages ----
function flash_set(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}
function flash_get(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

// ---- Settings (cached per request) ----
$GLOBALS['muya_settings'] = null;
function load_settings(): void
{
    $GLOBALS['muya_settings'] = [];
    try {
        foreach (qall('SELECT skey, svalue FROM settings') as $r) {
            $GLOBALS['muya_settings'][$r['skey']] = $r['svalue'];
        }
    } catch (Throwable $e) {
        // settings table not created yet (installer flow)
    }
}
function setting(string $key, $default = null)
{
    $v = $GLOBALS['muya_settings'][$key] ?? null;
    return ($v === null || $v === '') ? $default : $v;
}
function setting_set(string $key, $value): void
{
    if (is_pg()) {
        q('INSERT INTO settings (skey, svalue) VALUES (?, ?) ON CONFLICT (skey) DO UPDATE SET svalue = EXCLUDED.svalue', [$key, (string)$value]);
    } else {
        q('INSERT INTO settings (skey, svalue) VALUES (?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)', [$key, (string)$value]);
    }
    $GLOBALS['muya_settings'][$key] = (string)$value;
}

// ---- Formatting ----
function money_etb($v): string
{
    return 'ETB ' . number_format((float)$v, 2);
}
function fmt_dt(?string $dt): string
{
    if (!$dt) return '—';
    $t = strtotime($dt);
    return date('M j, Y H:i', $t);
}
function time_ago(?string $dt): string
{
    if (!$dt) return '—';
    $diff = time() - strtotime($dt);
    if ($diff < 60) return __('just_now');
    if ($diff < 3600) return floor($diff / 60) . ' ' . __('minutes_ago');
    if ($diff < 86400) return floor($diff / 3600) . ' ' . __('hours_ago');
    return floor($diff / 86400) . ' ' . __('days_ago');
}
function status_badge(string $status): string
{
    $map = [
        'queued'    => 'badge-amber',
        'sending'   => 'badge-blue',
        'sent'      => 'badge-blue',
        'delivered' => 'badge-green',
        'failed'    => 'badge-red',
        'completed' => 'badge-green',
        'cancelled' => 'badge-red',
        'approved'  => 'badge-green',
        'rejected'  => 'badge-red',
        'pending'   => 'badge-amber',
        'active'    => 'badge-green',
        'suspended' => 'badge-red',
        'inactive'  => 'badge-amber',
    ];
    $cls = $map[$status] ?? 'badge-gray';
    return '<span class="badge ' . $cls . '">' . e(__('st_' . $status)) . '</span>';
}

/** Random hex token. */
function rand_token(int $bytes = 32): string
{
    return bin2hex(random_bytes($bytes));
}

/** Random reference code, e.g. MUYA-7F3K9Q. */
function gen_ref(): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $s = '';
    for ($i = 0; $i < 6; $i++) $s .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    return 'MUYA-' . $s;
}

/** Is this an AJAX/JSON request? */
function json_out_request(): bool
{
    $ax = $_SERVER['HTTP_X_REQUESTED_WITH'] ?? '';
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    return strcasecmp($ax, 'xmlhttprequest') === 0 || strpos($accept, 'application/json') !== false;
}
