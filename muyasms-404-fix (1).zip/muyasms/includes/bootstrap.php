<?php
/**
 * MuyaSMS — application bootstrap.
 * Loads config, error handling, security headers, session, settings, i18n.
 */

define('MUYA', true);
define('ROOT', dirname(__DIR__));
define('INC', __DIR__);

/** Redirect to the installer with an ABSOLUTE path (works from any subpage). */
function muya_install_redirect(): void
{
    $base = '';
    $doc  = rtrim(str_replace('\\', '/', (string)($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
    $root = str_replace('\\', '/', ROOT);
    if ($doc !== '' && strpos($root, $doc) === 0) {
        $base = substr($root, strlen($doc));            // e.g. "/muyasms"
    } elseif (defined('APP_URL')) {
        $base = (string)preg_replace('#^[a-z]+://[^/]+#i', '', APP_URL);
    }
    header('Location: ' . $base . '/install.php');
    exit;
}

// ---- Config (redirect to installer if missing) ----
if (!is_file(ROOT . '/config/config.php')) {
    if (is_file(ROOT . '/install.php')) {
        muya_install_redirect();
    }
    http_response_code(500);
    exit('MuyaSMS is not configured.');
}
require ROOT . '/config/config.php';

// ---- Error handling ----
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', ROOT . '/storage/php-error.log');
if (defined('APP_DEBUG') && APP_DEBUG) {
    ini_set('display_errors', '1');
}
set_exception_handler(function ($e) {
    error_log('UNCAUGHT: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (function_exists('json_out_request') && json_out_request()) {
        json_out(['ok' => false, 'error' => 'Server error. Please try again later.'], 500);
    }
    http_response_code(500);
    if (defined('APP_DEBUG') && APP_DEBUG) {
        exit('<pre>' . htmlspecialchars((string)$e) . '</pre>');
    }
    exit('<!doctype html><meta charset="utf-8"><body style="background:#0A0D12;color:#94A3B8;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div><h2 style="color:#F8FAFC">Something went wrong</h2><p>Try again in a moment. The error has been logged.</p></div>');
});

require INC . '/helpers.php';
require INC . '/db.php';
require INC . '/security.php';
require INC . '/i18n.php';
require INC . '/auth.php';
require INC . '/sms.php';
require INC . '/mailer.php';
require INC . '/dispatch.php';
require INC . '/layout.php';   // muya_icon / muya_logo_svg / page shell (function-only file)

// ---- Security headers ----
send_security_headers();

// ---- Session ----
muya_session_start();

// ---- CSRF token ----
csrf_token();

// ---- Settings ----
load_settings();

// ---- Language (en / am) ----
lang_init();

// ---- Fresh deployment? Send every visitor to the installer ----
// (No installed.lock yet + users table unreachable/missing → install.php
//  shows the quick-fix DB form. Prevents the raw "Something went wrong"
//  500 page during first setup.)
if (!is_file(ROOT . '/storage/installed.lock')
    && is_file(ROOT . '/install.php')
    && PHP_SAPI !== 'cli'
    && strpos($_SERVER['SCRIPT_NAME'] ?? '', 'install.php') === false) {
    try {
        $muya_probe = db_table_exists('users');
    } catch (Throwable $muya_e) {
        $muya_probe = null;
    }
    if (!$muya_probe) {
        muya_install_redirect();
    }
}

// ---- Maintenance mode (admins always pass) ----
$muya_user = current_user();
if (setting('maintenance_mode') === '1' && php_sapi_name() !== 'cli') {
    $isAdmin = $muya_user && in_array($muya_user['role'], ['admin', 'staff'], true);
    $isInstall = strpos($_SERVER['SCRIPT_NAME'] ?? '', 'install.php') !== false;
    $isAdminArea = strpos($_SERVER['SCRIPT_NAME'] ?? '', '/admin/') !== false;
    if (!$isAdmin && !$isInstall && !$isAdminArea) {
        http_response_code(503);
        header('Retry-After: 3600');
        exit('<!doctype html><meta charset="utf-8"><title>Maintenance</title><body style="background:#0A0D12;color:#94A3B8;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div style="text-align:center"><div style="font-size:44px">🛠️</div><h2 style="color:#F8FAFC">MuyaSMS is under maintenance</h2><p>We will be back shortly. / በቅርቡ እንመለሳለን።</p></div></body>');
    }
}
