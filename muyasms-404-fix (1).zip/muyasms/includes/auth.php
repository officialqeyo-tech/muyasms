<?php
/**
 * MuyaSMS — authentication (v2 — instant accounts).
 *
 * FLOW:
 *   - Customers self-register (name, email, phone, company optional, password)
 *     → account is ACTIVE IMMEDIATELY (no admin approval, no waiting).
 *   - Signup bonus credits are granted at registration.
 *   - Sign-in works with EMAIL or PHONE + password.
 *   - Email verification is still sent, but it NEVER blocks the account.
 *   - Admins only approve telebirr PAYMENTS (wallet) and enterprise
 *     verification documents — never account creation.
 *
 * Phone numbers are stored in E.164 (+2519…) via normalize_phone()
 * from includes/sms.php — the SAME function used for SMS recipients,
 * so account phones and recipient phones always share one format.
 *
 * Super-admin (officialqeyo@gmail.com) is created by install.php.
 */

// (normalize_phone lives in includes/sms.php — reused here for login/registration)

/** Find a user by email OR phone (used by login + password reset). */
function find_user_by_login(string $login): ?array
{
    $login = trim($login);
    if ($login === '') return null;
    if (strpos($login, '@') !== false) {
        return qr('SELECT * FROM users WHERE email = ?', [strtolower($login)]);
    }
    $ph = normalize_phone($login);          // E.164 (+2519…) or null
    if ($ph === null || $ph === '') return null;
    return qr('SELECT * FROM users WHERE phone = ?', [$ph]);
}

function current_user(): ?array
{
    static $u = null;
    static $loaded = false;
    if (!$loaded) {
        $loaded = true;
        if (!empty($_SESSION['uid'])) {
            // NOTE: 'pending' users are allowed — accounts are active from
            // the moment they are created. Only 'suspended' is blocked.
            $u = qr('SELECT * FROM users WHERE id = ? AND status != \'suspended\'', [(int)$_SESSION['uid']]);
            if (!$u) {
                unset($_SESSION['uid']);
            }
        }
    }
    return $u;
}

function is_admin(): bool
{
    $u = current_user();
    return $u && in_array($u['role'], ['admin', 'staff'], true);
}

function is_super(): bool
{
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

/** Require any signed-in customer/admin (page guard). */
function require_user(): array
{
    $u = current_user();
    if (!$u) redirect('../signin.php');
    return $u;
}

/** Require admin/staff role (admin panel guard). */
function require_admin(): array
{
    $u = current_user();
    if (!$u || !in_array($u['role'], ['admin', 'staff'], true)) {
        redirect('index.php');
    }
    return $u;
}

/** Require super-admin role. */
function require_super(): array
{
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') {
        redirect('dashboard.php');
    }
    return $u;
}

// ---- Login ----

/**
 * Attempt sign-in with EMAIL or PHONE + password.
 * $panel = 'admin' → ONLY admin/staff emails are accepted (admin panel rule).
 * $panel = 'app'   → customers (admins may also sign in; redirected to admin panel).
 * Returns [ok(bool), error(string)].
 */
function attempt_login(string $login, string $password, string $panel = 'app'): array
{
    $login = trim($login);
    if ($login === '' || $password === '') return [false, __('err_fields')];

    $u = find_user_by_login($login);

    // Uniform failure message (no user-enumeration)
    $generic = __('err_login');
    if (!$u) return [false, $generic];

    // Admin panel: only administrator emails may sign in here
    if ($panel === 'admin' && !in_array($u['role'], ['admin', 'staff'], true)) {
        audit('login_denied', 'Non-admin email tried admin panel: ' . $u['email']);
        return [false, __('err_admin_only')];
    }

    if ($u['status'] === 'suspended') return [false, __('err_suspended')];

    // NOTE: 'pending' (email not yet verified) accounts CAN sign in —
    // accounts are usable from the moment they are created.

    // Account lockout after 5 failed attempts (15 min)
    if ($u['locked_until'] && strtotime($u['locked_until']) > time()) {
        return [false, __('err_locked')];
    }

    if (!password_verify($password, $u['password_hash'])) {
        $fails = (int)$u['failed_logins'] + 1;
        if ($fails >= 5) {
            q('UPDATE users SET failed_logins = 0, locked_until = ? WHERE id = ?', [date('Y-m-d H:i:s', time() + 900), $u['id']]);
            audit('login_lock', 'Account locked (5 failed attempts): ' . $u['email']);
        } else {
            q('UPDATE users SET failed_logins = ? WHERE id = ?', [$fails, $u['id']]);
        }
        audit('login_fail', 'Wrong password: ' . $u['email']);
        return [false, $generic];
    }

    // Success
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    q('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login = NOW(), last_ip = ? WHERE id = ?', [client_ip(), $u['id']]);
    if (!empty($u['preferred_lang'])) {
        $_SESSION['lang'] = $u['preferred_lang'];
    }
    audit('login_ok', $u['email'] . ' (' . $u['role'] . ')');
    return [true, ''];
}

/** Sign in a freshly registered user (no password re-check needed). */
function force_sign_in(int $uid): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $uid;
    q('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login = NOW(), last_ip = ? WHERE id = ?', [client_ip(), $uid]);
}

function logout(): void
{
    $u = current_user();
    if ($u) audit('logout', $u['email']);
    unset($_SESSION['uid']);
    session_regenerate_id(true);
}

// ---- Registration ----

/**
 * Register a customer — the account is ACTIVE immediately, bonus credits
 * included. Returns [ok(bool), tokenOrError(string)] where the token is
 * the raw email-verification token (hashed in the DB).
 */
function register_user(string $name, string $email, string $phone, string $company, string $password): array
{
    $email = strtolower(trim($email));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return [false, __('err_email_invalid')];
    if (mb_strlen($name) < 2) return [false, __('err_name')];
    if (!password_ok($password)) return [false, __('err_password_rules')];
    $ph = normalize_phone($phone);           // sms.php — E.164 (+2519…) or null
    if ($ph === null || $ph === '') return [false, __('err_phone_invalid')];
    if (qr('SELECT id FROM users WHERE email = ?', [$email])) {
        return [false, __('err_email_taken')];
    }
    if (qr('SELECT id FROM users WHERE phone = ?', [$ph])) {
        return [false, __('err_phone_taken')];
    }

    $token = rand_token(32);
    $bonus = max(0, (int)setting('signup_free_credits', 100));
    q('INSERT INTO users (name, email, password_hash, phone, company_name, preferred_lang, credits, status, verify_token, verify_expires) VALUES (?,?,?,?,?,?,?,?,?,?)', [
        $name, $email, password_hash($password, PASSWORD_DEFAULT),
        $ph,                                  // E.164 +2519… (from sms.php normalize_phone)
        $company !== '' ? mb_substr(trim($company), 0, 190) : null,
        lang(),
        $bonus,
        'active',                       // ← instant account, no approval
        hash('sha256', $token),
        date('Y-m-d H:i:s', time() + 86400),
    ]);
    $uid = db_last_id();

    if ($bonus > 0) {
        q('INSERT INTO wallet_transactions (user_id, type, credits, method, status, note) VALUES (?, \'bonus\', ?, \'system\', \'approved\', ?)', [
            $uid, $bonus, __('signup_bonus_note'),
        ]);
    }
    audit('register', $email);
    return [true, $token];
}

function password_ok(string $p): bool
{
    return strlen($p) >= 8 && preg_match('/[A-Za-z]/', $p) && preg_match('/[0-9]/', $p);
}

/**
 * Mark the email as verified (token link from email).
 * The account was already active with its bonus from registration —
 * this only confirms the address and clears the token.
 */
function apply_email_verification(array $user): bool
{
    q('UPDATE users SET email_verified = 1, verify_token = NULL, verify_expires = NULL WHERE id = ?', [$user['id']]);
    audit('email_verified', $user['email']);
    return true;
}

/** Issue a fresh verification token for a logged-in, unverified user. */
function reissue_verify_token(array $user): string
{
    $token = rand_token(32);
    q('UPDATE users SET verify_token = ?, verify_expires = ? WHERE id = ?', [
        hash('sha256', $token), date('Y-m-d H:i:s', time() + 86400), $user['id'],
    ]);
    return $token;
}

// ---- Password reset ----

/** Issue a reset token by email OR phone. Returns raw token or null. */
function issue_reset_token(string $login): ?string
{
    $u = find_user_by_login($login);
    if (!$u) return null;
    $token = rand_token(32);
    q('UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?', [
        hash('sha256', $token), date('Y-m-d H:i:s', time() + 3600), $u['id'],
    ]);
    return $token;
}
function consume_reset_token(string $token): ?array
{
    $u = qr('SELECT * FROM users WHERE reset_token = ? AND reset_expires > NOW()', [hash('sha256', $token)]);
    return $u ?: null;
}

// ---- API keys ----
function generate_api_key(): string
{
    return 'muya_' . rand_token(24);
}
function api_key_hash(string $key): string
{
    return hash('sha256', $key);
}
