<?php
/**
 * MuyaSMS — SMS utilities: phone normalization (Ethiopia focus),
 * GSM-7 / Unicode segment calculation, credit estimation.
 */

/** Normalize a phone number to E.164-ish (+251...). Returns null if invalid. */
function normalize_phone(?string $raw): ?string
{
    $p = trim((string)$raw);
    if ($p === '') return null;
    $p = preg_replace('/[\s\-().]/', '', $p);

    // Ethiopian local formats: 09xxxxxxxx / 9xxxxxxxx / 002519... → +2519...
    if (preg_match('/^(?:0)?(9\d{8})$/', $p, $m)) return '+251' . $m[1];
    if (preg_match('/^251(9\d{8})$/', $p, $m))    return '+251' . $m[1];

    // Kept as-is if already valid international
    if (preg_match('/^\+[1-9]\d{7,14}$/', $p)) return $p;

    return null;
}

/** GSM 03.38 basic + extension characters. */
function is_gsm7(string $text): bool
{
    $gsm = '@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !"#¤%&\'()*+,-./0123456789:;<=>?' .
           '¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà' .
           "\f^{}\\[~]|€";
    $len = function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    for ($i = 0; $i < $len; $i++) {
        $ch = function_exists('mb_substr') ? mb_substr($text, $i, 1, 'UTF-8') : $text[$i];
        if (mb_strpos($gsm, $ch, 0, 'UTF-8') === false) return false;
    }
    return true;
}

/**
 * Segment info: ['segments'=>n, 'encoding'=>'gsm7|unicode', 'per_segment'=>153|67, 'remaining'=>chars in current segment]
 */
function seg_info(string $text): array
{
    $len = function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    if ($len === 0) return ['segments' => 0, 'encoding' => 'gsm7', 'per_segment' => 160, 'remaining' => 160];
    if (is_gsm7($text)) {
        // extension chars count as 2
        $ext = "\f^{}\\[~]|€";
        $units = $len;
        $l = $len;
        for ($i = 0; $i < $l; $i++) {
            $ch = function_exists('mb_substr') ? mb_substr($text, $i, 1, 'UTF-8') : $text[$i];
            if (mb_strpos($ext, $ch, 0, 'UTF-8') !== false) $units++;
        }
        if ($units <= 160) return ['segments' => 1, 'encoding' => 'gsm7', 'per_segment' => 160, 'remaining' => 160 - $units];
        $segs = (int)ceil($units / 153);
        return ['segments' => $segs, 'encoding' => 'gsm7', 'per_segment' => 153, 'remaining' => 153 - ($units - 153 * ($segs - 1))];
    }
    if ($len <= 70) return ['segments' => 1, 'encoding' => 'unicode', 'per_segment' => 70, 'remaining' => 70 - $len];
    $segs = (int)ceil($len / 67);
    return ['segments' => $segs, 'encoding' => 'unicode', 'per_segment' => 67, 'remaining' => 67 - ($len - 67 * ($segs - 1))];
}

/** Credits needed for one recipient given the message text. */
function credits_for_recipient(string $text): int
{
    $seg = seg_info($text);
    if ($seg['segments'] < 1) $seg['segments'] = 1;
    return (int)$seg['segments'];
}

/** International multiplier applies to non-Ethiopian numbers. */
function is_intl(string $phoneE164): bool
{
    return strpos($phoneE164, '+251') !== 0;
}

/**
 * Estimate total credits for a campaign.
 * $phones = array of E.164 numbers, $text = message.
 */
function estimate_credits(array $phones, string $text): array
{
    $intlMult = max(1, (int)setting('intl_credit_multiplier', 2));
    $total = 0;
    foreach ($phones as $p) {
        $c = credits_for_recipient($text);
        if (is_intl($p)) $c *= $intlMult;
        $total += $c;
    }
    return ['credits' => $total];
}

/** Parse a recipients textarea / array: returns ['ok'=>[phones], 'bad'=>[raws]] */
function parse_recipients(string $raw): array
{
    $ok = [];
    $bad = [];
    $items = preg_split('/[\r\n,;]+/', $raw) ?: [];
    foreach ($items as $item) {
        $item = trim($item);
        if ($item === '') continue;
        $p = normalize_phone($item);
        if ($p === null) { $bad[] = $item; continue; }
        if (!in_array($p, $ok, true)) $ok[] = $p;
    }
    return ['ok' => $ok, 'bad' => $bad];
}
