<?php
/**
 * MuyaSMS — shared layout (3D neon dark theme).
 * Usage:
 *   muya_page_start(['title'=>'Dashboard','area'=>'app','active'=>'dashboard']);
 *   ... page HTML ...
 *   muya_page_end();
 */

function muya_icon(string $name): string
{
    $icons = [
        'grid'      => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'send'      => '<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/>',
        'users'     => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'card'      => '<rect x="1" y="4" width="22" height="16" rx="3"/><path d="M1 10h22"/>',
        'shield'    => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
        'clock'     => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
        'key'       => '<path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
        'settings'  => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
        'chart'     => '<path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/>',
        'logout'    => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
        'globe'     => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
        'doc'       => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
        'cash'      => '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/>',
        'zap'       => '<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
        'phone'     => '<rect x="5" y="2" width="14" height="20" rx="3"/><path d="M12 18h.01"/>',
        'back'      => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    ];
    $p = $icons[$name] ?? $icons['grid'];
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

/** Brand logo (3D gradient M mark). */
function muya_logo_svg(int $size = 34): string
{
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 48 48" fill="none" aria-hidden="true">
<defs>
<linearGradient id="lgA" x1="4" y1="4" x2="44" y2="44"><stop stop-color="#10B981"/><stop offset="1" stop-color="#3B82F6"/></linearGradient>
<linearGradient id="lgB" x1="4" y1="44" x2="44" y2="4"><stop stop-color="#F97316"/><stop offset="1" stop-color="#F59E0B"/></linearGradient>
</defs>
<path d="M8 40V16l8 12 8-12 8 12 8-12v24" stroke="url(#lgA)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8 40V16l8 12 8-12 8 12 8-12" stroke="url(#lgB)" stroke-width="1.4" stroke-linecap="round" opacity=".8"/>
</svg>';
}

function muya_nav_items(string $area): array
{
    if ($area === 'admin') {
        $items = [
            ['dashboard.php', 'dashboard', 'nav_overview', 'chart'],
            ['payments.php', 'payments', 'nav_payments', 'cash'],
            ['verifications.php', 'verifications', 'nav_verifications', 'shield'],
            ['users.php', 'users', 'nav_users', 'users'],
            ['gateways.php', 'gateways', 'nav_gateways', 'zap'],
            ['pricing.php', 'pricing', 'nav_pricing', 'card'],
        ];
        $u = current_user();
        if ($u && $u['role'] === 'admin') {
            $items[] = ['staff.php', 'staff', 'nav_staff', 'key'];
            $items[] = ['audit.php', 'audit', 'nav_audit', 'doc'];
        }
        return $items;
    }
    return [
        ['index.php', 'dashboard', 'nav_dashboard', 'grid'],
        ['send.php', 'send', 'nav_send', 'send'],
        ['contacts.php', 'contacts', 'nav_contacts', 'users'],
        ['wallet.php', 'wallet', 'nav_wallet', 'card'],
        ['verification.php', 'verification', 'nav_verification', 'shield'],
        ['history.php', 'history', 'nav_history', 'clock'],
        ['api.php', 'api', 'nav_api', 'key'],
        ['settings.php', 'settings', 'nav_settings', 'settings'],
    ];
}

function muya_page_start(array $opts = []): void
{
    $title  = $opts['title'] ?? 'MuyaSMS';
    $area   = $opts['area'] ?? 'app';          // app | admin | auth
    $active = $opts['active'] ?? '';
    $user   = current_user();
    $isApp  = $area === 'app';
    $nav    = muya_nav_items($isApp ? 'app' : 'admin');
    $base   = $isApp ? 'app/' : 'admin/';
    $platform = setting('platform_name', 'MuyaSMS');
    $signoutPath = '../signout.php';

    $pendingPay = 0; $pendingVer = 0;
    try {
        if ($area === 'admin') {
            $pendingPay = (int)qv('SELECT COUNT(*) FROM wallet_transactions WHERE status = \'pending\'');
            $pendingVer = (int)qv('SELECT COUNT(*) FROM verifications WHERE status = \'pending\'');
        }
    } catch (Throwable $e) {}

    ?><!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title) ?> · <?= e($platform) ?></title>
<link rel="icon" type="image/svg+xml" href="<?= $isApp || $area === 'admin' ? '../' : '' ?>assets/img/favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= $isApp || $area === 'admin' ? '../' : '' ?>assets/css/muya.css">
</head>
<body data-area="<?= e($area) ?>">
<div class="bg-stage" aria-hidden="true">
  <div class="orb orb-emerald"></div>
  <div class="orb orb-blue"></div>
  <div class="orb orb-gold"></div>
  <div class="grid-floor"></div>
</div>

<div class="shell">
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <?= muya_logo_svg(34) ?>
      <div class="brand-name"><?= e($platform) ?></div>
    </div>
    <nav class="nav">
      <?php foreach ($nav as $item): [$href, $key, $label, $icon] = $item; ?>
      <a class="nav-item <?= $key === $active ? 'active' : '' ?>" href="<?= e($base . $href) ?>">
        <span class="nav-ic"><?= muya_icon($icon) ?></span>
        <span class="nav-tx"><?= e(__($label)) ?></span>
        <?php if ($key === 'payments' && $pendingPay > 0): ?><span class="nav-pill"><?= (int)$pendingPay ?></span><?php endif; ?>
        <?php if ($key === 'verifications' && $pendingVer > 0): ?><span class="nav-pill"><?= (int)$pendingVer ?></span><?php endif; ?>
      </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <div class="user-chip">
        <div class="avatar"><?= e(mb_strtoupper(mb_substr($user['name'] ?? '?', 0, 1))) ?></div>
        <div class="user-meta">
          <div class="user-name"><?= e($user['name'] ?? '') ?></div>
          <div class="user-mail"><?= e($user['email'] ?? '') ?></div>
        </div>
      </div>
      <a class="btn btn-ghost btn-block" href="<?= e($signoutPath) ?>"><?= muya_icon('logout') ?><span><?= e(__('sign_out')) ?></span></a>
    </div>
  </aside>

  <main class="main">
    <header class="topbar">
      <button class="icon-btn mobile-only" id="navToggle" type="button" aria-label="Menu">☰</button>
      <h1 class="page-title"><?= e($opts['title'] ?? '') ?></h1>
      <div class="topbar-right">
        <?php if ($isApp && $user): ?>
        <a class="credits-badge" href="wallet.php" title="<?= e(__('credits')) ?>">
          <span class="credits-num" data-count="<?= (int)$user['credits'] ?>"><?= number_format((int)$user['credits']) ?></span>
          <span class="credits-lbl"><?= e(__('sms_credits')) ?></span>
        </a>
        <?php endif; ?>
        <a class="lang-toggle" href="<?= e(lang_toggle_url()) ?>" hreflang="<?= lang() === 'en' ? 'am' : 'en' ?>" title="Language">
          <?= muya_icon('globe') ?><span><?= lang() === 'en' ? 'አማርኛ' : 'English' ?></span>
        </a>
      </div>
    </header>

    <div class="flash-zone">
      <?php foreach (flash_get() as $f): ?>
      <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
      <?php endforeach; ?>
      <?php if ($isApp && $user && empty($user['email_verified']) && empty($_SESSION['verify_banner_dismissed'])): ?>
      <div class="flash flash-warn" style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
        <span>✉️ <?= e(__('verify_banner')) ?></span>
        <a class="btn btn-ghost btn-sm" href="../verify.php?resend=1" onclick="return muyaVerifyResend(this)"><?= e(__('verify_resend')) ?></a>
      </div>
      <?php endif; ?>
    </div>

    <div class="content">
<?php
}

function muya_page_end(array $opts = []): void
{
    $area = $opts['area'] ?? 'app';
    $prefix = ($area === 'app' || $area === 'admin') ? '../' : '';
    $jsGlobals = [
        'csrf'  => csrf_token(),
        'lang'  => lang(),
        'i18n'  => [
            'saving'         => __('saving'),
            'error_generic'  => __('error_generic'),
            'copied'         => __('copied'),
            'confirm_action' => __('confirm_action'),
        ],
    ];
    ?>
    </div><!-- /content -->
  </main>
</div><!-- /shell -->

<div class="toast-zone" id="toastZone" aria-live="polite"></div>

<script>
window.MUYA = <?= json_encode($jsGlobals, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
function muyaVerifyResend(el) {
  // turn the link into a POST (CSRF-safe resend)
  var f = document.createElement('form');
  f.method = 'post';
  f.action = el.getAttribute('href');
  var i = document.createElement('input');
  i.type = 'hidden';
  i.name = 'csrf';
  i.value = '<?= csrf_token() ?>';
  f.appendChild(i);
  document.body.appendChild(f);
  f.submit();
  return false;
}
</script>
<script src="<?= e($prefix) ?>assets/js/app.js"></script>
</body>
</html>
<?php
}
