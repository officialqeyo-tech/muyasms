<?php
/**
 * MuyaSMS — dependency-free SMTP mailer (PHP sockets).
 * Configured for cPanel mailbox: mail.muyalink.com : 465 SSL (implicit TLS).
 * Supports: AUTH LOGIN, AUTH PLAIN, SSL + STARTTLS, UTF-8 HTML mail.
 */

class MuyaSMTP
{
    private $fp = null;
    private $host;
    private $port;
    private $secure;
    private $timeout;
    private $log = [];

    public function __construct(string $host, int $port, string $secure = 'ssl', int $timeout = 15)
    {
        $this->host = $host;
        $this->port = $port;
        $this->secure = $secure;
        $this->timeout = $timeout;
    }

    public function connect(): void
    {
        $errno = 0; $errstr = '';
        $transport = ($this->secure === 'ssl') ? 'ssl' : 'tcp';
        $ctx = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true]]);
        $this->fp = @stream_socket_client(
            $transport . '://' . $this->host . ':' . $this->port,
            $errno, $errstr, $this->timeout,
            STREAM_CLIENT_CONNECT, $ctx
        );
        if (!$this->fp) {
            throw new RuntimeException("SMTP connect failed: $errstr ($errno)");
        }
        stream_set_timeout($this->fp, $this->timeout);
        $this->expect([220]);

        $myHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $this->cmd('EHLO ' . (preg_match('/^[a-z0-9.\-]+$/i', $myHost) ? $myHost : 'muyalink.com'), [250]);

        if ($this->secure === 'tls') {
            $this->cmd('STARTTLS', [220]);
            $ok = @stream_socket_enable_crypto($this->fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if (!$ok) throw new RuntimeException('STARTTLS failed');
            $this->cmd('EHLO ' . (preg_match('/^[a-z0-9.\-]+$/i', $myHost) ? $myHost : 'muyalink.com'), [250]);
        }
    }

    public function auth(string $user, string $pass): void
    {
        $this->cmd('AUTH LOGIN', [334]);
        $this->cmd(base64_encode($user), [334]);
        $r = $this->cmd(base64_encode($pass), [235]);
        if ($r === null) throw new RuntimeException('SMTP auth failed');
    }

    /** Send a command and check response code. Returns [code, text]. */
    public function cmd(string $command, array $expectCodes): array
    {
        if ($command !== '') {
            fwrite($this->fp, $command . "\r\n");
        }
        $code = 0; $text = '';
        // multi-line aware reader
        while (($line = fgets($this->fp, 1024)) !== false) {
            $text .= $line;
            $this->log[] = trim($line);
            if (strlen($line) < 4) break;
            $code = (int)substr($line, 0, 3);
            if (isset($line[3]) && $line[3] === ' ') break; // final line of response
        }
        if ($code === 0) throw new RuntimeException('No SMTP response');
        if ($expectCodes && !in_array($code, $expectCodes, true)) {
            throw new RuntimeException('SMTP expected ' . implode('/', $expectCodes) . ' got ' . $code . ': ' . trim($text));
        }
        return [$code, $text];
    }

    public function send_message(string $from, string $fromName, array $to, string $subject, string $html, string $textAlt = ''): void
    {
        // MAIL FROM
        $this->cmd('MAIL FROM:<' . $from . '>', [250]);
        // RCPT TO (one recipient per call — first is the addressee)
        foreach ($to as $recipient) {
            $this->cmd('RCPT TO:<' . $recipient . '>', [250, 251]);
        }
        // DATA
        $this->cmd('DATA', [354]);

        $mime = $this->build_mime($from, $fromName, $to[0], $subject, $html, $textAlt);
        // dot-stuffing + CRLF normalization
        $mime = str_replace("\r\n", "\n", $mime);
        $mime = str_replace("\n", "\r\n", $mime);
        $mime = preg_replace('/^\./m', '..', $mime);
        fwrite($this->fp, $mime . "\r\n.\r\n");
        $this->expect([250]);
        $this->cmd('QUIT', [221]);
    }

    private function expect(array $codes): void
    {
        $this->cmd('', $codes);
    }

    private function build_mime(string $from, string $fromName, string $to, string $subject, string $html, string $textAlt): string
    {
        $headers = [];
        $headers[] = 'From: ' . $this->encode_hdr($fromName) . ' <' . $from . '>';
        $headers[] = 'Reply-To: ' . $from;
        $headers[] = 'To: ' . $to;
        $headers[] = 'Subject: ' . $this->encode_hdr($subject);
        $headers[] = 'Date: ' . date('r');
        $headers[] = 'Message-ID: <' . rand_token(12) . '@muyalink.com>';
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'X-Mailer: MuyaSMS-Mailer/1.0';

        if ($textAlt === '') {
            $textAlt = trim(strip_tags(preg_replace('/<br[^>]*>/i', "\n", $html)));
        }
        $boundary = '=_muya_' . rand_token(8);
        $headers[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';

        $body  = '--' . $boundary . "\r\n";
        $body .= 'Content-Type: text/plain; charset=UTF-8' . "\r\n";
        $body .= 'Content-Transfer-Encoding: base64' . "\r\n\r\n";
        $body .= chunk_split(base64_encode($textAlt)) . "\r\n";
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Type: text/html; charset=UTF-8' . "\r\n";
        $body .= 'Content-Transfer-Encoding: base64' . "\r\n\r\n";
        $body .= chunk_split(base64_encode($html)) . "\r\n";
        $body .= '--' . $boundary . '--';

        return implode("\r\n", $headers) . "\r\n\r\n" . $body;
    }

    private function encode_hdr(string $s): string
    {
        if (preg_match('/[^\x20-\x7e]/', $s)) {
            return '=?UTF-8?B?' . base64_encode($s) . '?=';
        }
        return $s;
    }

    public function close(): void
    {
        if ($this->fp) { @fclose($this->fp); $this->fp = null; }
    }

    public function lastLog(): array
    {
        return $this->log;
    }
}

/**
 * Send an email through the configured cPanel SMTP box.
 * Returns [ok(bool), error(string)]
 */
function muya_mail(string $toEmail, string $subject, string $html, string $toName = ''): array
{
    if (setting('email_enabled', '1') !== '1') {
        return [false, 'Email disabled in settings'];
    }
    $smtp = new MuyaSMTP(SMTP_HOST, (int)SMTP_PORT, (defined('SMTP_SECURE') ? SMTP_SECURE : 'ssl'), 15);
    try {
        $smtp->connect();
        $smtp->auth(SMTP_USER, SMTP_PASS);
        $fromName = defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'MuyaSMS';
        $smtp->send_message(SMTP_FROM, $fromName, [$toEmail], $subject, $html);
        $smtp->close();
        return [true, ''];
    } catch (Throwable $e) {
        $smtp->close();
        error_log('MAIL FAIL → ' . $toEmail . ' :: ' . $e->getMessage());
        return [false, $e->getMessage()];
    }
}

/**
 * Bilingual (EN + AM) branded HTML email wrapper.
 * $bodyHtmlEn / $bodyHtmlAm — inner content; $btnHref null = no button.
 */
function email_template(string $titleEn, string $titleAm, string $bodyHtmlEn, string $bodyHtmlAm, ?string $btnHref = null, string $btnText = ''): string
{
    $btn = '';
    if ($btnHref) {
        $btn = '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:26px auto 8px"><tr><td style="background:linear-gradient(135deg,#10B981,#3B82F6);border-radius:10px">'
             . '<a href="' . htmlspecialchars($btnHref, ENT_QUOTES, 'UTF-8') . '" style="display:inline-block;padding:13px 30px;color:#ffffff;font:600 15px/1 Arial,sans-serif;text-decoration:none">'
             . htmlspecialchars($btnText, ENT_QUOTES, 'UTF-8') . '</a></td></tr></table>';
    }
    $html = '<!doctype html><html><body style="margin:0;padding:0;background:#0A0D12">
<div style="display:none">MuyaSMS</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0A0D12;padding:32px 12px">
<tr><td align="center">
<table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#111726;border:1px solid #1E293B;border-radius:16px;overflow:hidden">
  <tr><td style="padding:22px 28px;border-bottom:1px solid #1E293B">
    <span style="font:700 20px/1 Arial,sans-serif;color:#F8FAFC">Muya</span><span style="font:700 20px/1 Arial,sans-serif;background:linear-gradient(90deg,#10B981,#3B82F6);-webkit-background-clip:text;background-clip:text;color:transparent">SMS</span>
    <span style="float:right;font:400 11px/1 Arial,sans-serif;color:#64748B">muyalink.com</span>
  </td></tr>
  <tr><td style="padding:28px 32px 8px">
    <h1 style="margin:0 0 6px;font:700 21px/1.3 Arial,sans-serif;color:#F8FAFC">' . $titleEn . '</h1>
    <div style="font:400 14px/1.65 Arial,sans-serif;color:#B6C2D6">' . $bodyHtmlEn . '</div>
    ' . $btn . '
  </td></tr>
  <tr><td style="padding:20px 32px 6px;border-top:1px solid #1E293B;margin-top:18px">
    <h1 style="margin:0 0 6px;font:700 18px/1.3 Arial,sans-serif;color:#10B981">' . $titleAm . '</h1>
    <div style="font:400 14px/1.65 Arial,sans-serif;color:#B6C2D6">' . $bodyHtmlAm . '</div>
  </td></tr>
  <tr><td style="padding:18px 32px 28px">
    <p style="margin:0;font:400 11px/1.6 Arial,sans-serif;color:#475569">MuyaSMS · muyalink.com · ' . date('Y') . '<br>Sent automatically — do not reply to this message.</p>
  </td></tr>
</table>
</td></tr></table></body></html>';
    return $html;
}

/** Notify admin (pending payments / verifications). Failures are logged only. */
function notify_admin(string $subject, string $html): void
{
    $to = setting('admin_notify_email', 'officialqeyo@gmail.com');
    if (!filter_var((string)$to, FILTER_VALIDATE_EMAIL)) return;
    muya_mail((string)$to, $subject, $html);
}
