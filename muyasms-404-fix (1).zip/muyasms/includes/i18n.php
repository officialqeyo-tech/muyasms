<?php
/**
 * MuyaSMS — internationalization (English + አማርኛ Amharic).
 * Usage:  __('dashboard')  — translates current key, sprintf-style args supported.
 * Switch:  ?lang=am / ?lang=en (persisted in session + cookie)
 */

$GLOBALS['muya_lang'] = 'en';
$GLOBALS['muya_L'] = null;

function lang_dir(): string
{
    return ROOT . '/lang';
}

function lang_init(): void
{
    $lang = $_SESSION['lang'] ?? ($_COOKIE['muya_lang'] ?? 'en');

    // allow ?lang=am|en toggle (also honor user preference after login)
    if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'am'], true)) {
        $lang = $_GET['lang'];
        $_SESSION['lang'] = $lang;
        setcookie('muya_lang', $lang, time() + 31536000, '/', '', is_https(), true);
    }
    if (!in_array($lang, ['en', 'am'], true)) $lang = 'en';

    $GLOBALS['muya_lang'] = $lang;
    $file = lang_dir() . '/' . $lang . '.php';
    $fallback = lang_dir() . '/en.php';
    $GLOBALS['muya_L'] = is_file($file) ? require $file : (is_file($fallback) ? require $fallback : []);
    if (!is_array($GLOBALS['muya_L'])) $GLOBALS['muya_L'] = [];
    // ensure English fallback keys for missing translations
    if ($lang !== 'en' && is_file($fallback)) {
        $en = require $fallback;
        if (is_array($en)) {
            $GLOBALS['muya_L'] = array_merge($en, $GLOBALS['muya_L']);
        }
    }
}

function lang(): string
{
    return $GLOBALS['muya_lang'];
}

/** Translate with optional sprintf args. */
function __(string $key, ...$args): string
{
    $L = $GLOBALS['muya_L'] ?? [];
    $s = $L[$key] ?? $key;
    if ($args) $s = vsprintf($s, $args);
    return $s;
}

/** Language toggle URL for current page. */
function lang_toggle_url(): string
{
    $target = lang() === 'en' ? 'am' : 'en';
    $qs = $_GET;
    $qs['lang'] = $target;
    return '?' . http_build_query($qs);
}

/** JS-visible translations (subset) — injected into layout. */
function i18n_js_strings(): array
{
    return [
        'saving'        => __('saving'),
        'error_generic' => __('error_generic'),
        'copied'        => __('copied'),
        'confirm_action' => __('confirm_action'),
        'copied'        => __('copied'),
    ];
}
