<?php
/**
 * MuyaSMS — cron cleanup (daily).
 *
 * cPanel → Cron Jobs (once a day, e.g. 03:00):
 *   php /home/USERNAME/public_html/cron/cleanup.php YOUR_CRON_KEY
 *
 * Purges expired tokens, stale rate-limit files, old audit entries.
 */
require __DIR__ . '/../includes/bootstrap.php';

$givenKey = $_GET['key'] ?? (isset($argv[1]) ? $argv[1] : '');
if (!defined('CRON_KEY') || !is_string($givenKey) || !hash_equals(CRON_KEY, $givenKey)) {
    http_response_code(403);
    header('Content-Type: application/json');
    exit('{"ok":false,"error":"bad cron key"}');
}

$report = [];

// 1) expired verification / reset tokens
try {
    $n = q('UPDATE users SET verify_token = NULL, verify_expires = NULL WHERE verify_expires IS NOT NULL AND verify_expires < NOW()')->rowCount();
    $n += q('UPDATE users SET reset_token = NULL, reset_expires = NULL WHERE reset_expires IS NOT NULL AND reset_expires < NOW()')->rowCount();
    $report['tokens_cleared'] = $n;
} catch (Throwable $e) { $report['tokens_error'] = $e->getMessage(); }

// 2) stale rate-limit files (> 1 day)
$rlDir = ROOT . '/storage/rl';
$purged = 0;
if (is_dir($rlDir)) {
    foreach (scandir($rlDir) ?: [] as $f) {
        $path = $rlDir . '/' . $f;
        if (is_file($path) && filemtime($path) < time() - 86400) {
            @unlink($path);
            $purged++;
        }
    }
}
$report['rl_files_purged'] = $purged;

// 3) audit log > 180 days
try {
    $auditSql = is_pg()
        ? 'DELETE FROM audit_log WHERE created_at < NOW() - INTERVAL \'180 days\''
        : 'DELETE FROM audit_log WHERE created_at < NOW() - INTERVAL 180 DAY';
    $report['audit_deleted'] = q($auditSql)->rowCount();
} catch (Throwable $e) { $report['audit_error'] = $e->getMessage(); }

// 4) PHP error log rotation (> 5 MB)
$errLog = ROOT . '/storage/php-error.log';
if (is_file($errLog) && filesize($errLog) > 5 * 1024 * 1024) {
    @unlink($errLog);
    $report['error_log_rotated'] = true;
}

header('Content-Type: application/json');
echo json_encode(['ok' => true, 'time' => date('c')] + $report, JSON_UNESCAPED_SLASHES);
