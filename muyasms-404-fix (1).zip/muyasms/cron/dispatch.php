<?php
/**
 * MuyaSMS — cron dispatcher.
 *
 * cPanel → Cron Jobs (every minute):
 *   php /home/USERNAME/public_html/cron/dispatch.php YOUR_CRON_KEY
 *
 * Also works over HTTP (returns JSON):
 *   https://muyalink.com/cron/dispatch.php?key=YOUR_CRON_KEY
 */
require __DIR__ . '/../includes/bootstrap.php';

$givenKey = $_GET['key'] ?? (isset($argv[1]) ? $argv[1] : '');
if (!defined('CRON_KEY') || !is_string($givenKey) || !hash_equals(CRON_KEY, $givenKey)) {
    http_response_code(403);
    header('Content-Type: application/json');
    exit('{"ok":false,"error":"bad cron key"}');
}

$stats = process_queue();
header('Content-Type: application/json');
echo json_encode(['ok' => true, 'time' => date('c')] + $stats, JSON_UNESCAPED_SLASHES);
