<?php
/**
 * MuyaSMS configuration — SAMPLE / REFERENCE COPY.
 *
 * ✅ config.php is ALREADY SHIPPED in this package, pre-configured with:
 *      - your cPanel SMTP mailbox (sms@muyalink.com @ mail.muyalink.com:465 SSL)
 *      - your PostgreSQL database (muyalito_muyasms) + passwords (kept hidden — never share)
 *      - a generated CRON_KEY
 *    Normally you never need to edit anything. If the DB name/user is
 *    different on your cPanel, just open /install.php — it shows a quick-fix
 *    form that rewrites only the DB lines of config/config.php.
 *
 * This sample exists only as a clean reference (e.g. if you ever rebuild
 * config.php from scratch on a new server).
 */

// ---- Database ----
// DB_DRIVER: 'pgsql' = PostgreSQL (phpPgAdmin) · 'mysql' = MySQL (phpMyAdmin)
// DB_HOST 'localhost' = TCP · '/var/run/postgresql' = unix socket (PostgreSQL)
define('DB_DRIVER', 'pgsql');
define('DB_HOST', 'localhost');
define('DB_PORT', 5432);
define('DB_NAME', 'cpaneluser_muyasms');
define('DB_USER', 'cpaneluser_muya');
define('DB_PASS', 'CHANGE_ME_DATABASE_PASSWORD');

// ---- SMTP (cPanel email) ----
define('SMTP_HOST', 'mail.muyalink.com');
define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl');        // 'ssl' = port 465 | 'tls' = port 587 STARTTLS
define('SMTP_USER', 'sms@muyalink.com');
define('SMTP_PASS', 'CHANGE_ME_EMAIL_PASSWORD');
define('SMTP_FROM', 'sms@muyalink.com');
define('SMTP_FROM_NAME', 'MuyaSMS');

// ---- App ----
define('APP_URL', 'https://muyalink.com');   // no trailing slash
define('CRON_KEY', 'CHANGE_ME_RANDOM_SECRET_32_CHARS'); // used to run cron/dispatch.php
define('APP_DEBUG', false);                  // NEVER enable in production
