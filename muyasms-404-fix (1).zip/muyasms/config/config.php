<?php
/**
 * MuyaSMS configuration — SHIPS PRE-CONFIGURED for your server (do not edit unless needed).
 *
 * YOUR DATABASE:  PostgreSQL (phpPgAdmin) — database "muyalito_muyasms".
 * The installer (/install.php) auto-detects the PostgreSQL user
 * (it tries muyalito_muyasms, your cPanel account name muyalito,
 * localhost and the /var/run/postgresql socket) and saves whatever
 * connects into this file.
 *
 * SECURITY:
 *   - This file contains secrets (DB + SMTP passwords). It is NEVER shown in the UI.
 *   - Web access is blocked by config/.htaccess (Require all denied) + root .htaccess.
 *   - Never share, print, screenshot or email these values after setup.
 */

// ---- Database (PostgreSQL on your cPanel server) ----
// DB_DRIVER: 'pgsql' = PostgreSQL (phpPgAdmin) · 'mysql' = MySQL (phpMyAdmin)
// DB_HOST 'localhost' = TCP · '/var/run/postgresql' = unix socket
define('DB_DRIVER', 'pgsql');
define('DB_HOST', 'localhost');
define('DB_PORT', 5432);
define('DB_NAME', 'muyalito_muyasms');
define('DB_USER', 'muyalito_muyasms');
define('DB_PASS', 'Red@212310#');

// ---- SMTP (cPanel email — already verified working) ----
define('SMTP_HOST', 'mail.muyalink.com');
define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl');        // 'ssl' = port 465 (yours) | 'tls' = port 587 STARTTLS
define('SMTP_USER', 'sms@muyalink.com');
define('SMTP_PASS', 'Red@212310#');
define('SMTP_FROM', 'sms@muyalink.com');
define('SMTP_FROM_NAME', 'MuyaSMS');

// ---- App ----
define('APP_URL', 'https://muyalink.com/muyasms');   // no trailing slash
define('CRON_KEY', 'fa8d17dfe862cf4256082aeb2b6e21562074f1b3'); // secret key for cron/dispatch.php — copy it when you create the cPanel cron job
define('APP_DEBUG', false);                  // NEVER enable in production
