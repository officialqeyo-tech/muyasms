<?php
/**
 * MuyaSMS — sign out.
 */
require __DIR__ . '/includes/bootstrap.php';
logout();
redirect('signin.php');
