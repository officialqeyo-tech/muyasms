<?php
/**
 * MuyaSMS — secure verification document download (admin/staff only).
 * Files live in uploads/verify/ which is blocked by .htaccess;
 * they can only be streamed through this authenticated endpoint.
 */
require __DIR__ . '/includes/bootstrap.php';

if (!is_admin()) {
    http_response_code(403);
    exit('Forbidden');
}

$id = (int)($_GET['id'] ?? 0);
$v = qr('SELECT v.*, u.name AS user_name, u.email AS user_email FROM verifications v JOIN users u ON u.id = v.user_id WHERE v.id = ?', [$id]);
if (!$v) {
    http_response_code(404);
    exit('Not found');
}

$path = ROOT . '/uploads/verify/' . basename($v['doc_path']);
$full = realpath($path);
$baseDir = realpath(ROOT . '/uploads/verify');

// path traversal protection
if (!$full || !$baseDir || strpos($full, $baseDir) !== 0 || !is_file($full)) {
    http_response_code(404);
    exit('File not found');
}

$ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
$mime = ['pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png'][$ext] ?? 'application/octet-stream';

$filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', 'verification_' . $id . '_' . $v['company_name']) . '.' . $ext;

header('Content-Type: ' . $mime);
header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Length: ' . filesize($full));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($full);
audit('verif_doc_view', 'doc #' . $id . ' (' . $v['user_email'] . ')');
exit;
