/* ============================================================
   MuyaSMS — core JS: API wrapper, toasts, 3D tilt, counters,
   mini charts, modals, mobile nav. No dependencies.
   ============================================================ */
(function () {
  'use strict';

  var M = window.MUYA || {};

  /* ---------- Toasts ---------- */
  function toast(msg, type) {
    var zone = document.getElementById('toastZone');
    if (!zone) return;
    var el = document.createElement('div');
    el.className = 'toast toast-' + (type || 'info');
    el.textContent = msg;
    zone.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .3s, transform .3s';
      el.style.opacity = '0';
      el.style.transform = 'translateY(8px)';
      setTimeout(function () { el.remove(); }, 320);
    }, 4200);
  }
  window.muyaToast = toast;

  /* ---------- API helper ---------- */
  function api(path, data, opts) {
    opts = opts || {};
    var url = path;
    var init = {
      method: opts.method || 'POST',
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': M.csrf || '' }
    };
    if (data instanceof FormData) {
      init.body = data; // multipart (file upload) — csrf appended separately
      data.append('csrf', M.csrf || '');
    } else if (data !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(data || {});
    } else {
      init.method = opts.method || 'GET';
    }
    return fetch(url, init).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: 'Bad response' }; });
    }).then(function (j) {
      if (j && j.ok === false && j.error) {
        if (!opts.silent) toast(j.error, 'err');
        throw new Error(j.error);
      }
      return j;
    }).catch(function (e) {
      if (String(e.message).indexOf('Failed to fetch') === 0 && !opts.silent) {
        toast((M.i18n && M.i18n.error_generic) || 'Network error', 'err');
      }
      throw e;
    });
  }
  window.muyaApi = api;

  /* ---------- 3D tilt cards ---------- */
  function initTilt() {
    var cards = document.querySelectorAll('[data-tilt]');
    Array.prototype.forEach.call(cards, function (card) {
      var strength = parseFloat(card.getAttribute('data-tilt')) || 6;
      function onMove(ev) {
        var rect = card.getBoundingClientRect();
        var px = (ev.clientX - rect.left) / rect.width - 0.5;
        var py = (ev.clientY - rect.top) / rect.height - 0.5;
        card.style.transform = 'perspective(800px) rotateY(' + (px * strength) + 'deg) rotateX(' + (-py * strength) + 'deg) translateY(-2px)';
      }
      function onLeave() { card.style.transform = ''; }
      card.addEventListener('mousemove', onMove);
      card.addEventListener('mouseleave', onLeave);
    });
  }

  /* ---------- Animated counters ---------- */
  function animateCounters() {
    var els = document.querySelectorAll('[data-count]');
    Array.prototype.forEach.call(els, function (el) {
      var target = parseFloat(el.getAttribute('data-count')) || 0;
      var suffix = el.getAttribute('data-suffix') || '';
      var dec = (el.getAttribute('data-decimals') || '0') | 0;
      var start = null, dur = 900;
      function step(ts) {
        if (!start) start = ts;
        var p = Math.min(1, (ts - start) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        var val = target * eased;
        el.textContent = (dec ? val.toFixed(dec) : Math.round(val).toLocaleString()) + suffix;
        if (p < 1) requestAnimationFrame(step);
      }
      if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (entries) {
          entries.forEach(function (en) { if (en.isIntersecting) { requestAnimationFrame(step); io.disconnect(); } });
        }, { threshold: 0.4 });
        io.observe(el);
      } else requestAnimationFrame(step);
    });
  }

  /* ---------- Mini chart engine (canvas) ---------- */
  function prepCanvas(cv) {
    var dpr = window.devicePixelRatio || 1;
    var rect = cv.getBoundingClientRect();
    cv.width = rect.width * dpr;
    cv.height = rect.height * dpr;
    var ctx = cv.getContext('2d');
    ctx.scale(dpr, dpr);
    return { ctx: ctx, w: rect.width, h: rect.height };
  }

  function drawLine(cv, series, opts) {
    if (!cv) return;
    opts = opts || {};
    var p = prepCanvas(cv), ctx = p.ctx, w = p.w, h = p.h;
    var pad = { l: 34, r: 12, t: 14, b: 24 };
    var iw = w - pad.l - pad.r, ih = h - pad.t - pad.b;
    var max = 1;
    series.forEach(function (s) { s.data.forEach(function (v) { if (v > max) max = v; }); });
    max = Math.max(1, Math.ceil(max * 1.15));

    ctx.clearRect(0, 0, w, h);
    // grid
    ctx.strokeStyle = 'rgba(148,163,184,.10)';
    ctx.fillStyle = 'rgba(148,163,184,.55)';
    ctx.font = '10px Inter, sans-serif';
    ctx.lineWidth = 1;
    for (var g = 0; g <= 4; g++) {
      var gy = pad.t + ih - (ih * g / 4);
      ctx.beginPath(); ctx.moveTo(pad.l, gy); ctx.lineTo(w - pad.r, gy); ctx.stroke();
      ctx.fillText(String(Math.round(max * g / 4)), 4, gy + 3);
    }

    series.forEach(function (s) {
      var n = s.data.length;
      if (!n) return;
      var pts = s.data.map(function (v, i) {
        return [pad.l + iw * (n === 1 ? 0.5 : i / (n - 1)), pad.t + ih - (ih * v / max)];
      });
      // area
      var grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ih);
      grad.addColorStop(0, s.color + '44');
      grad.addColorStop(1, s.color + '00');
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pad.t + ih);
      pts.forEach(function (pt) { ctx.lineTo(pt[0], pt[1]); });
      ctx.lineTo(pts[pts.length - 1][0], pad.t + ih);
      ctx.closePath();
      ctx.fillStyle = grad; ctx.fill();
      // line
      ctx.beginPath();
      pts.forEach(function (pt, i) { i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); });
      ctx.strokeStyle = s.color; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.shadowColor = s.color + '66'; ctx.shadowBlur = 9;
      ctx.stroke();
      ctx.shadowBlur = 0;
    });

    if (opts.labels && opts.labels.length) {
      ctx.fillStyle = 'rgba(100,116,139,.8)';
      var ln = opts.labels.length;
      var step = Math.ceil(ln / 8);
      opts.labels.forEach(function (lb, i) {
        if (i % step !== 0) return;
        var x = pad.l + iw * (ln === 1 ? 0.5 : i / (ln - 1));
        ctx.fillText(lb, Math.min(Math.max(x - 10, 2), w - 26), h - 6);
      });
    }
  }

  function drawDonut(cv, segs) {
    if (!cv) return;
    var p = prepCanvas(cv), ctx = p.ctx, w = p.w, h = p.h;
    var cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 10, ir = r * 0.62;
    var total = 0; segs.forEach(function (s) { total += s.value; });
    ctx.clearRect(0, 0, w, h);
    if (!total) {
      ctx.beginPath(); ctx.arc(cx, cy, (r + ir) / 2, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(100,116,139,.22)'; ctx.lineWidth = r - ir; ctx.stroke();
      return;
    }
    var a = -Math.PI / 2;
    segs.forEach(function (s) {
      if (!s.value) return;
      var a2 = a + (s.value / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.arc(cx, cy, r, a, a2); ctx.arc(cx, cy, ir, a2, a, true);
      ctx.closePath();
      ctx.fillStyle = s.color;
      ctx.shadowColor = s.color + '55'; ctx.shadowBlur = 10;
      ctx.fill(); ctx.shadowBlur = 0;
      a = a2;
    });
  }

  window.muyaCharts = { line: drawLine, donut: drawDonut };

  /* ---------- Modals ---------- */
  function openModal(html, wide) {
    var back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = '<div class="modal' + (wide ? ' modal-wide' : '') + '">' + html + '</div>';
    function close(e) { if (e.target === back) back.remove(); }
    back.addEventListener('click', close);
    document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { back.remove(); document.removeEventListener('keydown', esc); } });
    document.body.appendChild(back);
    back.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', function () { back.remove(); }); });
    return back;
  }
  window.muyaModal = openModal;

  /* ---------- Confirm helper ---------- */
  window.muyaConfirm = function (msg) {
    return window.confirm(msg || ((M.i18n && M.i18n.confirm_action) || 'Are you sure?'));
  };

  /* ---------- Copy ---------- */
  window.muyaCopy = function (text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { toast((M.i18n && M.i18n.copied) || 'Copied', 'ok'); });
    } else {
      var ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); toast((M.i18n && M.i18n.copied) || 'Copied', 'ok'); } catch (e) {}
      ta.remove();
    }
  };

  /* ---------- Mobile nav ---------- */
  var navToggle = document.getElementById('navToggle');
  if (navToggle) {
    navToggle.addEventListener('click', function () {
      var sb = document.getElementById('sidebar');
      if (sb) sb.classList.toggle('open');
    });
    document.addEventListener('click', function (e) {
      var sb = document.getElementById('sidebar');
      if (sb && sb.classList.contains('open') && !sb.contains(e.target) && e.target !== navToggle) {
        sb.classList.remove('open');
      }
    });
  }

  /* ---------- Auto segments hint (composer) ---------- */
  var composerMsg = document.getElementById('msgText');
  if (composerMsg) {
    var update = function () {
      var txt = composerMsg.value || '';
      var isUni = /[^\u0000-\u007F£¥èéùìòÇØøÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ¡ÄÖÑÜ§¿äöñüà\f^{}\[\]~|€]/.test(txt);
      var len = Array.from(txt).length;
      var single = isUni ? 70 : 160, concat = isUni ? 67 : 153;
      var segs = len === 0 ? 0 : (len <= single ? 1 : Math.ceil(len / concat));
      var remain = len === 0 ? single : (segs === 1 ? single - len : concat - (len - concat * (segs - 1)));
      var el = document.getElementById('segInfo');
      if (el) {
        el.innerHTML = '<b>' + len + '</b> ' + (document.documentElement.lang === 'am' ? 'ፊደላት' : 'characters') +
          ' · ' + (isUni ? 'Unicode' : 'GSM-7') + ' · <b>' + seggsSafe(segs) + '</b> ' +
          (document.documentElement.lang === 'am' ? 'ክፍሎች' : 'segments') + ' · ' + remain;
      }
      var costEl = document.getElementById('costInfo');
      if (costEl && typeof window.muyaEstimate === 'function') window.muyaEstimate();
    };
    function seggsSafe(s) { return s; }
    composerMsg.addEventListener('input', update);
    update();
  }

  /* ---------- Init ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    initTilt();
    animateCounters();
  });
  initTilt();
  animateCounters();
})();
