<?php
/**
 * MuyaSMS — one-time installer (v1.2 — instant-accounts update).
 *
 *  Step 0  storage/installed.lock exists  → already installed
 *  Step 1  config/config.php missing      → full config form (writes the file)
 *  Step 2  MySQL connection fails         → quick-fix DB form (rewrites ONLY the DB_* lines)
 *  Step 3  DB ok                          → creates all tables + seeds settings (dump.sql mirror)
 *          + UPGRADE for v2 instant accounts:
 *              • ALTER users ADD UNIQUE uniq_phone (safe if it exists)
 *              • pending customers → active (no approval needed anymore)
 *  Step 4  super-admin form               → creates officialqeyo@gmail.com owner account
 *  Step 5  writes storage/installed.lock  → DELETE THIS FILE after install!
 *
 * No password is ever displayed after it is saved. Config values are read from
 * config/config.php server-side (regex) — secrets are never embedded in this file.
 */
error_reporting(E_ALL);
ini_set('display_errors', '1');

define('MUYA', true);
define('ROOT', __DIR__);

$lock    = ROOT . '/storage/installed.lock';
$cfgFile = ROOT . '/config/config.php';

if (!is_dir(ROOT . '/storage')) { @mkdir(ROOT . '/storage', 0755, true); }

session_start();
if (empty($_SESSION['inst_csrf'])) { $_SESSION['inst_csrf'] = bin2hex(random_bytes(16)); }
$csrf = $_SESSION['inst_csrf'];

function inst_csrf_ok(): bool
{
    return isset($_POST['csrf']) && hash_equals($_SESSION['inst_csrf'] ?? '', (string)$_POST['csrf']);
}

function inst_q(string $v): string { return str_replace("'", "\\'", $v); }

/** Replace (or insert) one define() line inside config.php text. */
function inst_set_cfg(string $txt, string $key, string $val, bool $quoted): string
{
    $rep = "define('" . $key . "', " . ($quoted ? "'" . str_replace("'", "\\'", $val) . "'" : $val) . ");";
    $new = (string)preg_replace("/define\('" . $key . "',\s*[^;]+\);/", $rep, $txt, 1);
    if ($new === $txt && strpos($txt, "define('" . $key . "'") === false) {
        // key missing -> insert after the DB_HOST line (or right after <?php)
        $new = (string)preg_replace("/(define\('DB_HOST',[^;]+\);\n)/", '$1' . $rep . "\n", $txt, 1);
        if ($new === $txt) {
            $new = (string)preg_replace('/^<\?php\s*\n/', '\\0' . $rep . "\n", $txt, 1);
        }
    }
    return $new;
}

/** Persist the database connection details into config/config.php. */
function inst_save_db_config(string $cfgFile, string $drv, string $host, int $port, string $user): void
{
    $txt = (string)@file_get_contents($cfgFile);
    if ($txt === '') return;
    $txt = inst_set_cfg($txt, 'DB_DRIVER', $drv, true);
    $txt = inst_set_cfg($txt, 'DB_HOST', $host, true);
    $txt = inst_set_cfg($txt, 'DB_PORT', (string)$port, false);
    $txt = inst_set_cfg($txt, 'DB_USER', $user, true);
    @file_put_contents($cfgFile, $txt);
}

/** Replace (or insert) one define() line inside config.php text. */
function inst_set_cfg(string $txt, string $key, string $val, bool $quoted): string
{
    $rep = "define('" . $key . "', " . ($quoted ? "'" . str_replace("'", "\\'", $val) . "'" : $val) . ");";
    $new = (string)preg_replace("/define\\('" . $key . "',\\s*[^;]+\\);/", str_replace('\\', '\\\\', $rep), $txt, 1);
    if ($new === $txt && strpos($txt, "define('" . $key . "'") === false) {
        // key missing -> insert after the DB_HOST line (or right after <?php)
        $new = (string)preg_replace("/(define\\('DB_HOST',[^;]+\\);\\n)/", '$1' . $rep . "\n", $txt, 1);
        if ($new === $txt) {
            $new = (string)preg_replace('/^<\\?php\\s*\\n/', '\\0' . $rep . "\n", $txt, 1);
        }
    }
    return $new;
}

/** Persist a winning database connection combo into config/config.php. */
function inst_save_db_config(string $cfgFile, string $drv, string $host, int $port, string $user): void
{
    $txt = (string)@file_get_contents($cfgFile);
    if ($txt === '') return;
    $txt = inst_set_cfg($txt, 'DB_DRIVER', $drv, true);
    $txt = inst_set_cfg($txt, 'DB_HOST', $host, true);
    $txt = inst_set_cfg($txt, 'DB_PORT', (string)$port, false);
    $txt = inst_set_cfg($txt, 'DB_USER', $user, true);
    @file_put_contents($cfgFile, $txt);
}

// ---- read existing config values (never execute the file) ----
$cfg = [];
if (is_file($cfgFile)) {
    $txt = (string)file_get_contents($cfgFile);
    foreach (['DB_DRIVER','DB_HOST','DB_PORT','DB_NAME','DB_USER','DB_PASS','SMTP_HOST','SMTP_PORT','SMTP_SECURE','SMTP_USER','SMTP_PASS','SMTP_FROM','SMTP_FROM_NAME','APP_URL','CRON_KEY'] as $k) {
        if (preg_match("/define\('" . $k . "',\s*'([^']*)'/", $txt, $m)) { $cfg[$k] = $m[1]; }
        elseif (preg_match("/define\('" . $k . "',\s*([0-9]+)/", $txt, $m)) { $cfg[$k] = $m[1]; }
    }
}

$installed = is_file($lock);
$configOk  = is_file($cfgFile);
$done = false; $error = ''; $dbError = '';
$tablesOk = false; $adminOk = false;

// ================= POST: config forms =================
if (!$installed && $_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['form'])) {
    if (!inst_csrf_ok()) {
        $error = 'Security token expired — please try again.';
    } elseif ($_POST['form'] === 'dbfix' && $configOk) {
        $driver = (string)($_POST['db_driver'] ?? 'mysql') === 'pgsql' ? 'pgsql' : 'mysql';
        $host   = trim((string)($_POST['db_host'] ?? 'localhost'));
        $port   = (int)($_POST['db_port'] ?? ($driver === 'pgsql' ? 5432 : 3306));
        $name   = trim((string)($_POST['db_name'] ?? ''));
        $user   = trim((string)($_POST['db_user'] ?? ''));
        $pass   = (string)($_POST['db_pass'] ?? '');
        if ($name === '' || $user === '' || !preg_match('/^[A-Za-z0-9_]+$/', $name) || !preg_match('/^[A-Za-z0-9_]+$/', $user)) {
            $error = 'Database name/user may contain only letters, numbers and underscore (cPanel format: youraccount_name).';
        } elseif ($pass === '') {
            $error = 'Database password cannot be empty.';
        } elseif (!preg_match('~^[A-Za-z0-9._/\\-]+$~', $host) || $host === '') {
            $error = 'Invalid DB host.';
        } elseif ($port < 1 || $port > 65535) {
            $error = 'Invalid DB port (PostgreSQL: 5432 · MySQL: 3306).';
        } else {
            $txt = (string)file_get_contents($cfgFile);
            $txt = inst_set_cfg($txt, 'DB_DRIVER', $driver, true);
            $txt = inst_set_cfg($txt, 'DB_HOST', $host, true);
            $txt = inst_set_cfg($txt, 'DB_PORT', (string)$port, false);
            $txt = inst_set_cfg($txt, 'DB_NAME', $name, true);
            $txt = inst_set_cfg($txt, 'DB_USER', $user, true);
            $txt = inst_set_cfg($txt, 'DB_PASS', $pass, true);
            if (@file_put_contents($cfgFile, $txt) === false) {
                $error = 'Could not write config/config.php — set config/ permissions to 755 and retry.';
            } else {
                header('Location: install.php');
                exit;
            }
        }
    } elseif ($_POST['form'] === 'fullconfig' && !$configOk) {
        $driver = (string)($_POST['db_driver'] ?? 'mysql') === 'pgsql' ? 'pgsql' : 'mysql';
        $host   = trim((string)($_POST['db_host'] ?? 'localhost'));
        $port   = (int)($_POST['db_port'] ?? ($driver === 'pgsql' ? 5432 : 3306));
        $name   = trim((string)($_POST['db_name'] ?? ''));
        $user   = trim((string)($_POST['db_user'] ?? ''));
        $pass   = (string)($_POST['db_pass'] ?? '');
        $smtph  = trim((string)($_POST['smtp_host'] ?? ''));
        $smtpp  = (int)($_POST['smtp_port'] ?? 465);
        $smtpu  = trim((string)($_POST['smtp_user'] ?? ''));
        $smtppw = (string)($_POST['smtp_pass'] ?? '');
        if ($name === '' || $user === '' || $pass === '' || !preg_match('/^[A-Za-z0-9_]+$/', $name) || !preg_match('/^[A-Za-z0-9_]+$/', $user)) {
            $error = 'Database name/user may contain only letters, numbers and underscore; password required.';
        } elseif ($port < 1 || $port > 65535) {
            $error = 'Invalid DB port (PostgreSQL: 5432 · MySQL: 3306).';
        } elseif ($smtph === '' || $smtpu === '' || $smtppw === '' || !filter_var($smtpu, FILTER_VALIDATE_EMAIL) || ($smtpp !== 465 && $smtpp !== 587 && $smtpp !== 25)) {
            $error = 'SMTP settings incomplete (host, email user, password, port 465/587/25).';
        } else {
            $cronKey = bin2hex(random_bytes(20));
            $tpl = "<?php
/**
 * MuyaSMS configuration — written by the installer.
 * Secrets are protected by config/.htaccess — never share them.
 */
define('DB_DRIVER', '" . $driver . "');
define('DB_HOST', '" . inst_q($host) . "');
define('DB_PORT', " . (int)$port . ");
define('DB_NAME', '" . inst_q($name) . "');
define('DB_USER', '" . inst_q($user) . "');
define('DB_PASS', '" . inst_q($pass) . "');

define('SMTP_HOST', '" . inst_q($smtph) . "');
define('SMTP_PORT', " . $smtpp . ");
define('SMTP_SECURE', '" . ($smtpp === 465 ? 'ssl' : 'tls') . "');
define('SMTP_USER', '" . inst_q($smtpu) . "');
define('SMTP_PASS', '" . inst_q($smtppw) . "');
define('SMTP_FROM', '" . inst_q($smtpu) . "');
define('SMTP_FROM_NAME', 'MuyaSMS');

define('APP_URL', 'https://muyalink.com/muyasms');
define('CRON_KEY', '" . $cronKey . "');
define('APP_DEBUG', false);
";
            if (@file_put_contents($cfgFile, $tpl) === false) {
                $error = 'Could not write config/config.php — set config/ permissions to 755 and retry.';
            } else {
                header('Location: install.php');
                exit;
            }
        }
    }
}

// ================= Main flow =================
$pdo = null;
$drvName = '';
if (!$installed && $configOk) {
    require ROOT . '/config/config.php';
    require ROOT . '/includes/helpers.php';

    try {
        // ---- connect (PostgreSQL: auto-try the usual cPanel combos) ----
        $drv = strtolower(trim(defined('DB_DRIVER') ? DB_DRIVER : 'mysql'));
        if ($drv === 'postgres' || $drv === 'postgresql') { $drv = 'pgsql'; }

        if ($drv === 'pgsql' && !in_array('pgsql', PDO::getAvailableDrivers(), true)) {
            throw new PDOException('PHP on this server does not have the PostgreSQL driver (pdo_pgsql) enabled. Ask the host to enable it, OR create a MySQL database in cPanel -> MySQL Databases and pick MySQL below.');
        }
        if ($drv === 'mysql' && !in_array('mysql', PDO::getAvailableDrivers(), true)) {
            throw new PDOException('PHP on this server does not have the MySQL driver (pdo_mysql) enabled. Create a PostgreSQL database in cPanel -> PostgreSQL Databases and pick PostgreSQL below.');
        }

        $port  = (int)(defined('DB_PORT') ? DB_PORT : ($drv === 'pgsql' ? 5432 : 3306));
        $cands = [];
        if ($drv === 'pgsql') {
            $cands[] = ['host' => DB_HOST, 'port' => $port, 'user' => DB_USER];
            $acct = explode('_', trim(DB_NAME))[0];   // cPanel account name (e.g. muyalito)
            if ($acct !== '' && $acct !== DB_USER) {
                $cands[] = ['host' => 'localhost', 'port' => 5432, 'user' => $acct];
                $cands[] = ['host' => '/var/run/postgresql', 'port' => 5432, 'user' => $acct];
            }
            $cands[] = ['host' => '/var/run/postgresql', 'port' => 5432, 'user' => DB_USER];
        } else {
            $cands[] = ['host' => DB_HOST, 'port' => $port, 'user' => DB_USER];
        }

        foreach ($cands as $c) {
            if ($c['user'] === '') continue;
            try {
                $dsn = $drv === 'pgsql'
                    ? 'pgsql:host=' . $c['host'] . ';port=' . (int)$c['port'] . ';dbname=' . DB_NAME
                    : 'mysql:host=' . $c['host'] . ';port=' . (int)$c['port'] . ';dbname=' . DB_NAME . ';charset=utf8mb4';
                $try = new PDO($dsn, $c['user'], DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 6]);
                $try->query('SELECT 1');
                $pdo = $try;
                // persist the winning combo into config.php when it differs
                if ($c['host'] !== DB_HOST || (int)$c['port'] !== $port || $c['user'] !== DB_USER) {
                    inst_save_db_config($cfgFile, $drv, $c['host'], (int)$c['port'], $c['user']);
                }
                break;
            } catch (PDOException $e) { /* try next combo */ }
        }
        if (!$pdo) {
            $names = implode(', ', array_unique(array_filter(array_column($cands, 'user'))));
            throw new PDOException('Connection to database "' . DB_NAME . '" failed (tried user(s): ' . $names . '; hosts: localhost + /var/run/postgresql). Check the name, user and password exactly as shown in cPanel.');
        }
        $drvName  = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);   // 'mysql' | 'pgsql'
        $configOk = true;

        // ---- create tables (dump.sql for MySQL · dump-pg.sql for PostgreSQL) ----
        $dumpName = $drvName === 'pgsql' ? 'dump-pg.sql' : 'dump.sql';
        $schema = @file_get_contents(ROOT . '/' . $dumpName);
        if ($schema === false) {
            $error = $dumpName . ' not found next to install.php';
        } else {
            $schema = preg_replace('/^\s*--.*$/m', '', $schema);
            $stmts = array_filter(array_map('trim', explode(';', $schema)));
            foreach ($stmts as $stmt) {
                if ($stmt === '') continue;
                try {
                    $pdo->exec($stmt);
                } catch (PDOException $e) {
                    if (stripos($e->getMessage(), 'already exists') === false && stripos($e->getMessage(), 'duplicate') === false) {
                        $error .= 'Schema: ' . $e->getMessage() . "\n";
                    }
                }
            }
        }
        if ($error === '') {
            $tablesOk = true;

            // ---- seed default settings ----
            $defaults = [
                'platform_name'            => 'MuyaSMS',
                'admin_notify_email'       => 'officialqeyo@gmail.com',
                'price_per_sms'            => '1.00',
                'intl_credit_multiplier'   => '2',
                'signup_free_credits'      => '100',
                'bulk_requires_verification' => '1',
                'unverified_recipient_limit' => '10',
                'telebirr_name'            => 'MuyaLink',
                'telebirr_account'         => '',
                'telebirr_note'            => 'Open your telebirr app, send the payment, then submit the transaction ID below.',
                'min_topup_etb'            => '25',
                'dispatch_batch_size'      => '25',
                'dispatch_interval_sec'    => '20',
                'maintenance_mode'         => '0',
                'email_enabled'            => '1',
            ];
            $seedSql = $drvName === 'pgsql'
                ? 'INSERT INTO settings (skey, svalue) VALUES (?,?) ON CONFLICT (skey) DO NOTHING'
                : 'INSERT INTO settings (skey, svalue) VALUES (?,?) ON DUPLICATE KEY UPDATE svalue = svalue';
            foreach ($defaults as $k => $v) {
                try {
                    $pdo->prepare($seedSql)->execute([$k, $v]);
                } catch (PDOException $e) { /* keep existing values */ }
            }

            // ---- v2 UPGRADE: instant accounts ------------------------------------
            // 1) unique phone index (so phone sign-in is unambiguous).
            //    Ignored if the index already exists or old rows collide.
            try {
                if ($drvName === 'pgsql') {
                    $pdo->exec('ALTER TABLE users ADD CONSTRAINT uniq_phone UNIQUE (phone)');
                } else {
                    $pdo->exec('ALTER TABLE `users` ADD UNIQUE KEY `uniq_phone` (`phone`)');
                }
            } catch (PDOException $e) { /* already exists or duplicates — fine */ }

            // 2) unlock stuck 'pending' customers — accounts no longer need
            //    any approval. (Admins/staff untouched.)
            try {
                $pdo->exec("UPDATE users SET status = 'active' WHERE status = 'pending' AND role = 'customer'");
            } catch (PDOException $e) { /* ignore */ }

            // ---- super-admin already exists? ----
            $adminOk = (bool)$pdo->query('SELECT COUNT(*) FROM users WHERE role = \'admin\'')->fetchColumn();
        }

        // ---- create the super-admin (owner) ----
        if ($tablesOk && !$adminOk && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'admin') {
            if (!inst_csrf_ok()) {
                $error = 'Security token expired — please try again.';
            } else {
                $name  = trim((string)($_POST['name'] ?? ''));
                $email = strtolower(trim((string)($_POST['email'] ?? '')));
                $pass  = (string)($_POST['password'] ?? '');
                $pass2 = (string)($_POST['password2'] ?? '');
                if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = 'Please enter a name and a valid email.';
                } elseif (strlen($pass) < 10 || !preg_match('/[A-Za-z]/', $pass) || !preg_match('/[0-9]/', $pass)) {
                    $error = 'Password must be 10+ characters with letters and numbers.';
                } elseif ($pass !== $pass2) {
                    $error = 'Passwords do not match.';
                } else {
                    try {
                        $st = $pdo->prepare(
                            'INSERT INTO users (name, email, password_hash, role, status, email_verified, preferred_lang, credits, last_ip)
                             VALUES (?,?,?,?,\'active\',1,\'en\',0,?)'
                        );
                        $st->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT), 'admin', $_SERVER['REMOTE_ADDR'] ?? null]);
                        @file_put_contents($lock, date('c'));
                        $done = true;
                    } catch (PDOException $e) {
                        $error = 'DB error: ' . $e->getMessage();
                    }
                }
            }
        }

        if (!$done && $tablesOk && $adminOk) {
            @file_put_contents($lock, date('c'));
            $done = true;
        }
    } catch (PDOException $e) {
        $dbError = $e->getMessage();
    }
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>MuyaSMS — Installer</title>
<style>
body{background:#0A0D12;color:#F8FAFC;font-family:-apple-system,'Segoe UI',Roboto,'Noto Sans Ethiopic',sans-serif;margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;font-size:15px}
.box{max-width:600px;width:100%;background:linear-gradient(165deg,#131B2C,#0E1421);border:1px solid #26334A;border-radius:18px;padding:34px;box-shadow:0 30px 80px rgba(0,0,0,.6)}
h1{font-size:23px;margin:0 0 4px}
.sub{color:#94A3B8;font-size:13.5px;margin-bottom:22px}
.step{display:flex;gap:12px;align-items:center;padding:12px 14px;border-radius:12px;border:1px solid #1E293B;background:rgba(22,30,46,.5);margin-bottom:10px;font-size:14px}
.ok{color:#10B981}.bad{color:#EF4444}.wait{color:#F59E0B}
label{display:block;font-size:12.5px;color:#94A3B8;font-weight:600;margin:14px 0 6px}
input{width:100%;padding:12px 14px;border-radius:12px;background:rgba(10,14,20,.65);border:1px solid #26334A;color:#F8FAFC;font-size:14px;box-sizing:border-box}
input:focus{outline:none;border-color:#3B82F6;box-shadow:0 0 0 3px rgba(59,130,246,.16)}
button{width:100%;margin-top:20px;padding:13px;border:none;border-radius:12px;background:linear-gradient(135deg,#10B981,#3B82F6);color:#fff;font-weight:700;font-size:15px;cursor:pointer}
.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.4);color:#FCA5A5;padding:12px;border-radius:12px;margin-bottom:14px;font-size:13.5px;white-space:pre-wrap}
a{color:#10B981}
.note{font-size:12px;color:#64748B;margin-top:16px;line-height:1.7}
.hint{font-size:11.5px;color:#64748B;margin-top:4px;line-height:1.5}
</style>
</head>
<body>
<div class="box">
  <h1>MuyaSMS <span style="background:linear-gradient(90deg,#10B981,#3B82F6);-webkit-background-clip:text;background-clip:text;color:transparent">installer</span></h1>
  <div class="sub">muyalink.com · PHP <?= PHP_VERSION ?></div>

<?php if ($installed): ?>
  <div class="step"><span class="ok">✔</span> Already installed — <a href="index.php">open MuyaSMS</a></div>
  <div class="note">Need to reinstall? Delete <b>storage/installed.lock</b>.<br><b style="color:#F59E0B">⚠ And delete install.php from production if still present!</b></div>

<?php elseif (!$configOk): ?>
  <div class="step"><span class="wait">1</span> config/config.php is missing — fill the form below (it writes the file)</div>
  <?php if ($error !== ''): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="post" autocomplete="off">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
    <input type="hidden" name="form" value="fullconfig">
    <label>Database type</label>
    <select name="db_driver" required style="width:100%;padding:12px 14px;border-radius:12px;background:rgba(10,14,20,.65);border:1px solid #26334A;color:#F8FAFC;font-size:14px;box-sizing:border-box">
      <option value="pgsql">PostgreSQL (phpPgAdmin)</option>
      <option value="mysql">MySQL (phpMyAdmin)</option>
    </select>
    <label>Database host</label><input name="db_host" value="localhost" required>
    <label>Database port (PostgreSQL 5432 · MySQL 3306)</label><input name="db_port" value="5432" required>
    <label>Database name (cPanel prefixes it, e.g. muyalito_muyasms)</label><input name="db_name" required placeholder="youraccount_muyasms">
    <label>Database user</label><input name="db_user" required placeholder="youraccount_muya (or your cPanel account name)">
    <label>Database password</label><input type="password" name="db_pass" required>
    <label>SMTP host</label><input name="smtp_host" value="mail.muyalink.com" required>
    <label>SMTP port</label><input name="smtp_port" value="465" required>
    <label>SMTP user (mailbox email)</label><input name="smtp_user" value="sms@muyalink.com" required>
    <label>SMTP password</label><input type="password" name="smtp_pass" required>
    <button type="submit">Save configuration →</button>
  </form>

<?php else: ?>
  <?php if ($error !== ''): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <?php if ($dbError !== ''): ?>
    <div class="err">Database connection failed:<br><?= htmlspecialchars($dbError) ?></div>
    <div class="step"><span class="wait">2</span> Fix the database details below — the installer rewrites only the DB lines in config.php</div>
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
      <input type="hidden" name="form" value="dbfix">
      <label>Database type</label>
      <select name="db_driver" required style="width:100%;padding:12px 14px;border-radius:12px;background:rgba(10,14,20,.65);border:1px solid #26334A;color:#F8FAFC;font-size:14px;box-sizing:border-box">
        <option value="pgsql"<?= ($cfg['DB_DRIVER'] ?? '') === 'pgsql' ? ' selected' : '' ?>>PostgreSQL (phpPgAdmin)</option>
        <option value="mysql"<?= ($cfg['DB_DRIVER'] ?? '') !== 'pgsql' ? ' selected' : '' ?>>MySQL (phpMyAdmin)</option>
      </select>
      <label>Database host</label><input name="db_host" value="<?= htmlspecialchars($cfg['DB_HOST'] ?? 'localhost') ?>" required>
      <label>Database port (PostgreSQL 5432 · MySQL 3306)</label><input name="db_port" value="<?= htmlspecialchars($cfg['DB_PORT'] ?? '5432') ?>" required>
      <label>Database name</label>
      <input name="db_name" value="<?= htmlspecialchars($cfg['DB_NAME'] ?? '') ?>" required>
      <div class="hint">cPanel shows the full name in <b>PostgreSQL Databases</b> / <b>MySQL® Databases</b> — usually <b>youraccount_</b> + the name you created (yours: <b>muyalito_muyasms</b>).</div>
      <label>Database user</label><input name="db_user" value="<?= htmlspecialchars($cfg['DB_USER'] ?? '') ?>" required>
      <div class="hint">PostgreSQL: often your cPanel account name (e.g. <b>muyalito</b>) or the user you created in cPanel.</div>
      <label>Database password</label>
      <input type="password" name="db_pass" value="<?= htmlspecialchars($cfg['DB_PASS'] ?? '') ?>" required>
      <div class="hint">Already saved from your setup — change it only if the DB password is different.</div>
      <button type="submit">Save &amp; retry connection →</button>
    </form>

  <?php elseif ($done): ?>
    <div class="step"><span class="ok">✔</span> Database ready</div>
    <div class="step"><span class="ok">✔</span> Super-admin created</div>
    <div class="step"><span class="ok">✔</span> <b>Installation complete!</b></div>
    <a href="admin/index.php"><button type="button">Open admin panel →</button></a>
    <div class="note"><b style="color:#F59E0B">⚠ SECURITY — do these now:</b><br>
      1. <b>Delete install.php</b> from the server.<br>
      2. Set up the cPanel cron job (see README-DEPLOY.md — the CRON_KEY is inside config/config.php).<br>
      3. Keep config/config.php protected (config/.htaccess already blocks web access).</div>

  <?php else: ?>
    <div class="step"><span class="<?= $tablesOk ? 'ok' : 'wait' ?>"><?= $tablesOk ? '✔' : '…' ?></span> Database connection + tables (<?= ($drvName ?? '') === 'pgsql' ? 'PostgreSQL · dump-pg.sql' : 'MySQL · dump.sql' ?>)</div>
    <div class="step"><span class="wait">…</span> Super-admin account (form below)</div>

    <?php if ($tablesOk && !$adminOk): ?>
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
      <input type="hidden" name="form" value="admin">
      <label>Administrator name</label>
      <input name="name" required value="MuyaLink Admin">
      <label>Administrator email — the super-admin / owner login (officialqeyo@gmail.com)</label>
      <input type="email" name="email" required value="officialqeyo@gmail.com">
      <label>Password (10+ chars, letters &amp; numbers)</label>
      <input type="password" name="password" required minlength="10" autocomplete="new-password">
      <label>Repeat password</label>
      <input type="password" name="password2" required minlength="10" autocomplete="new-password">
      <button type="submit">Create super-admin &amp; finish →</button>
    </form>
    <?php endif; ?>
  <?php endif; ?>
<?php endif; ?>
</div>
</body>
</html>
