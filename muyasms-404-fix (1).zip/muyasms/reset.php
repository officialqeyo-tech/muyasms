<?php
/**
 * MuyaSMS — password reset (request link + set new password).
 */
require __DIR__ . '/includes/bootstrap.php';

$mode = 'request';          // request | new | done
$token = trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));
$error = '';

if ($token !== '' && preg_match('/^[a-f0-9]{64}$/', $token)) {
    $mode = 'new';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    require_same_origin();

    if (isset($_POST['do_request'])) {
        if (!rl_check('reset', 4, 3600)) {
            $error = __('err_locked');
        } else {
            $login = post_str('login', 190);   // email OR phone
            $t = $login ? issue_reset_token($login) : null;
            if ($t) {
                $u = find_user_by_login($login);
                $link = base_url('/reset.php?token=' . $t);
                $html = email_template(
                    'Reset your password',
                    'የይለፍ ቃል እንደገና ያስጀምሩ',
                    '<p>We received a request to reset the password for <b>' . e($u['email']) . '</b>. The link below is valid for 1 hour.</p><p>If you did not request this, you can safely ignore this email.</p>',
                    '<p>ለ<b>' . e($u['email']) . '</b> የይለፍ ቃል ለመቀየር ጥያቄ ደርሶናል። ከዚህ በታች ያለው አገናኽ ለ1 ሰዓት ብቻ ይሠራል።</p><p>ጥያቄ ካላደረጉ በስተቀር መረሳት ይችላሉ።</p>',
                    $link,
                    'Reset password / ይለፍ ቃል ቀይር'
                );
                muya_mail($u['email'], 'MuyaSMS — Password reset / የይለፍ ቃል መቀየር', $html);
                audit('reset_request', $u['email']);
            }
            $mode = 'done'; // same message either way (no user enumeration)
        }
    } elseif (isset($_POST['do_new'])) {
        if (!rl_check('reset_new', 8, 3600)) {
            $error = __('err_locked');
        } else {
            $u = consume_reset_token($token);
            $pass = (string)($_POST['password'] ?? '');
            if (!$u) {
                $error = __('verify_bad');
                $mode = 'new';
            } elseif (!password_ok($pass)) {
                $error = __('err_password_rules');
                $mode = 'new';
            } elseif ($pass !== (string)($_POST['password2'] ?? '')) {
                $error = __('err_fields');
                $mode = 'new';
            } else {
                q('UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?', [password_hash($pass, PASSWORD_DEFAULT), $u['id']]);
                audit('reset_done', $u['email']);
                $mode = 'done';
                flash_set('ok', __('reset_ok'));
                redirect('signin.php');
            }
        }
    }
}
?><!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(__('reset_title')) ?> · MuyaSMS</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/muya.css">
</head>
<body>
<div class="bg-stage" aria-hidden="true">
  <div class="orb orb-emerald"></div><div class="orb orb-blue"></div><div class="grid-floor"></div>
</div>
<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;z-index:1">
  <div class="auth-card" style="max-width:440px">
    <a class="auth-brand" href="index.php"><?= muya_logo_svg(30) ?><span class="brand-name" style="font-size:16px">MuyaSMS</span></a>

    <?php if ($error): ?><div class="flash flash-err mt-2"><?= e($error) ?></div><?php endif; ?>

    <?php if ($mode === 'done'): ?>
      <h1 class="mt-2">✉️</h1>
      <p class="sub" style="margin:8px 0 20px"><?= e(__('reset_sent')) ?></p>
      <a class="btn btn-ghost btn-block" href="signin.php"><?= e(__('sign_in')) ?></a>

    <?php elseif ($mode === 'new'): ?>
      <h1 class="mt-2"><?= e(__('reset_new')) ?></h1>
      <p class="sub" style="margin-bottom:18px"><?= e(__('err_password_rules')) ?></p>
      <form method="post" action="reset.php">
        <?= csrf_field() ?>
        <input type="hidden" name="token" value="<?= e($token) ?>">
        <input type="hidden" name="do_new" value="1">
        <div class="f-group">
          <label class="f-label"><?= e(__('set_new_pass')) ?></label>
          <input class="f-input f-input-lg" type="password" name="password" required minlength="8" autofocus>
        </div>
        <div class="f-group">
          <label class="f-label"><?= e(__('password_confirm')) ?></label>
          <input class="f-input f-input-lg" type="password" name="password2" required minlength="8">
        </div>
        <button class="btn btn-primary btn-block" type="submit"><?= e(__('save')) ?></button>
      </form>

    <?php else: ?>
      <h1 class="mt-2"><?= e(__('reset_title')) ?></h1>
      <p class="sub" style="margin-bottom:18px"><?= e(__('reset_hint')) ?></p>
      <form method="post" action="reset.php">
        <?= csrf_field() ?>
        <input type="hidden" name="do_request" value="1">
        <div class="f-group">
          <label class="f-label"><?= e(__('email_or_phone')) ?></label>
          <input class="f-input f-input-lg" type="text" name="login" required autofocus placeholder="you@company.com  ·  09…">
        </div>
        <button class="btn btn-primary btn-block" type="submit"><?= e(__('submit')) ?></button>
      </form>
    <?php endif; ?>

    <div class="auth-foot"><a href="signin.php">← <?= e(__('back')) ?></a></div>
  </div>
</div>
</body>
</html>
