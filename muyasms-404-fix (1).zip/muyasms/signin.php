<?php
/**
 * MuyaSMS — customer sign-in (email OR phone + password).
 * Accounts are active from registration — no approval needed.
 * Admin emails are directed to the admin panel.
 */
require __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    $u = current_user();
    redirect(in_array($u['role'], ['admin', 'staff'], true) ? 'admin/dashboard.php' : 'app/index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    require_same_origin();
    if (!rl_check('login', 12, 600)) {
        $error = __('err_locked');
    } else {
        [$ok, $err] = attempt_login(post_str('login', 190), (string)($_POST['password'] ?? ''), 'app');
        if ($ok) {
            $u = current_user();
            if (in_array($u['role'], ['admin', 'staff'], true)) redirect('admin/dashboard.php');
            redirect('app/index.php');
        }
        $error = $err;
    }
}
?><!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(__('sign_in')) ?> · MuyaSMS</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/muya.css">
</head>
<body>
<div class="bg-stage" aria-hidden="true">
  <div class="orb orb-emerald"></div><div class="orb orb-blue"></div><div class="orb orb-gold"></div><div class="grid-floor"></div>
</div>

<div class="auth-shell">
  <div class="auth-hero">
    <div class="flex" style="gap:12px"><?= muya_logo_svg(40) ?><span class="brand-name" style="font-size:22px">MuyaSMS</span></div>
    <h2 class="mt-3"><?= e(__('hero_title')) ?></h2>
    <p><?= e(__('hero_sub')) ?></p>
    <div class="feature-grid">
      <div class="feature"><div class="f-ic" style="color:var(--emerald)"><?= muya_icon('send') ?></div><h4><?= e(__('feat_bulk_t')) ?></h4><p><?= e(__('feat_bulk_d')) ?></p></div>
      <div class="feature"><div class="f-ic" style="color:var(--gold)"><?= muya_icon('card') ?></div><h4><?= e(__('feat_pay_t')) ?></h4><p><?= e(__('feat_pay_d')) ?></p></div>
      <div class="feature"><div class="f-ic" style="color:var(--blue)"><?= muya_icon('zap') ?></div><h4><?= e(__('feat_auto_t')) ?></h4><p><?= e(__('feat_auto_d')) ?></p></div>
      <div class="feature"><div class="f-ic" style="color:var(--orange)"><?= muya_icon('shield') ?></div><h4><?= e(__('feat_ver_t')) ?></h4><p><?= e(__('feat_ver_d')) ?></p></div>
    </div>
  </div>

  <div class="auth-panel">
    <div class="auth-card">
      <a class="auth-brand" href="index.php"><?= muya_logo_svg(32) ?><span class="brand-name" style="font-size:17px">MuyaSMS</span></a>
      <h1><?= e(__('login_title')) ?></h1>
      <div class="sub"><?= e(__('customer_portal')) ?></div>

      <?php if ($error): ?><div class="flash flash-err mb-2"><?= e($error) ?></div><?php endif; ?>
      <?php foreach (flash_get() as $f): ?><div class="flash flash-<?= e($f['type']) ?> mb-2"><?= e($f['msg']) ?></div><?php endforeach; ?>

      <form method="post" action="signin.php" autocomplete="on">
        <?= csrf_field() ?>
        <div class="f-group">
          <label class="f-label" for="login"><?= e(__('email_or_phone')) ?></label>
          <input class="f-input f-input-lg" type="text" id="login" name="login" required autofocus autocomplete="username" placeholder="you@company.com  ·  09…">
        </div>
        <div class="f-group">
          <label class="f-label" for="password"><?= e(__('password')) ?></label>
          <input class="f-input f-input-lg" type="password" id="password" name="password" required autocomplete="current-password" placeholder="••••••••">
        </div>
        <button class="btn btn-primary btn-block btn-lg" type="submit" style="padding:13px"><?= e(__('sign_in')) ?></button>
      </form>

      <div class="auth-foot" style="display:flex;justify-content:space-between">
        <a href="reset.php"><?= e(__('forgot')) ?></a>
        <a href="register.php"><?= e(__('no_account')) ?> →</a>
      </div>
      <div class="auth-foot" style="border-top:1px solid var(--border);padding-top:14px">
        <a href="admin/index.php" style="color:var(--dim)"><?= muya_icon('shield') ?> <?= e(__('landing_admin')) ?></a>
      </div>
      <div class="auth-legal center" style="margin-top:12px">
        <a href="?lang=<?= lang() === 'en' ? 'am' : 'en' ?>" style="color:var(--dim)"><?= lang() === 'en' ? '🇪🇹 በአማርኛ ይመልከቱ' : '🇬🇧 View in English' ?></a>
      </div>
    </div>
  </div>
</div>
</body>
</html>
