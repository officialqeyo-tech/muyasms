<?php
/**
 * MuyaSMS — email verification landing (v2).
 *
 * Verification NEVER blocks the account (accounts are active from
 * registration). Clicking the link only confirms the email address.
 * Logged-in users can also resend the link via ?resend=1.
 */
require __DIR__ . '/includes/bootstrap.php';

$state = 'idle';   // idle | ok | bad | resent

// ---- Resend (logged-in, unverified) ----
if (isset($_GET['resend'])) {
    $u = current_user();
    if ($u && !(int)$u['email_verified'] && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_csrf();
        require_same_origin();
        if (rl_check('vresend', 3, 3600)) {
            $token = reissue_verify_token($u);
            $verifyUrl = base_url('/verify.php?token=' . $token);
            $html = email_template(
                'Confirm your email address',
                'የኢሜይል አድራሻዎን ያረጋግጡ',
                '<p>Hi <b>' . e($u['name']) . '</b> — tap the button below to confirm your email address. The link expires in 24 hours.</p>',
                '<p>ሰላም <b>' . e($u['name']) . '</b> — ኢሜይልዎን ለማረጋገጥ ከዚህ በታች ያለውን አዝራር ይንኩ። አገናኙ በ24 ሰዓታት ውስጥ ይያባል።</p>',
                $verifyUrl,
                'Confirm my email / ኢሜይል ያረጋግጡ'
            );
            muya_mail($u['email'], 'MuyaSMS — Confirm your email / ኢሜይል ያረጋግጡ', $html);
            audit('verify_resend', $u['email']);
            $state = 'resent';
        }
    } elseif ($u) {
        redirect('app/index.php');
    } else {
        redirect('signin.php');
    }
}

// ---- Token landing ----
$token = trim((string)($_GET['token'] ?? ''));
if ($token !== '' && preg_match('/^[a-f0-9]{64}$/', $token)) {
    $u = qr('SELECT * FROM users WHERE verify_token = ? AND verify_expires > NOW()', [hash('sha256', $token)]);
    if ($u) {
        $already = (int)$u['email_verified'] === 1;
        if (!$already) {
            apply_email_verification($u);
            // friendly confirmation email
            $html = email_template(
                'Email confirmed — thank you! 🎉',
                'ኢሜይል ተረጋግጧል — እናመሰግናለን! 🎉',
                '<p>Thanks <b>' . e($u['name']) . '</b>! Your email address is now confirmed. Your account and credits are ready — enjoy MuyaSMS!</p>',
                '<p>እናመሰግናለን <b>' . e($u['name']) . '</b>! ኢሜይልዎ ተረጋግጧል። መለያዎና ክሬዲቶችዎ ዝግጁ ናቸው — MuyaSMSን ይደሰቱ።</p>',
                base_url('/signin.php'),
                'Sign in / ግባ'
            );
            muya_mail($u['email'], 'MuyaSMS — Email confirmed / ኢሜይል ተረጋግጧል', $html);
        }
        $state = 'ok';
    } else {
        $state = 'bad';
    }
} elseif ($token === '') {
    // no token and no resend → just go where they belong
    redirect(current_user() ? 'app/index.php' : 'signin.php');
}

$uNow = current_user();
$csrfField = csrf_field();
?><!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(__('verify_email_title')) ?> · MuyaSMS</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/muya.css">
</head>
<body>
<div class="bg-stage" aria-hidden="true">
  <div class="orb orb-emerald"></div><div class="orb orb-blue"></div><div class="grid-floor"></div>
</div>
<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;z-index:1">
  <div class="auth-card center" style="max-width:460px">
    <div style="font-size:52px;margin-bottom:8px"><?= in_array($state, ['ok', 'resent'], true) ? '🎉' : '⚠️' ?></div>

    <?php if ($state === 'ok'): ?>
      <h1><?= e(__('verify_ok')) ?></h1>
      <p class="sub" style="margin:10px 0 22px;color:var(--muted)"><?= e(__('verify_ok_d')) ?></p>
      <a class="btn btn-primary btn-block" href="<?= $uNow ? 'app/index.php' : 'signin.php' ?>">
        <?= $uNow ? e(__('nav_dashboard')) : e(__('verify_goto')) ?>
      </a>

    <?php elseif ($state === 'resent'): ?>
      <h1><?= e(__('verify_email_sent')) ?></h1>
      <p class="sub" style="margin:10px 0 22px;color:var(--muted)"><?= e(__('send_verify_again')) ?></p>
      <a class="btn btn-primary btn-block" href="app/index.php"><?= e(__('nav_dashboard')) ?></a>

    <?php else: ?>
      <h1><?= e(__('verify_bad')) ?></h1>
      <p class="sub" style="margin:10px 0 22px;color:var(--muted)"><?= e(__('verify_bad')) ?></p>
      <?php if ($uNow && !(int)$uNow['email_verified']): ?>
      <form method="post" action="verify.php?resend=1">
        <?= $csrfField ?>
        <button class="btn btn-primary btn-block" type="submit"><?= e(__('verify_resend')) ?></button>
      </form>
      <?php else: ?>
      <a class="btn btn-ghost btn-block" href="signin.php"><?= e(__('sign_in')) ?></a>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
