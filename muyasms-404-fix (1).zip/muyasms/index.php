<?php
/**
 * MuyaSMS — landing page (no loading/splash page — instant content).
 */
require __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    $u = current_user();
    redirect(in_array($u['role'], ['admin', 'staff'], true) ? 'admin/dashboard.php' : 'app/index.php');
}
$platform = setting('platform_name', 'MuyaSMS');
?><!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?= e(__('hero_sub')) ?>">
<title><?= e($platform) ?> — <?= e(__('hero_title')) ?></title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/muya.css">
</head>
<body>
<div class="bg-stage" aria-hidden="true">
  <div class="orb orb-emerald"></div>
  <div class="orb orb-blue"></div>
  <div class="orb orb-gold"></div>
  <div class="grid-floor"></div>
</div>

<nav class="landing-nav">
  <?= muya_logo_svg(36) ?>
  <div class="brand-name" style="font-size:20px"><?= e($platform) ?></div>
  <div class="right flex" style="gap:10px">
    <a class="lang-toggle" href="?lang=<?= lang() === 'en' ? 'am' : 'en' ?>"><?= muya_icon('globe') ?><span><?= lang() === 'en' ? 'አማርኛ' : 'English' ?></span></a>
    <a class="btn btn-ghost" href="signin.php"><?= e(__('sign_in')) ?></a>
    <a class="btn btn-primary" href="register.php"><?= e(__('hero_cta')) ?></a>
  </div>
</nav>

<section class="landing-hero">
  <div>
    <span class="tag tag-green">muyalink.com · telebirr</span>
    <h1 style="margin-top:16px"><?= e(__('hero_title')) ?> <span class="grad">— <?= e($platform) ?></span></h1>
    <p class="lead"><?= e(__('hero_sub')) ?></p>
    <div class="landing-cta">
      <a class="btn-hero" href="register.php"><?= e(__('hero_cta')) ?></a>
      <a class="btn-hero-ghost" href="signin.php"><?= e(__('hero_cta2')) ?></a>
    </div>
    <div class="free-note">🎁 <?= e(__('hero_free')) ?></div>
  </div>

  <div class="hero-visual">
    <div class="card card-3d hero-card-3d hero-float" data-tilt="8" style="padding:18px">
      <img src="assets/img/logo.svg" alt="MuyaSMS — Auto &amp; Bulk SMS Gateway" loading="eager"
           style="width:100%;height:auto;display:block;border-radius:12px">
      <div class="mt-2 small muted" style="text-align:center">
        <?= e(__('hero_title')) ?> · muyalink.com · telebirr
      </div>
    </div>
  </div>
</section>

<section class="landing-features">
  <?php
  $feats = [
      ['feat_bulk_t', 'feat_bulk_d', 'send', 'var(--emerald)'],
      ['feat_auto_t', 'feat_auto_d', 'zap', 'var(--blue)'],
      ['feat_gateway_t', 'feat_gateway_d', 'grid', 'var(--gold)'],
      ['feat_pay_t', 'feat_pay_d', 'card', 'var(--orange)'],
      ['feat_ver_t', 'feat_ver_d', 'shield', 'var(--emerald)'],
  ];
  foreach ($feats as $f): ?>
  <div class="card card-3d" data-tilt="5">
    <div class="flex" style="gap:12px;margin-bottom:10px">
      <span class="stat-ic" style="position:static;color:<?= $f[3] ?>"><?= muya_icon($f[2]) ?></span>
      <h4 style="font-size:15px"><?= e(__($f[0])) ?></h4>
    </div>
    <p class="muted small"><?= e(__($f[1])) ?></p>
  </div>
  <?php endforeach; ?>
</section>

<footer class="landing-foot">
  © <?= date('Y') ?> <?= e($platform) ?> · muyalink.com ·
  <a href="admin/index.php" style="color:var(--dim)"><?= e(__('landing_admin')) ?></a>
</footer>

<script src="assets/js/app.js"></script>
</body>
</html>
