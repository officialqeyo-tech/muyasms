-- ============================================================
-- MuyaSMS — PostgreSQL schema + default settings (muyalink.com)
-- Used automatically by /install.php when the database is
-- PostgreSQL (phpPgAdmin). Do NOT import by hand — the installer
-- does it for you. The super-admin is created by install.php too.
-- ============================================================

-- ------------------------------------------------------------
-- users   (v2: customers are ACTIVE from registration — no admin
--          approval; phone is unique so it can be used to sign in)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'customer' CHECK (role IN ('admin','staff','customer')),
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('pending','active','suspended')),
  email_verified SMALLINT NOT NULL DEFAULT 0,
  verify_token CHAR(64) DEFAULT NULL,
  verify_expires TIMESTAMP DEFAULT NULL,
  reset_token CHAR(64) DEFAULT NULL,
  reset_expires TIMESTAMP DEFAULT NULL,
  phone VARCHAR(32) DEFAULT NULL,
  company_name VARCHAR(190) DEFAULT NULL,
  company_verified SMALLINT NOT NULL DEFAULT 0,
  credits INTEGER NOT NULL DEFAULT 0,
  api_key_hash CHAR(64) DEFAULT NULL,
  preferred_lang VARCHAR(5) NOT NULL DEFAULT 'en',
  failed_logins SMALLINT NOT NULL DEFAULT 0,
  locked_until TIMESTAMP DEFAULT NULL,
  last_login TIMESTAMP DEFAULT NULL,
  last_ip VARCHAR(45) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT NULL,
  CONSTRAINT uniq_email UNIQUE (email),
  CONSTRAINT uniq_phone UNIQUE (phone)
);

-- ------------------------------------------------------------
-- wallet_transactions  (telebirr top-ups, bonus, charges)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(12) NOT NULL DEFAULT 'topup' CHECK (type IN ('topup','bonus','charge','refund','adjust')),
  credits INTEGER NOT NULL DEFAULT 0,
  amount_etb NUMERIC(12,2) DEFAULT NULL,
  method VARCHAR(12) NOT NULL DEFAULT 'system' CHECK (method IN ('telebirr','system','admin')),
  txn_ref VARCHAR(120) DEFAULT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'approved' CHECK (status IN ('pending','approved','rejected')),
  note VARCHAR(255) DEFAULT NULL,
  reviewed_by INTEGER DEFAULT NULL,
  reviewed_at TIMESTAMP DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uniq_txn_ref UNIQUE (txn_ref)
);
CREATE INDEX IF NOT EXISTS idx_wt_user ON wallet_transactions (user_id);
CREATE INDEX IF NOT EXISTS idx_wt_status ON wallet_transactions (status);

-- ------------------------------------------------------------
-- gateways  (admin-configurable HTTP SMS gateways)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gateways (
  id SERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  api_url VARCHAR(500) NOT NULL,
  http_method VARCHAR(6) NOT NULL DEFAULT 'POST' CHECK (http_method IN ('GET','POST')),
  headers_json TEXT,
  body_template TEXT,
  sender_id VARCHAR(60) DEFAULT NULL,
  success_condition VARCHAR(255) DEFAULT NULL,
  delivered_condition VARCHAR(255) DEFAULT NULL,
  id_regex VARCHAR(255) DEFAULT NULL,
  timeout_sec SMALLINT NOT NULL DEFAULT 15,
  retries SMALLINT NOT NULL DEFAULT 2,
  max_per_second SMALLINT NOT NULL DEFAULT 5,
  priority SMALLINT NOT NULL DEFAULT 100,
  is_default SMALLINT NOT NULL DEFAULT 0,
  status VARCHAR(10) NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT NULL
);
CREATE INDEX IF NOT EXISTS idx_gw_status_def ON gateways (status, is_default, priority);

-- ------------------------------------------------------------
-- campaigns
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS campaigns (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(160) NOT NULL,
  message TEXT NOT NULL,
  recipients_count INTEGER NOT NULL DEFAULT 0,
  credits_charged INTEGER NOT NULL DEFAULT 0,
  gateway_id INTEGER DEFAULT NULL,
  source VARCHAR(6) NOT NULL DEFAULT 'web' CHECK (source IN ('web','api')),
  status VARCHAR(12) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sending','completed','failed','cancelled')),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finished_at TIMESTAMP DEFAULT NULL
);
CREATE INDEX IF NOT EXISTS idx_camp_user ON campaigns (user_id, id);
CREATE INDEX IF NOT EXISTS idx_camp_status ON campaigns (status);

-- ------------------------------------------------------------
-- messages  (one row per recipient — real delivery state)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS messages (
  id BIGSERIAL PRIMARY KEY,
  campaign_id INTEGER DEFAULT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient VARCHAR(24) NOT NULL,
  content TEXT NOT NULL,
  segments SMALLINT NOT NULL DEFAULT 1,
  credits INTEGER NOT NULL DEFAULT 1,
  status VARCHAR(10) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','delivered','failed')),
  gateway_msg_id VARCHAR(120) DEFAULT NULL,
  error VARCHAR(255) DEFAULT NULL,
  gateway_id INTEGER DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at TIMESTAMP DEFAULT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_campaign ON messages (campaign_id);
CREATE INDEX IF NOT EXISTS idx_msg_user_status ON messages (user_id, status);
CREATE INDEX IF NOT EXISTS idx_msg_dispatch ON messages (status, id);

-- ------------------------------------------------------------
-- contacts
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contacts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(120) DEFAULT NULL,
  phone VARCHAR(24) NOT NULL,
  group_name VARCHAR(80) NOT NULL DEFAULT 'Default',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uniq_ct_user_phone UNIQUE (user_id, phone)
);
CREATE INDEX IF NOT EXISTS idx_ct_user_group ON contacts (user_id, group_name);

-- ------------------------------------------------------------
-- verifications  (enterprise documents — local storage)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS verifications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company_name VARCHAR(190) NOT NULL,
  doc_path VARCHAR(300) NOT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  note VARCHAR(255) DEFAULT NULL,
  reviewed_by INTEGER DEFAULT NULL,
  reviewed_at TIMESTAMP DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_vf_user ON verifications (user_id);
CREATE INDEX IF NOT EXISTS idx_vf_status ON verifications (status);

-- ------------------------------------------------------------
-- settings  (everything adjustable by the super-admin)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  skey VARCHAR(80) NOT NULL PRIMARY KEY,
  svalue TEXT
);

INSERT INTO settings (skey, svalue) VALUES
  ('platform_name', 'MuyaSMS'),
  ('admin_notify_email', 'officialqeyo@gmail.com'),
  ('price_per_sms', '1.00'),
  ('intl_credit_multiplier', '2'),
  ('signup_free_credits', '100'),
  ('bulk_requires_verification', '1'),
  ('unverified_recipient_limit', '10'),
  ('telebirr_name', 'MuyaLink'),
  ('telebirr_account', ''),
  ('telebirr_note', 'Open your telebirr app, send the payment, then submit the transaction ID below.'),
  ('min_topup_etb', '25'),
  ('dispatch_batch_size', '25'),
  ('dispatch_interval_sec', '20'),
  ('maintenance_mode', '0'),
  ('email_enabled', '1')
ON CONFLICT (skey) DO NOTHING;

-- ------------------------------------------------------------
-- audit_log
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
  id BIGSERIAL PRIMARY KEY,
  user_id INTEGER DEFAULT NULL,
  actor_email VARCHAR(190) DEFAULT NULL,
  action VARCHAR(80) NOT NULL,
  details VARCHAR(500) DEFAULT NULL,
  ip VARCHAR(45) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log (created_at);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log (action);
