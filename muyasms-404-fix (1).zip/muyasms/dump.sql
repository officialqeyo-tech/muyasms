-- ============================================================
-- MuyaSMS — MySQL schema + default settings (muyalink.com)
-- Import via cPanel → phpMyAdmin (UTF-8, utf8mb4_unicode_ci)
-- The super-admin account is created by /install.php afterwards.
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- users   (v2: customers are ACTIVE from registration — no admin
--          approval; phone is unique so it can be used to sign in)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('admin','staff','customer') NOT NULL DEFAULT 'customer',
  `status` ENUM('pending','active','suspended') NOT NULL DEFAULT 'active',
  `email_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `verify_token` CHAR(64) DEFAULT NULL,
  `verify_expires` DATETIME DEFAULT NULL,
  `reset_token` CHAR(64) DEFAULT NULL,
  `reset_expires` DATETIME DEFAULT NULL,
  `phone` VARCHAR(32) DEFAULT NULL,
  `company_name` VARCHAR(190) DEFAULT NULL,
  `company_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `credits` INT NOT NULL DEFAULT 0,
  `api_key_hash` CHAR(64) DEFAULT NULL,
  `preferred_lang` VARCHAR(5) NOT NULL DEFAULT 'en',
  `failed_logins` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` DATETIME DEFAULT NULL,
  `last_login` DATETIME DEFAULT NULL,
  `last_ip` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_email` (`email`),
  UNIQUE KEY `uniq_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- wallet_transactions  (telebirr top-ups, bonus, charges)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wallet_transactions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `type` ENUM('topup','bonus','charge','refund','adjust') NOT NULL,
  `credits` INT NOT NULL DEFAULT 0,
  `amount_etb` DECIMAL(12,2) DEFAULT NULL,
  `method` ENUM('telebirr','system','admin') NOT NULL DEFAULT 'system',
  `txn_ref` VARCHAR(120) DEFAULT NULL,
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
  `note` VARCHAR(255) DEFAULT NULL,
  `reviewed_by` INT UNSIGNED DEFAULT NULL,
  `reviewed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_txn_ref` (`txn_ref`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_wt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- gateways  (admin-configurable HTTP SMS gateways)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `gateways` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `api_url` VARCHAR(500) NOT NULL,
  `http_method` ENUM('GET','POST') NOT NULL DEFAULT 'POST',
  `headers_json` TEXT,
  `body_template` TEXT,
  `sender_id` VARCHAR(60) DEFAULT NULL,
  `success_condition` VARCHAR(255) DEFAULT NULL,
  `delivered_condition` VARCHAR(255) DEFAULT NULL,
  `id_regex` VARCHAR(255) DEFAULT NULL,
  `timeout_sec` SMALLINT UNSIGNED NOT NULL DEFAULT 15,
  `retries` TINYINT UNSIGNED NOT NULL DEFAULT 2,
  `max_per_second` SMALLINT UNSIGNED NOT NULL DEFAULT 5,
  `priority` TINYINT UNSIGNED NOT NULL DEFAULT 100,
  `is_default` TINYINT(1) NOT NULL DEFAULT 0,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status_def` (`status`, `is_default`, `priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- campaigns
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `campaigns` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(160) NOT NULL,
  `message` TEXT NOT NULL,
  `recipients_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `credits_charged` INT NOT NULL DEFAULT 0,
  `gateway_id` INT UNSIGNED DEFAULT NULL,
  `source` ENUM('web','api') NOT NULL DEFAULT 'web',
  `status` ENUM('queued','sending','completed','failed','cancelled') NOT NULL DEFAULT 'queued',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finished_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`, `id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_camp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- messages  (one row per recipient — real delivery state)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `messages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `campaign_id` INT UNSIGNED DEFAULT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `recipient` VARCHAR(24) NOT NULL,
  `content` TEXT NOT NULL,
  `segments` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `credits` INT NOT NULL DEFAULT 1,
  `status` ENUM('queued','sent','delivered','failed') NOT NULL DEFAULT 'queued',
  `gateway_msg_id` VARCHAR(120) DEFAULT NULL,
  `error` VARCHAR(255) DEFAULT NULL,
  `gateway_id` INT UNSIGNED DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_user_status` (`user_id`, `status`),
  KEY `idx_dispatch` (`status`, `id`),
  CONSTRAINT `fk_msg_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_msg_camp` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- contacts
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(120) DEFAULT NULL,
  `phone` VARCHAR(24) NOT NULL,
  `group_name` VARCHAR(80) NOT NULL DEFAULT 'Default',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_phone` (`user_id`, `phone`),
  KEY `idx_user_group` (`user_id`, `group_name`),
  CONSTRAINT `fk_ct_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- verifications  (enterprise documents — local storage)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `verifications` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `company_name` VARCHAR(190) NOT NULL,
  `doc_path` VARCHAR(300) NOT NULL,
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `note` VARCHAR(255) DEFAULT NULL,
  `reviewed_by` INT UNSIGNED DEFAULT NULL,
  `reviewed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_vf_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- settings  (everything adjustable by the super-admin)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `skey` VARCHAR(80) NOT NULL,
  `svalue` TEXT,
  PRIMARY KEY (`skey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`skey`, `svalue`) VALUES
  ('platform_name', 'MuyaSMS'),
  ('admin_notify_email', 'officialqeyo@gmail.com'),
  ('price_per_sms', '1.00'),
  ('intl_credit_multiplier', '2'),
  ('signup_free_credits', '100'),
  ('bulk_requires_verification', '1'),
  ('unverified_recipient_limit', '10'),
  ('telebirr_name', 'MuyaLink'),
  ('telebirr_account', ''),
  ('telebirr_note', 'Open your telebirr app, send the payment, then submit the transaction ID below.'),
  ('min_topup_etb', '25'),
  ('dispatch_batch_size', '25'),
  ('dispatch_interval_sec', '20'),
  ('maintenance_mode', '0'),
  ('email_enabled', '1')
ON DUPLICATE KEY UPDATE `svalue` = `svalue`;

-- ------------------------------------------------------------
-- audit_log
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `actor_email` VARCHAR(190) DEFAULT NULL,
  `action` VARCHAR(80) NOT NULL,
  `details` VARCHAR(500) DEFAULT NULL,
  `ip` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
